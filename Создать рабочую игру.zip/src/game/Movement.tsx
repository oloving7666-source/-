import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { HALF } from "./config";
import { actions, getState } from "./store";
import type { CameraMode } from "./types";

interface Props {
  keys: React.MutableRefObject<Record<string, boolean>>;
  pref: React.MutableRefObject<THREE.Vector3>;
  href: React.MutableRefObject<number>; // player heading (radians)
  mode: CameraMode;
}

const fwd = new THREE.Vector3();
const right = new THREE.Vector3();
const move = new THREE.Vector3();

// Camera-relative, joystick-style locomotion: W always pushes "into" the
// screen regardless of camera yaw, and the avatar turns to face travel.
export default function Movement({ keys, pref, href, mode }: Props) {
  const { camera } = useThree();

  useFrame((_, delta) => {
    if (getState().paused) return;
    const k = keys.current;
    let f = 0, s = 0;
    if (k.KeyW || k.ArrowUp) f += 1;
    if (k.KeyS || k.ArrowDown) f -= 1;
    if (k.KeyD || k.ArrowRight) s += 1;
    if (k.KeyA || k.ArrowLeft) s -= 1;
    if (!f && !s) return;
    const p = pref.current;

    if (mode === "explore") {
      // Tank-style, over-the-shoulder: A/D turn the avatar (the follow-cam
      // swings to match), W/S walk along the current heading.
      if (s) href.current -= s * delta * 2.4; // D turns right, A turns left
      if (f) {
        const h = href.current;
        const sprint = k.ShiftLeft || k.ShiftRight ? 1.9 : 1;
        const speed = 12 * sprint * delta * f;
        p.x = THREE.MathUtils.clamp(p.x + Math.sin(h) * speed, -HALF, HALF);
        p.z = THREE.MathUtils.clamp(p.z + Math.cos(h) * speed, -HALF, HALF);
        actions.setPlayer(p.x, p.z);
        actions.grabPickupsNear();
      }
      return;
    }

    // Architect (top-down): camera-relative panning across the map.
    camera.getWorldDirection(fwd);
    fwd.y = 0;
    if (fwd.lengthSq() < 1e-4) fwd.set(0, 0, -1);
    fwd.normalize();
    right.set(-fwd.z, 0, fwd.x); // camera-right on XZ (= up × forward)

    move.set(0, 0, 0).addScaledVector(fwd, f).addScaledVector(right, s);
    if (move.lengthSq() < 1e-6) return;
    move.normalize();

    const speed = 30 * delta;
    p.x = THREE.MathUtils.clamp(p.x + move.x * speed, -HALF, HALF);
    p.z = THREE.MathUtils.clamp(p.z + move.z * speed, -HALF, HALF);
    actions.setPlayer(p.x, p.z);

    // smoothly turn avatar toward movement heading
    const targetH = Math.atan2(move.x, move.z);
    let dh = targetH - href.current;
    while (dh > Math.PI) dh -= Math.PI * 2;
    while (dh < -Math.PI) dh += Math.PI * 2;
    href.current += dh * Math.min(1, delta * 12);
  });

  return null;
}
