import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import { BUILDINGS, CELL, POLLUTION_THRESHOLD } from "./config";
import { getState, isPowered } from "./store";
import type { Building } from "./types";

// ---- Satisfactory-style structural kit -------------------------------------
// Light concrete with a FICSIT-orange edge trim, so a raised factory floor
// reads cleanly instead of machines sitting straight on the dirt.
const CONCRETE = "#c7c8bb";
const CONCRETE_TOP = "#b6b8a8";
const ORANGE = "#e0872e";

// Orange perimeter trim running around the top edge of a slab of thickness `t`.
function EdgeTrim({ t, s }: { t: number; s: number }) {
  return (
    <>
      {[-1, 1].map((sg) => (
        <mesh key={`x${sg}`} position={[0, t - 0.05, (sg * s) / 2]}>
          <boxGeometry args={[s, 0.1, 0.08]} />
          <meshStandardMaterial color={ORANGE} emissive={ORANGE} emissiveIntensity={0.15} roughness={0.6} />
        </mesh>
      ))}
      {[-1, 1].map((sg) => (
        <mesh key={`z${sg}`} position={[(sg * s) / 2, t - 0.05, 0]}>
          <boxGeometry args={[0.08, 0.1, s]} />
          <meshStandardMaterial color={ORANGE} emissive={ORANGE} emissiveIntensity={0.15} roughness={0.6} />
        </mesh>
      ))}
    </>
  );
}

// A flat foundation slab: concrete block + inlaid top panel + orange trim.
function Slab({ t }: { t: number }) {
  const s = CELL * 0.98;
  return (
    <group>
      <mesh position={[0, t / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[s, t, s]} />
        <meshStandardMaterial color={CONCRETE} roughness={0.92} />
      </mesh>
      <mesh position={[0, t + 0.002, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[s * 0.88, s * 0.88]} />
        <meshStandardMaterial color={CONCRETE_TOP} roughness={1} />
      </mesh>
      <EdgeTrim t={t} s={s} />
    </group>
  );
}

// A sloped foundation (ramp). Rises `rise` units across one cell along +Z.
function Ramp() {
  const s = CELL * 0.98;
  const rise = 1.5, run = s;
  const hyp = Math.hypot(rise, run);
  const ang = Math.atan2(rise, run);
  return (
    <group position={[0, rise / 2, 0]} rotation={[-ang, 0, 0]}>
      <mesh castShadow receiveShadow>
        <boxGeometry args={[s, 0.32, hyp]} />
        <meshStandardMaterial color={CONCRETE} roughness={0.92} />
      </mesh>
      <mesh position={[0, 0.17, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[s * 0.88, hyp * 0.92]} />
        <meshStandardMaterial color={CONCRETE_TOP} roughness={1} />
      </mesh>
      {[-1, 1].map((sg) => (
        <mesh key={sg} position={[(sg * s) / 2, 0.12, 0]}>
          <boxGeometry args={[0.08, 0.1, hyp]} />
          <meshStandardMaterial color={ORANGE} emissive={ORANGE} emissiveIntensity={0.15} roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

// Ascending steps within one cell.
function Stairs() {
  const s = CELL * 0.9;
  const steps = 5, d = s / steps;
  return (
    <group>
      {Array.from({ length: steps }).map((_, i) => {
        const h = (i + 1) * 0.3;
        return (
          <mesh key={i} position={[0, h / 2, -s / 2 + d * (i + 0.5)]} castShadow receiveShadow>
            <boxGeometry args={[s * 0.9, h, d]} />
            <meshStandardMaterial color={i % 2 ? CONCRETE : CONCRETE_TOP} roughness={0.95} />
          </mesh>
        );
      })}
    </group>
  );
}

// A structural column that spans one floor of height.
function Pillar({ h }: { h: number }) {
  return (
    <group>
      <mesh position={[0, h / 2, 0]} castShadow>
        <boxGeometry args={[0.5, h, 0.5]} />
        <meshStandardMaterial color="#b8b9ac" roughness={0.9} />
      </mesh>
      {[0.06, h - 0.06].map((y, i) => (
        <mesh key={i} position={[0, y, 0]}>
          <boxGeometry args={[0.6, 0.12, 0.6]} />
          <meshStandardMaterial color={ORANGE} emissive={ORANGE} emissiveIntensity={0.15} roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

// A framed glass floor panel.
function GlassFloor() {
  const s = CELL * 0.98;
  return (
    <group>
      <mesh position={[0, 0.18, 0]}>
        <boxGeometry args={[s * 0.86, 0.14, s * 0.86]} />
        <meshStandardMaterial color="#bfe0ea" transparent opacity={0.34} roughness={0.1} metalness={0.2} />
      </mesh>
      <mesh position={[0, 0.06, 0]} castShadow>
        <boxGeometry args={[s, 0.12, s]} />
        <meshStandardMaterial color={CONCRETE} roughness={0.9} />
      </mesh>
      <EdgeTrim t={0.36} s={s} />
    </group>
  );
}

// Rising chimney smoke over a running INDUSTRIAL building. Density and darkness
// scale with world pollution, so the grimy chain visibly dirties the air — the
// eco chain never spawns it.
function Smoke({ y = 1.9, tint = "#4a4038" }: { y?: number; tint?: string }) {
  const ref = useRef<THREE.Group>(null);
  const puffs = useMemo(() => Array.from({ length: 5 }, (_, i) => ({ off: i / 5, sway: (i % 3) - 1 })), []);
  useFrame((s) => {
    if (getState().paused || !ref.current) return;
    const t = s.clock.elapsedTime;
    const dirt = Math.min(1, getState().pollution / POLLUTION_THRESHOLD);
    ref.current.visible = true;
    ref.current.children.forEach((c, i) => {
      const p = ((t * 0.35 + puffs[i].off) % 1);
      c.position.y = y + p * 2.6;
      c.position.x = puffs[i].sway * 0.18 + Math.sin(t * 0.8 + i) * 0.12;
      const sc = 0.18 + p * 0.6;
      c.scale.setScalar(sc);
      const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
      m.opacity = (0.15 + dirt * 0.5) * (1 - p);
    });
  });
  return (
    <group ref={ref}>
      {puffs.map((_, i) => (
        <mesh key={i}>
          <dodecahedronGeometry args={[0.5, 0]} />
          <meshStandardMaterial color={tint} transparent opacity={0} roughness={1} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}

// Gentle rising sparkle over a running ECO building — a clean counterpart to
// the industrial smoke (pollen / water mist).
function EcoMotes({ y = 1.4, color = "#bff0d0" }: { y?: number; color?: string }) {
  const ref = useRef<THREE.Group>(null);
  const motes = useMemo(() => Array.from({ length: 6 }, (_, i) => ({ off: i / 6, a: (i * 2.3) % (Math.PI * 2) })), []);
  useFrame((s) => {
    if (getState().paused || !ref.current) return;
    const t = s.clock.elapsedTime;
    ref.current.children.forEach((c, i) => {
      const p = ((t * 0.4 + motes[i].off) % 1);
      c.position.set(Math.cos(motes[i].a + p * 2) * (0.3 + p * 0.2), y + p * 1.6, Math.sin(motes[i].a + p * 2) * (0.3 + p * 0.2));
      const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
      m.opacity = 0.7 * Math.sin(p * Math.PI);
    });
  });
  return (
    <group ref={ref}>
      {motes.map((_, i) => (
        <mesh key={i}>
          <icosahedronGeometry args={[0.07, 0]} />
          <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.6} transparent opacity={0} toneMapped={false} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}

// Forge fire: a flickering warm glow plus upward-spitting sparks over a working
// smelter/complex — reads as active, hot industry (and blooms nicely).
function Forge({ y = 1.2 }: { y?: number }) {
  const light = useRef<THREE.PointLight>(null);
  const sparks = useRef<THREE.Group>(null);
  const glow = useRef<THREE.Mesh>(null);
  const seeds = useMemo(() => Array.from({ length: 9 }, (_, i) => ({
    off: i / 9, a: (i * 2.7) % (Math.PI * 2), r: 0.12 + (i % 3) * 0.08, spd: 0.9 + (i % 4) * 0.25,
  })), []);
  useFrame((s) => {
    if (getState().paused) return;
    const t = s.clock.elapsedTime;
    const flick = 0.7 + Math.sin(t * 18) * 0.15 + Math.sin(t * 7.3) * 0.12;
    if (light.current) light.current.intensity = 3.2 * flick;
    if (glow.current) {
      const m = glow.current.material as THREE.MeshStandardMaterial;
      m.emissiveIntensity = 1.4 * flick;
      glow.current.scale.setScalar(0.9 + flick * 0.15);
    }
    if (sparks.current) sparks.current.children.forEach((c, i) => {
      const sd = seeds[i];
      const p = ((t * sd.spd + sd.off) % 1);
      c.position.set(Math.cos(sd.a) * sd.r * (1 - p), y + p * 1.4, Math.sin(sd.a) * sd.r * (1 - p));
      const m = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
      m.opacity = (1 - p) * 0.9;
      c.scale.setScalar(0.5 + (1 - p) * 0.6);
    });
  });
  return (
    <group>
      <pointLight ref={light} position={[0, y, 0]} color="#ff8a3a" distance={7} intensity={3} />
      <mesh ref={glow} position={[0, y, 0]}>
        <sphereGeometry args={[0.28, 12, 12]} />
        <meshStandardMaterial color="#ffb066" emissive="#ff7a2a" emissiveIntensity={1.4} toneMapped={false} transparent opacity={0.85} />
      </mesh>
      <group ref={sparks}>
        {seeds.map((_, i) => (
          <mesh key={i}>
            <icosahedronGeometry args={[0.05, 0]} />
            <meshStandardMaterial color="#ffd27a" emissive="#ffae3a" emissiveIntensity={2} toneMapped={false} transparent opacity={0} depthWrite={false} />
          </mesh>
        ))}
      </group>
    </group>
  );
}

// Each structure is a small, visually distinct low-poly model so the base
// reads at a glance — no more identical boxes.
export function Machine({ b }: { b: Building }) {
  const meta = BUILDINGS[b.kind];
  const spin = useRef<THREE.Group>(null);
  const spin2 = useRef<THREE.Group>(null);
  const spin3 = useRef<THREE.Group>(null);
  // running = drawing power (or a self-powered producer) and not idle
  const running = isPowered(b);
  const dirty = running && (b.kind === "smelter" || b.kind === "assembler" || b.kind === "complex" || b.kind === "drill");
  const clean = running && (b.kind === "pump" || b.kind === "waterwheel" || b.kind === "recycler");

  useFrame((s) => {
    if (getState().paused) return;
    const e = s.clock.elapsedTime;
    if (spin.current) spin.current.rotation.z = e * 2;
    if (spin2.current) spin2.current.rotation.y = e * 3;
    if (spin3.current) spin3.current.rotation.x = e * 1.4;
  });

  const wood = "#6f4e30";

  return (
    <group rotation={[0, (b.rot * Math.PI) / 2, 0]}>
      {/* teal accent trim at the machine's foot — glows while it draws power */}
      {b.kind !== "conveyor" && b.kind !== "pylon" && (
        <mesh position={[0, 0.06, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.62, 0.72, 24]} />
          <meshStandardMaterial
            color="#1a2b2e"
            emissive="#2ff0d0"
            emissiveIntensity={running ? 1.3 : 0.15}
            toneMapped={false}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}
      {b.kind === "drill" && (
        <group>
          {[[-0.55, -0.55], [0.55, -0.55], [-0.55, 0.55], [0.55, 0.55]].map(([x, z], i) => (
            <mesh key={i} position={[x, 0.8, z]} rotation={[0, 0, x * z > 0 ? 0.12 : -0.12]} castShadow>
              <cylinderGeometry args={[0.08, 0.08, 1.7, 5]} />
              <meshStandardMaterial color={wood} />
            </mesh>
          ))}
          <mesh position={[0, 1.7, 0]} castShadow>
            <boxGeometry args={[1, 0.3, 1]} />
            <meshStandardMaterial color={meta.color} />
          </mesh>
          <group ref={spin2} position={[0, 0.9, 0]}>
            <mesh rotation={[0, 0, Math.PI / 4]}>
              <coneGeometry args={[0.25, 1.2, 4]} />
              <meshStandardMaterial color="#d9d2c4" metalness={0.6} roughness={0.3} />
            </mesh>
          </group>
        </group>
      )}

      {b.kind === "smelter" && (
        <group>
          <mesh position={[0, 0.7, 0]} castShadow>
            <boxGeometry args={[1.4, 1.4, 1.4]} />
            <meshStandardMaterial color="#7a7168" roughness={1} />
          </mesh>
          <mesh position={[0.4, 1.7, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.28, 1, 8]} />
            <meshStandardMaterial color="#5a534b" />
          </mesh>
          <mesh position={[0, 0.45, 0.71]}>
            <planeGeometry args={[0.7, 0.6]} />
            <meshStandardMaterial color="#ff7b2e" emissive="#ff7b2e" emissiveIntensity={1.6} toneMapped={false} />
          </mesh>
        </group>
      )}

      {b.kind === "assembler" && (
        <group>
          <mesh position={[0, 0.6, 0]} castShadow>
            <boxGeometry args={[1.5, 1.2, 1.2]} />
            <meshStandardMaterial color={wood} />
          </mesh>
          <mesh position={[0, 1.35, 0]} castShadow>
            <boxGeometry args={[1.7, 0.25, 1.4]} />
            <meshStandardMaterial color={meta.color} />
          </mesh>
          <group ref={spin2} position={[0, 1.5, 0]}>
            <mesh position={[0.55, 0, 0]}>
              <boxGeometry args={[1.1, 0.12, 0.12]} />
              <meshStandardMaterial color="#3a2c1e" emissive={meta.color} emissiveIntensity={0.4} />
            </mesh>
          </group>
        </group>
      )}

      {b.kind === "pump" && (
        <group>
          {/* windmill / water-mill tower */}
          <mesh position={[0, 1.2, 0]} castShadow>
            <cylinderGeometry args={[0.45, 0.7, 2.4, 8]} />
            <meshStandardMaterial color="#b9ac93" roughness={1} />
          </mesh>
          <mesh position={[0, 2.5, 0]} castShadow>
            <coneGeometry args={[0.7, 0.7, 8]} />
            <meshStandardMaterial color="#8a5a3a" />
          </mesh>
          <group ref={spin} position={[0, 2.1, 0.5]}>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} rotation={[0, 0, (i * Math.PI) / 2]} position={[0, 0, 0]}>
                <boxGeometry args={[0.18, 1.6, 0.05]} />
                <meshStandardMaterial color="#e8dcc0" />
              </mesh>
            ))}
          </group>
        </group>
      )}

      {b.kind === "pylon" && (
        <group>
          <mesh position={[0, 1.1, 0]} castShadow>
            <cylinderGeometry args={[0.14, 0.2, 2.2, 6]} />
            <meshStandardMaterial color={wood} />
          </mesh>
          <mesh position={[0, 2.3, 0]}>
            <icosahedronGeometry args={[0.34, 0]} />
            <meshStandardMaterial color="#eaffe0" emissive={meta.color} emissiveIntensity={1.6} toneMapped={false} />
          </mesh>
          <pointLight position={[0, 2.3, 0]} intensity={5} distance={8} color={meta.color} />
        </group>
      )}

      {b.kind === "turret" && (
        <group>
          <mesh position={[0, 0.35, 0]} castShadow>
            <cylinderGeometry args={[0.55, 0.65, 0.7, 8]} />
            <meshStandardMaterial color={wood} />
          </mesh>
          <group ref={spin2} position={[0, 0.9, 0]}>
            <mesh position={[0, 0, 0.4]} rotation={[Math.PI / 2, 0, 0]} castShadow>
              <boxGeometry args={[0.9, 0.12, 0.9]} />
              <meshStandardMaterial color={meta.color} />
            </mesh>
            <mesh position={[0, 0.1, 0.7]} rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.07, 0.07, 1, 6]} />
              <meshStandardMaterial color="#2a1a12" />
            </mesh>
          </group>
        </group>
      )}

      {b.kind === "wall" && (
        <group>
          {[-0.5, 0, 0.5].map((x, i) => (
            <mesh key={i} position={[x, 0.6, 0]} castShadow>
              <cylinderGeometry args={[0.18, 0.18, 1.2, 6]} />
              <meshStandardMaterial color={meta.color} roughness={1} />
            </mesh>
          ))}
          {[-0.5, 0, 0.5].map((x, i) => (
            <mesh key={`t${i}`} position={[x, 1.25, 0]}>
              <coneGeometry args={[0.2, 0.35, 6]} />
              <meshStandardMaterial color="#6f5a3e" />
            </mesh>
          ))}
        </group>
      )}

      {b.kind === "complex" && (
        <group>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[1.7, 1.8, 1.7]} />
            <meshStandardMaterial color={meta.color} />
          </mesh>
          <mesh position={[0, 1.95, 0]} castShadow>
            <boxGeometry args={[1.9, 0.4, 1.9]} />
            <meshStandardMaterial color="#8a5a3a" />
          </mesh>
          <group ref={spin} position={[0.95, 0.9, 0]}>
            <mesh rotation={[0, Math.PI / 2, 0]}>
              <cylinderGeometry args={[0.6, 0.6, 0.08, 16]} />
              <meshStandardMaterial color="#d9d2c4" metalness={0.5} roughness={0.3} />
            </mesh>
          </group>
        </group>
      )}

      {(b.kind === "splitter" || b.kind === "merger") && (
        <group>
          <mesh position={[0, 0.3, 0]} castShadow>
            <cylinderGeometry args={[0.7, 0.7, 0.6, 6]} />
            <meshStandardMaterial color={meta.color} metalness={0.3} roughness={0.5} />
          </mesh>
          {[0, 1, 2].map((i) => {
            const ang = (i / 3) * Math.PI * 2 + (b.kind === "merger" ? Math.PI : 0);
            return (
              <mesh key={i} position={[Math.cos(ang) * 0.6, 0.6, Math.sin(ang) * 0.6]} rotation={[0, -ang, 0]}>
                <coneGeometry args={[0.14, 0.4, 4]} />
                <meshStandardMaterial color="#3a2c1e" emissive={meta.color} emissiveIntensity={0.5} />
              </mesh>
            );
          })}
        </group>
      )}

      {b.kind === "waterwheel" && (
        <group>
          {/* stone mill house */}
          <mesh position={[0, 0.8, 0]} castShadow>
            <boxGeometry args={[1.2, 1.6, 1.1]} />
            <meshStandardMaterial color="#8f9aa0" roughness={1} />
          </mesh>
          <mesh position={[0, 1.85, 0]} castShadow>
            <coneGeometry args={[0.95, 0.7, 4]} />
            <meshStandardMaterial color="#5a6b73" />
          </mesh>
          {/* big vertical water wheel on the side, spinning around X */}
          <group ref={spin3} position={[0.75, 0.85, 0]}>
            <mesh rotation={[0, 0, 0]}>
              <torusGeometry args={[0.85, 0.08, 6, 20]} />
              <meshStandardMaterial color="#6f4e30" roughness={1} />
            </mesh>
            {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => {
              const a = (i / 8) * Math.PI * 2;
              return (
                <group key={i} rotation={[a, 0, 0]}>
                  <mesh position={[0, 0.55, 0]}>
                    <boxGeometry args={[0.34, 0.7, 0.05]} />
                    <meshStandardMaterial color="#8a6a44" roughness={1} />
                  </mesh>
                </group>
              );
            })}
            <mesh rotation={[0, 0, Math.PI / 2]}>
              <cylinderGeometry args={[0.06, 0.06, 0.5, 6]} />
              <meshStandardMaterial color="#3a2c1e" />
            </mesh>
          </group>
          <mesh position={[-0.35, 0.55, 0.56]}>
            <planeGeometry args={[0.4, 0.5]} />
            <meshStandardMaterial color="#bfe6f0" emissive="#7fd0e6" emissiveIntensity={0.5} />
          </mesh>
        </group>
      )}

      {b.kind === "recycler" && (
        <group>
          {/* composter tank with a slow tumbling drum */}
          <mesh position={[0, 0.35, 0]} castShadow>
            <boxGeometry args={[1.3, 0.55, 1.3]} />
            <meshStandardMaterial color="#5a4a34" roughness={1} />
          </mesh>
          <group ref={spin2} position={[0, 0.95, 0]} rotation={[0, 0, Math.PI / 2]}>
            <mesh castShadow>
              <cylinderGeometry args={[0.5, 0.5, 1.1, 10]} />
              <meshStandardMaterial color={meta.color} roughness={0.7} />
            </mesh>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} rotation={[0, (i / 4) * Math.PI * 2, 0]} position={[0, 0, 0]}>
                <boxGeometry args={[1.02, 0.06, 0.12]} />
                <meshStandardMaterial color="#3f5a2c" />
              </mesh>
            ))}
          </group>
          {/* leafy sprout on top */}
          <mesh position={[0, 1.55, 0]}>
            <icosahedronGeometry args={[0.24, 0]} />
            <meshStandardMaterial color="#8fd06a" emissive="#5fae3a" emissiveIntensity={0.3} roughness={0.9} />
          </mesh>
        </group>
      )}

      {b.kind === "found1" && <Slab t={0.5} />}
      {b.kind === "found2" && <Slab t={1.0} />}
      {b.kind === "found4" && <Slab t={2.0} />}
      {b.kind === "ramp" && <Ramp />}
      {b.kind === "cramp" && <group rotation={[0, Math.PI / 4, 0]}><Ramp /></group>}
      {b.kind === "stairs" && <Stairs />}
      {b.kind === "pillar" && <Pillar h={3} />}
      {b.kind === "glass" && <GlassFloor />}

      {dirty && <Smoke y={meta.height + 0.3} tint={b.kind === "smelter" ? "#3a332c" : "#5a5148"} />}
      {dirty && (b.kind === "smelter" || b.kind === "complex") && <Smoke y={meta.height + 0.5} tint="#2e2823" />}
      {clean && <EcoMotes y={meta.height} color={b.kind === "waterwheel" ? "#bfe8f4" : "#c4f0b0"} />}
      {running && (b.kind === "smelter" || b.kind === "complex") && <Forge y={meta.height * 0.55} />}

      {b.kind === "storage" && (
        <group>
          {/* open-top crate bin */}
          <mesh position={[0, 0.7, 0]} castShadow receiveShadow>
            <boxGeometry args={[1.7, 1.4, 1.7]} />
            <meshStandardMaterial color={meta.color} roughness={0.85} />
          </mesh>
          {/* corner posts */}
          {[[-0.8, -0.8], [0.8, -0.8], [-0.8, 0.8], [0.8, 0.8]].map(([x, z], i) => (
            <mesh key={i} position={[x, 0.75, z]} castShadow>
              <boxGeometry args={[0.16, 1.55, 0.16]} />
              <meshStandardMaterial color="#6f4e30" roughness={1} />
            </mesh>
          ))}
          {/* crates peeking over the rim */}
          {[[-0.4, -0.4, "#c8873f"], [0.45, -0.3, "#8a97a0"], [0.1, 0.45, "#7a5a34"], [-0.35, 0.35, "#a0a4ad"]].map(([x, z, c], i) => (
            <mesh key={`c${i}`} position={[x as number, 1.45 + (i % 2) * 0.18, z as number]} castShadow>
              <boxGeometry args={[0.42, 0.42, 0.42]} />
              <meshStandardMaterial color={c as string} roughness={0.7} />
            </mesh>
          ))}
        </group>
      )}

      {b.kind === "hub" && (
        <group>
          <mesh position={[0, 0.9, 0]} castShadow>
            <boxGeometry args={[2, 1.8, 2]} />
            <meshStandardMaterial color={meta.color} roughness={0.9} />
          </mesh>
          <mesh position={[0, 2.2, 0]} castShadow>
            <coneGeometry args={[1.7, 1, 4]} />
            <meshStandardMaterial color="#9c6a3f" />
          </mesh>
          <mesh position={[0, 3, 0]}>
            <sphereGeometry args={[0.28, 16, 16]} />
            <meshStandardMaterial color="#fff6df" emissive="#ffd98a" emissiveIntensity={1.4} toneMapped={false} />
          </mesh>
          <pointLight position={[0, 3, 0]} intensity={6} distance={14} color="#ffd98a" />
        </group>
      )}
    </group>
  );
}
