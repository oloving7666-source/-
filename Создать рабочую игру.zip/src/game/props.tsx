import { useFrame } from "@react-three/fiber";
import { useRef, type ReactElement } from "react";
import * as THREE from "three";
import { terrainHeight } from "./config";
import { getState, useGame } from "./store";
import type { PlacedProp, PropKind } from "./types";

// ---- individual low-poly models (matching the game's cozy forest palette) ----

function Tree() {
  return (
    <group>
      <mesh position={[0, 0.6, 0]} castShadow>
        <cylinderGeometry args={[0.12, 0.18, 1.2, 6]} />
        <meshStandardMaterial color="#6f4e30" roughness={1} />
      </mesh>
      <mesh position={[0, 1.5, 0]} castShadow>
        <icosahedronGeometry args={[0.85, 0]} />
        <meshStandardMaterial color="#4f7a3a" roughness={0.9} flatShading />
      </mesh>
      <mesh position={[0.35, 1.95, 0.1]} castShadow>
        <icosahedronGeometry args={[0.5, 0]} />
        <meshStandardMaterial color="#5e8c46" roughness={0.9} flatShading />
      </mesh>
    </group>
  );
}

function Pine() {
  return (
    <group>
      <mesh position={[0, 0.45, 0]} castShadow>
        <cylinderGeometry args={[0.1, 0.14, 0.9, 6]} />
        <meshStandardMaterial color="#5a3f28" roughness={1} />
      </mesh>
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[0, 1.0 + i * 0.55, 0]} castShadow>
          <coneGeometry args={[0.8 - i * 0.22, 0.85, 7]} />
          <meshStandardMaterial color="#3c6b39" roughness={0.9} flatShading />
        </mesh>
      ))}
    </group>
  );
}

function Bush() {
  return (
    <group>
      {[[0, 0, 0.5], [0.35, 0.1, 0.4], [-0.3, 0.05, 0.42]].map(([x, y, s], i) => (
        <mesh key={i} position={[x, 0.3 + y, 0]} castShadow>
          <icosahedronGeometry args={[s, 0]} />
          <meshStandardMaterial color={i === 1 ? "#6a9b4e" : "#557c3e"} roughness={0.9} flatShading />
        </mesh>
      ))}
    </group>
  );
}

function Rock() {
  return (
    <group>
      <mesh position={[0, 0.32, 0]} rotation={[0.3, 0.6, 0.2]} castShadow>
        <dodecahedronGeometry args={[0.55, 0]} />
        <meshStandardMaterial color="#8f9088" roughness={1} flatShading />
      </mesh>
      <mesh position={[0.45, 0.18, 0.2]} rotation={[0.5, 1.2, 0]} castShadow>
        <dodecahedronGeometry args={[0.28, 0]} />
        <meshStandardMaterial color="#7d7e77" roughness={1} flatShading />
      </mesh>
    </group>
  );
}

function Flower() {
  const petals = ["#e8657f", "#f0b03a", "#e0e0e0", "#c98adf"];
  return (
    <group>
      {[[0, 0], [0.22, 0.15], [-0.2, -0.1], [0.1, -0.22]].map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <mesh position={[0, 0.18, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 0.36, 4]} />
            <meshStandardMaterial color="#4f7a3a" />
          </mesh>
          <mesh position={[0, 0.38, 0]}>
            <icosahedronGeometry args={[0.1, 0]} />
            <meshStandardMaterial color={petals[i % petals.length]} emissive={petals[i % petals.length]} emissiveIntensity={0.25} flatShading />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function House() {
  return (
    <group>
      <mesh position={[0, 0.6, 0]} castShadow receiveShadow>
        <boxGeometry args={[1.6, 1.2, 1.4]} />
        <meshStandardMaterial color="#d9c9a3" roughness={0.9} />
      </mesh>
      <mesh position={[0, 1.5, 0]} rotation={[0, Math.PI / 4, 0]} castShadow>
        <coneGeometry args={[1.35, 0.9, 4]} />
        <meshStandardMaterial color="#a5543a" roughness={0.85} flatShading />
      </mesh>
      <mesh position={[0, 0.4, 0.71]}>
        <boxGeometry args={[0.4, 0.7, 0.05]} />
        <meshStandardMaterial color="#5a3f28" />
      </mesh>
      <mesh position={[0.5, 0.75, 0.71]}>
        <boxGeometry args={[0.35, 0.35, 0.05]} />
        <meshStandardMaterial color="#bfe0ea" emissive="#e0b45a" emissiveIntensity={0.4} />
      </mesh>
    </group>
  );
}

function Well() {
  return (
    <group>
      <mesh position={[0, 0.35, 0]} castShadow>
        <cylinderGeometry args={[0.5, 0.55, 0.7, 10]} />
        <meshStandardMaterial color="#8f9088" roughness={1} flatShading />
      </mesh>
      <mesh position={[0, 0.72, 0]}>
        <cylinderGeometry args={[0.4, 0.4, 0.1, 10]} />
        <meshStandardMaterial color="#3a5a6a" />
      </mesh>
      {[-0.5, 0.5].map((x) => (
        <mesh key={x} position={[x, 1.05, 0]} castShadow>
          <boxGeometry args={[0.1, 0.9, 0.1]} />
          <meshStandardMaterial color="#6f4e30" />
        </mesh>
      ))}
      <mesh position={[0, 1.55, 0]} rotation={[0, Math.PI / 4, 0]} castShadow>
        <coneGeometry args={[0.75, 0.5, 4]} />
        <meshStandardMaterial color="#a5543a" flatShading />
      </mesh>
    </group>
  );
}

function Lamp() {
  return (
    <group>
      <mesh position={[0, 0.75, 0]} castShadow>
        <cylinderGeometry args={[0.07, 0.1, 1.5, 6]} />
        <meshStandardMaterial color="#2c333a" metalness={0.5} roughness={0.5} />
      </mesh>
      <mesh position={[0, 1.55, 0]}>
        <icosahedronGeometry args={[0.22, 0]} />
        <meshStandardMaterial color="#ffe08a" emissive="#ffd36b" emissiveIntensity={1.6} toneMapped={false} />
      </mesh>
      <pointLight position={[0, 1.55, 0]} intensity={6} distance={7} color="#ffdf9e" />
    </group>
  );
}

// Idle-bobbing creatures (drift + hover animation like ambient wildlife).
function Deer() {
  return (
    <group>
      <mesh position={[0, 0.85, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <capsuleGeometry args={[0.28, 0.7, 4, 8]} />
        <meshStandardMaterial color="#b07a45" roughness={0.9} />
      </mesh>
      <mesh position={[0.5, 1.15, 0]} castShadow>
        <sphereGeometry args={[0.22, 10, 10]} />
        <meshStandardMaterial color="#c08a52" roughness={0.9} />
      </mesh>
      {[[0.58, 0.1], [0.58, -0.1]].map(([z, o], i) => (
        <mesh key={i} position={[z, 1.45, o]} rotation={[0, 0, -0.3]}>
          <coneGeometry args={[0.03, 0.3, 4]} />
          <meshStandardMaterial color="#8a6a3a" />
        </mesh>
      ))}
      {[[-0.3, 0.18], [-0.3, -0.18], [0.3, 0.18], [0.3, -0.18]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.35, z]} castShadow>
          <cylinderGeometry args={[0.06, 0.05, 0.7, 5]} />
          <meshStandardMaterial color="#7a5636" />
        </mesh>
      ))}
    </group>
  );
}

function Monster() {
  const eye = useRef<THREE.MeshStandardMaterial>(null);
  useFrame((s) => {
    if (getState().paused || !eye.current) return;
    eye.current.emissiveIntensity = 1.2 + Math.sin(s.clock.elapsedTime * 4) * 0.6;
  });
  return (
    <group>
      <mesh position={[0, 0.7, 0]} castShadow>
        <icosahedronGeometry args={[0.55, 0]} />
        <meshStandardMaterial color="#7a3b2a" emissive="#d64f2f" emissiveIntensity={0.5} flatShading />
      </mesh>
      <mesh position={[0.25, 0.85, 0.35]}>
        <sphereGeometry args={[0.12, 8, 8]} />
        <meshStandardMaterial ref={eye} color="#ffe08a" emissive="#ffcc55" emissiveIntensity={1.5} toneMapped={false} />
      </mesh>
      <mesh position={[-0.25, 0.85, 0.35]}>
        <sphereGeometry args={[0.12, 8, 8]} />
        <meshStandardMaterial color="#ffe08a" emissive="#ffcc55" emissiveIntensity={1.5} toneMapped={false} />
      </mesh>
      {[[-0.35, 0.5], [-0.35, -0.5], [0.35, 0.5], [0.35, -0.5]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.2, z]} castShadow>
          <coneGeometry args={[0.09, 0.4, 4]} />
          <meshStandardMaterial color="#5a2b1e" flatShading />
        </mesh>
      ))}
    </group>
  );
}

const MODELS: Record<PropKind, () => ReactElement> = {
  tree: Tree, pine: Pine, bush: Bush, rock: Rock, flower: Flower,
  house: House, well: Well, lamp: Lamp, monster: Monster, deer: Deer,
};

// A single placed prop, seated on the terrain with idle animation for creatures.
function PropModel({ p }: { p: PlacedProp }) {
  const g = useRef<THREE.Group>(null);
  const y = terrainHeight(p.x, p.z);
  const alive = p.kind === "monster" || p.kind === "deer";
  useFrame((s) => {
    if (!g.current || !alive || getState().paused) return;
    const t = s.clock.elapsedTime + p.x * 0.7 + p.z * 0.3;
    g.current.position.y = y + Math.abs(Math.sin(t * 1.4)) * 0.12;
    g.current.rotation.y = p.rot + Math.sin(t * 0.6) * 0.25;
  });
  const Model = MODELS[p.kind];
  return (
    <group ref={g} position={[p.x, y, p.z]} rotation={[0, p.rot, 0]} scale={p.scale}>
      <Model />
    </group>
  );
}

export function GodProps() {
  const props = useGame((s) => s.props);
  return (
    <group>
      {props.map((p) => <PropModel key={p.id} p={p} />)}
    </group>
  );
}
