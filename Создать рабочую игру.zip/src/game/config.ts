import type { Biome, BuildingKind, GameState, ItemKey, Ore, RawKey, ResKey } from "./types";

export const GRID = 120; // large open world
export const CELL = 2;
export const HALF = (GRID * CELL) / 2;
export const LEVEL_HEIGHT = 3; // world units between floors
export const MAX_LEVEL = 3;
export const POWER_LINK = 16; // max grid distance for a hub↔pylon / pylon↔pylon link

export const POLLUTION_THRESHOLD = 100;

export function cellToWorld(x: number, z: number): [number, number] {
  return [x * CELL - HALF + CELL / 2, z * CELL - HALF + CELL / 2];
}
export function worldToCell(wx: number, wz: number): [number, number] {
  return [Math.floor((wx + HALF) / CELL), Math.floor((wz + HALF) / CELL)];
}
// A single small river runs (roughly north–south) off to the east side of the
// map, gently meandering. Returns its centre X for a given Z.
export function riverCenterX(wz: number): number {
  return HALF * 0.42 + Math.sin(wz * 0.018) * 12 + Math.sin(wz * 0.05 + 1) * 4;
}
export const WATER_LEVEL = -0.55;
export const RIVER_HALF_WIDTH = 6; // narrow channel

// A wooden bridge spans the river near the map centre so the player can cross.
export const BRIDGE_Z = 0; // world-Z of the crossing
export const BRIDGE_CX = riverCenterX(BRIDGE_Z); // world-X centre of the bridge
export const BRIDGE_DECK_Y = 0.35; // deck sits just above the water

// How mountainous a point is: 0 across the open field, ramping to 1 along the
// far western edge where the range rises.
export function mountainMask(wx: number): number {
  const edge = -HALF * 0.32; // mountains begin west of this line
  const span = HALF * 0.62;
  return Math.max(0, Math.min(1, (edge - wx) / span));
}

// Open world: a broad walkable plain with a small carved river to the east and
// a rugged mountain range rising along the western edge (mostly decorative).
export function terrainHeight(wx: number, wz: number): number {
  // gentle rolling plain — low amplitude so it stays flat & buildable
  const field =
    Math.sin(wx * 0.028) * Math.cos(wz * 0.03) * 0.45 +
    Math.sin(wz * 0.05 + 0.6) * 0.22 + 0.35;

  // western mountain range: ridged peaks that climb toward the edge
  const m = mountainMask(wx);
  const ridged =
    (0.6 + 0.4 * Math.sin(wz * 0.09)) *
    (0.6 + 0.4 * Math.abs(Math.cos(wx * 0.055 + wz * 0.02)));
  const mountains = m * m * (5 + ridged * 12);

  // narrow river valley carved around riverCenterX (kept away from the bridge)
  const dist = Math.abs(wx - riverCenterX(wz));
  const valley = Math.max(0, 1 - dist / RIVER_HALF_WIDTH);
  const carve = valley * valley * 2.4;

  return field + mountains - carve;
}
export function isWater(wx: number, wz: number): boolean {
  return terrainHeight(wx, wz) < WATER_LEVEL;
}
export function isBuildable(cx: number, cz: number): boolean {
  if (cx < 0 || cz < 0 || cx >= GRID || cz >= GRID) return false;
  const [wx, wz] = cellToWorld(cx, cz);
  return !isWater(wx, wz); // can't build on open water
}

// ---- Biomes ----------------------------------------------------------------
// The world map hosts four regions. Switching biome re-skins the whole 3D scene
// (ground ramp, water, fog/sky bias, foliage tint & type, drifting particles)
// so the same base layout reads as forest / desert / snow / swamp.
export interface BiomeMeta {
  id: Biome;
  label: string;
  icon: string;
  blurb: string;
  // sky/atmosphere the scene tints toward
  sky: string;
  skyMix: number;      // how strongly to pull the day-cycle sky toward `sky`
  fogNear: number;
  fogFar: number;
  water: string;
  waterOpacity: number;
  // ground colour ramp (low waterbed → sand/shore → field → rock → peak)
  ground: { bed: string; shore: string; field: string; field2: string; rock: string; rockHi: string; peak: string };
  // foliage
  foliage: { hue: number; sat: number; lit: number; spread: number; frost: number }; // frost 0..1 = snow cap
  treeDensity: number; // 0..1 multiplier on how many trees appear
  rockTint: string;
  particle: { kind: "pollen" | "snow" | "sand" | "spore"; color: string };
  decor: "flowers" | "reeds" | "cacti" | "none"; // signature ground prop
  ambient: number;     // hemisphere light multiplier
  // gameplay modifiers so the biome you deploy into actually matters:
  // pollution accrual, energy output and horde size are each scaled.
  mod: { pollutionMul: number; powerMul: number; waveMul: number; label: string };
}

export const BIOMES: Record<Biome, BiomeMeta> = {
  forest: {
    id: "forest", label: "Лес", icon: "🌲", blurb: "Умеренный лес — исходная база.",
    sky: "#a7cfc6", skyMix: 0, fogNear: 95, fogFar: 320,
    water: "#3e86a8", waterOpacity: 0.82,
    ground: { bed: "#3f5b57", shore: "#b3a877", field: "#5d7d44", field2: "#6f8f52", rock: "#6d6a63", rockHi: "#8b8880", peak: "#eef2f4" },
    foliage: { hue: 0.22, sat: 0.55, lit: 0.32, spread: 0.14, frost: 0 },
    treeDensity: 1, rockTint: "#8d8f88",
    particle: { kind: "pollen", color: "#fff3b0" }, decor: "flowers", ambient: 1,
    mod: { pollutionMul: 1, powerMul: 1, waveMul: 1, label: "Баланс во всём — мягкий старт." },
  },
  desert: {
    id: "desert", label: "Пустыня", icon: "🏜", blurb: "Дюны, каньоны и кактусы. Знойно и сухо.",
    sky: "#e7c88a", skyMix: 0.55, fogNear: 120, fogFar: 360,
    water: "#6fa9b0", waterOpacity: 0.6,
    ground: { bed: "#9c8752", shore: "#d8c489", field: "#d9bd7c", field2: "#c9a95f", rock: "#a8895a", rockHi: "#caa877", peak: "#e6d3a4" },
    foliage: { hue: 0.13, sat: 0.4, lit: 0.36, spread: 0.05, frost: 0 },
    treeDensity: 0.18, rockTint: "#b08a5c",
    particle: { kind: "sand", color: "#e9d6a4" }, decor: "cacti", ambient: 1.15,
    mod: { pollutionMul: 1.35, powerMul: 1.2, waveMul: 1, label: "Зной: +20% энергии, но +35% загрязнения." },
  },
  snow: {
    id: "snow", label: "Снега", icon: "❄", blurb: "Заснеженные пики и мёрзлые пруды. Стужа.",
    sky: "#c3d6e2", skyMix: 0.6, fogNear: 70, fogFar: 260,
    water: "#8fb4c6", waterOpacity: 0.7,
    ground: { bed: "#7f97a4", shore: "#dfe7ec", field: "#e8eef2", field2: "#d6dfe6", rock: "#b7bec6", rockHi: "#dfe6ec", peak: "#ffffff" },
    foliage: { hue: 0.32, sat: 0.28, lit: 0.34, spread: 0.06, frost: 0.85 },
    treeDensity: 0.7, rockTint: "#c4ccd2",
    particle: { kind: "snow", color: "#ffffff" }, decor: "none", ambient: 1.1,
    mod: { pollutionMul: 0.8, powerMul: 0.85, waveMul: 1.3, label: "Стужа: воздух чище, энергии меньше, орда злее." },
  },
  swamp: {
    id: "swamp", label: "Болото", icon: "🐊", blurb: "Топи, кувшинки и туман. Влажно и мрачно.",
    sky: "#8fa08a", skyMix: 0.5, fogNear: 55, fogFar: 220,
    water: "#4a6b4e", waterOpacity: 0.78,
    ground: { bed: "#33432f", shore: "#5b6444", field: "#556b3e", field2: "#647245", rock: "#5a5f4c", rockHi: "#767a63", peak: "#c9d3c4" },
    foliage: { hue: 0.24, sat: 0.45, lit: 0.26, spread: 0.1, frost: 0 },
    treeDensity: 0.9, rockTint: "#6b7059",
    particle: { kind: "spore", color: "#bcd89a" }, decor: "reeds", ambient: 0.85,
    mod: { pollutionMul: 0.8, powerMul: 1, waveMul: 1.2, label: "Сырость чистит воздух, но топь кормит орду." },
  },
};

export const RAW_KEYS: RawKey[] = ["wood", "stone", "coal", "iron", "copper", "gold"];
export const ITEM_KEYS: ItemKey[] = ["plates", "gears", "ammo"];

export const RES_META: Record<string, { label: string; color: string; icon: string }> = {
  wood:   { label: "Дерево",   color: "#7a5a34", icon: "🪵" },
  stone:  { label: "Камень",   color: "#9a9a92", icon: "🪨" },
  coal:   { label: "Уголь",    color: "#2f2f33", icon: "⚫" },
  iron:   { label: "Железо",   color: "#8a97a0", icon: "⛏" },
  copper: { label: "Медь",     color: "#c07a3a", icon: "🟠" },
  gold:   { label: "Золото",   color: "#e0b93a", icon: "🟡" },
  plates: { label: "Пластины", color: "#c8873f", icon: "▬" },
  gears:  { label: "Винты",    color: "#a0a4ad", icon: "⚙" },
  ammo:   { label: "Патроны",  color: "#5a7a41", icon: "▮" },
};

export const ORE_COLOR: Record<Ore, string> = {
  iron: "#8a97a0", copper: "#c07a3a", coal: "#2f2f33", stone: "#9a9a92", gold: "#e0b93a", water: "#3e86a8",
};

export interface BuildingMeta {
  label: string;
  color: string;
  height: number;
  hotkey: string;
  desc: string;
  power: number;
  pollution: number;
  cost: Partial<Record<RawKey, number>>;
  tier: 1 | 2 | 3;
  radius?: number;
}

export const BUILDINGS: Record<BuildingKind, BuildingMeta> = {
  drill:     { label: "Бур",       color: "#c98a3c", height: 1.7, hotkey: "1", desc: "Авто-добыча с жилы",        power: -4,  pollution: 1.2, cost: { wood: 5, iron: 5 },  tier: 1 },
  conveyor:  { label: "Лента",     color: "#e0b45a", height: 0.4, hotkey: "2", desc: "Тяни ЛКМ, повороты авто",  power: -1,  pollution: 0.1, cost: { wood: 1 },           tier: 1 },
  splitter:  { label: "Развилка",  color: "#d0b060", height: 0.6, hotkey: "3", desc: "Делит поток на 3",          power: -1,  pollution: 0.1, cost: { wood: 3 },           tier: 1 },
  merger:    { label: "Слияние",   color: "#b09a50", height: 0.6, hotkey: "4", desc: "Сводит 3 потока в 1",       power: -1,  pollution: 0.1, cost: { wood: 3 },           tier: 1 },
  turret:    { label: "Баллиста",  color: "#b5563f", height: 1.3, hotkey: "5", desc: "Авто-оборона (радиус 8)",  power: -3,  pollution: 0.3, cost: { wood: 5, iron: 3 },  tier: 1, radius: 8 },
  smelter:   { label: "Печь",      color: "#d8823f", height: 1.6, hotkey: "6", desc: "Руда+уголь → пластины",    power: -6,  pollution: 2.0, cost: { stone: 8 },          tier: 2 },
  assembler: { label: "Мастерская",color: "#9d7bd0", height: 1.5, hotkey: "7", desc: "Пластины → винты/патроны", power: -5,  pollution: 1.5, cost: { wood: 10, iron: 5 }, tier: 2 },
  pump:      { label: "Мельница",  color: "#5aa5c4", height: 2.4, hotkey: "8", desc: "Эко-энергия",              power: 8,   pollution: -0.5, cost: { wood: 8 },          tier: 2 },
  pylon:     { label: "Столб",     color: "#7db56b", height: 2.2, hotkey: "9", desc: "Питание в радиусе 6",      power: 0,   pollution: 0,   cost: { wood: 6 },           tier: 2, radius: 6 },
  wall:      { label: "Частокол",  color: "#8a6f4e", height: 1.2, hotkey: "0", desc: "Барьер против орды",       power: 0,   pollution: 0,   cost: { wood: 2 },           tier: 1 },
  complex:   { label: "Лесопилка", color: "#caa15e", height: 2.2, hotkey: "-", desc: "Блюпринт-комплекс",        power: -12, pollution: 3.0, cost: { wood: 40, iron: 20 }, tier: 3 },
  hub:       { label: "Ратуша",    color: "#e8dcc0", height: 2.8, hotkey: "=", desc: "Ядро базы и генератор",    power: 20,  pollution: 0,   cost: {},                    tier: 1 },
  // Эко-ветка: чистая энергия и переработка — очищают воздух, но дают меньше сырья.
  waterwheel:{ label: "Вод. колесо",color:"#4fa3c7", height: 2.8, hotkey: "H", desc: "Гидро-энергия · чистит воздух", power: 12, pollution: -1.6, cost: { wood: 12, stone: 6 }, tier: 2 },
  recycler:  { label: "Компостер",  color: "#7bb04a", height: 1.5, hotkey: "J", desc: "Отходы → дерево · чистит воздух", power: -3, pollution: -3.0, cost: { wood: 10, iron: 4 },  tier: 2 },
  storage:   { label: "Склад",       color: "#b98a4e", height: 1.4, hotkey: "K", desc: "Приёмник грузов с лент",       power: 0,   pollution: 0,   cost: { wood: 8, stone: 4 }, tier: 1 },

  // ---- Строения (как в Satisfactory): ровный пол под заводик, колонны, пандусы ----
  found1:    { label: "Фундамент 1м",  color: "#c7c8bb", height: 0.5, hotkey: "F", desc: "Тонкий пол — ровное основание",     power: 0, pollution: 0, cost: { stone: 2 },          tier: 1 },
  found2:    { label: "Фундамент 2м",  color: "#c7c8bb", height: 1.0, hotkey: "F", desc: "Пол средней толщины",              power: 0, pollution: 0, cost: { stone: 4 },          tier: 1 },
  found4:    { label: "Фундамент 4м",  color: "#c7c8bb", height: 2.0, hotkey: "F", desc: "Толстый пол — выровнять склон",     power: 0, pollution: 0, cost: { stone: 8 },          tier: 1 },
  ramp:      { label: "Пандус",        color: "#c7c8bb", height: 1.5, hotkey: "G", desc: "Наклон — заезд на этаж",           power: 0, pollution: 0, cost: { stone: 4 },          tier: 1 },
  cramp:     { label: "Угл. пандус",   color: "#c7c8bb", height: 1.5, hotkey: "G", desc: "Диагональный подъём в угол",       power: 0, pollution: 0, cost: { stone: 4 },          tier: 1 },
  stairs:    { label: "Лестница",      color: "#c7c8bb", height: 1.5, hotkey: "G", desc: "Ступени наверх",                   power: 0, pollution: 0, cost: { stone: 4 },          tier: 1 },
  pillar:    { label: "Колонна",       color: "#b8b9ac", height: 3.0, hotkey: "V", desc: "Опора под верхние этажи",          power: 0, pollution: 0, cost: { stone: 3 },          tier: 1 },
  glass:     { label: "Стекло-пол",    color: "#bfe0ea", height: 0.4, hotkey: "B", desc: "Прозрачный пол в раме",            power: 0, pollution: 0, cost: { stone: 2, iron: 1 }, tier: 2 },
};

export const KIND_ORDER: BuildingKind[] = [
  "drill", "conveyor", "splitter", "merger", "turret", "smelter", "assembler", "pump", "pylon", "wall", "complex", "waterwheel", "recycler", "storage",
  "found1", "found2", "found4", "ramp", "cramp", "stairs", "pillar", "glass",
];

// Grouped build palette so the bottom bar reads as clear departments. Two
// contrasting production philosophies read at a glance: the grimy INDUSTRIAL
// chain (Производство: бур→печь→мастерская, много руды, но коптит) versus the
// clean ЭКО chain (мельницы, гидро-колёса, компостеры — меньше выход, но
// очищают воздух).
export const PALETTE_CATEGORIES: { label: string; icon: string; kinds: BuildingKind[] }[] = [
  { label: "Добыча", icon: "⛏", kinds: ["drill"] },
  { label: "Строения", icon: "🧱", kinds: ["found1", "found2", "found4", "ramp", "cramp", "stairs", "pillar", "glass"] },
  { label: "Логистика", icon: "🚚", kinds: ["conveyor", "splitter", "merger", "storage"] },
  { label: "Производство", icon: "🏭", kinds: ["smelter", "assembler", "complex"] },
  { label: "Экология", icon: "🌿", kinds: ["pump", "waterwheel", "recycler"] },
  { label: "Энергия", icon: "⚡", kinds: ["pylon"] },
  { label: "Оборона", icon: "🛡", kinds: ["turret", "wall"] },
];

// ---- Tech tree ----------------------------------------------------------
// Everything tier-1 is available from the start; advanced machines are gated
// behind research nodes bought with raw resources. Some nodes require an
// earlier node first, so the tree branches (industrial vs eco).
export const DEFAULT_UNLOCKED: BuildingKind[] = KIND_ORDER
  .filter((k) => BUILDINGS[k].tier === 1)
  .concat(["hub"]);

export interface Tech {
  id: string;
  name: string;
  icon: string;
  desc: string;
  cost: Partial<Record<RawKey, number>>;
  unlocks: BuildingKind[];
  requires: string[];
  // Optional passive bonus (no new building): raises belt throughput/capacity.
  effect?: { beltRate?: number; beltCap?: number; label: string };
}

export const TECHS: Tech[] = [
  { id: "smelting",   name: "Металлургия",  icon: "🔥", desc: "Плавка руды в пластины",       cost: { wood: 30, stone: 20 }, unlocks: ["smelter", "glass"],          requires: [] },
  { id: "power",      name: "Электросеть",  icon: "⚡", desc: "Столбы и мельницы — энергия",  cost: { wood: 30, iron: 15 },  unlocks: ["pylon", "pump"],             requires: [] },
  { id: "automation", name: "Автоматика",   icon: "🔧", desc: "Мастерские: винты и патроны",  cost: { iron: 30, stone: 20 }, unlocks: ["assembler"],                 requires: ["smelting"] },
  { id: "eco",        name: "Экология",     icon: "🌿", desc: "Гидро-энергия и переработка",  cost: { wood: 50, stone: 25 }, unlocks: ["waterwheel", "recycler"],    requires: ["power"] },
  { id: "logistics",  name: "Логистика",    icon: "🔗", desc: "Быстрые ленты: +пропускная способность и буфер", cost: { iron: 25, wood: 25 }, unlocks: [], requires: ["power"], effect: { beltRate: 2, beltCap: 6, label: "ленты: +2/т, +6 буфер" } },
  { id: "logistics2", name: "Экспресс-ленты", icon: "🚄", desc: "Ещё быстрее: удвоенный поток грузов", cost: { iron: 60, copper: 30 }, unlocks: [], requires: ["logistics"], effect: { beltRate: 3, beltCap: 8, label: "ленты: +3/т, +8 буфер" } },
  { id: "heavy",      name: "Тяжпром",      icon: "🏭", desc: "Комплексы-блюпринты",          cost: { iron: 60, wood: 60, stone: 40 }, unlocks: ["complex"],         requires: ["automation"] },
];

// God/creator mode catalog — decorative props the player can freely paint into
// the world, grouped into selectable sections in the creator toolbar.
export const PROP_CATALOG: {
  section: string; icon: string;
  items: { kind: import("./types").PropKind; label: string; glyph: string }[];
}[] = [
  {
    section: "Природа", icon: "🌲",
    items: [
      { kind: "tree", label: "Дерево", glyph: "🌳" },
      { kind: "pine", label: "Ель", glyph: "🌲" },
      { kind: "bush", label: "Куст", glyph: "🌿" },
      { kind: "rock", label: "Камень", glyph: "🪨" },
      { kind: "flower", label: "Цветы", glyph: "🌼" },
    ],
  },
  {
    section: "Строения", icon: "🏠",
    items: [
      { kind: "house", label: "Домик", glyph: "🏠" },
      { kind: "well", label: "Колодец", glyph: "⛲" },
      { kind: "lamp", label: "Фонарь", glyph: "🏮" },
    ],
  },
  {
    section: "Существа", icon: "🦌",
    items: [
      { kind: "deer", label: "Олень", glyph: "🦌" },
      { kind: "monster", label: "Монстр", glyph: "👹" },
    ],
  },
];

// Hand-crafted tools are upgradeable tiers: higher level → bigger yield.
// Tier 1 is crafted from loose sticks & pebbles found on the ground; later
// tiers use processed resources.
export interface ToolTier {
  level: number;
  cost: Partial<Record<RawKey, number>>;
  mats?: { stick?: number; pebble?: number };
  yield: number;
  label: string;
}
export const TOOL_TIERS: Record<"axe" | "pickaxe", ToolTier[]> = {
  axe: [
    { level: 1, label: "Топор", cost: {}, mats: { stick: 3, pebble: 2 }, yield: 8 },
    { level: 2, label: "Топор II (сталь)", cost: { wood: 20, iron: 8 }, yield: 16 },
    { level: 3, label: "Топор III (закалённый)", cost: { iron: 20, gold: 5 }, yield: 28 },
  ],
  pickaxe: [
    { level: 1, label: "Кирка", cost: {}, mats: { stick: 2, pebble: 3 }, yield: 3 },
    { level: 2, label: "Кирка II (сталь)", cost: { wood: 16, iron: 6 }, yield: 6 },
    { level: 3, label: "Кирка III (алмазная)", cost: { iron: 18, copper: 10 }, yield: 11 },
  ],
};

// ---- Objectives ------------------------------------------------------------
// A light quest chain that gives direction and teaches both production
// philosophies. Progress is derived from live state each tick; the first time
// an objective is satisfied it is banked (in state.completedObjectives) and its
// reward is paid out once.
export interface Objective {
  id: string;
  title: string;
  desc: string;
  goal: number;
  progress: (s: GameState) => number;
  reward: Partial<Record<ResKey, number>>;
}

const countKind = (s: GameState, k: BuildingKind) => s.buildings.filter((b) => b.kind === k).length;
const ecoCount = (s: GameState) => countKind(s, "pump") + countKind(s, "waterwheel") + countKind(s, "recycler");

export const OBJECTIVES: Objective[] = [
  { id: "tools", title: "Первые инструменты", desc: "Скрафтите топор и кирку (мастерская, C)", goal: 2,
    progress: (s) => (s.tools.axe > 0 ? 1 : 0) + (s.tools.pickaxe > 0 ? 1 : 0), reward: { wood: 40 } },
  { id: "lumber", title: "Заготовка леса", desc: "Накопите 120 древесины", goal: 120,
    progress: (s) => s.resources.wood, reward: { iron: 15 } },
  { id: "drills", title: "Добытчик", desc: "Постройте 3 бура на жилах", goal: 3,
    progress: (s) => countKind(s, "drill"), reward: { stone: 30 } },
  { id: "grid", title: "Энергосеть", desc: "Поставьте столб питания", goal: 1,
    progress: (s) => countKind(s, "pylon"), reward: { copper: 20 } },
  { id: "plates", title: "Металлургия", desc: "Выплавьте 20 пластин", goal: 20,
    progress: (s) => s.resources.plates, reward: { iron: 25 } },
  { id: "eco", title: "Зелёный путь", desc: "Постройте эко-станцию (мельница/колесо/компостер)", goal: 1,
    progress: (s) => ecoCount(s), reward: { gold: 6 } },
  { id: "defence", title: "Крепость Грани", desc: "Возведите 4 частокола", goal: 4,
    progress: (s) => countKind(s, "wall"), reward: { iron: 30 } },
  { id: "clean", title: "Чистое небо", desc: "Держите загрязнение ниже 20 при 2+ эко-станциях", goal: 1,
    progress: (s) => (ecoCount(s) >= 2 && s.pollution < 20 ? 1 : 0), reward: { gold: 12 } },
];

// ---- Hotbar ----------------------------------------------------------------
// A Minecraft-style tool belt. Crafted tools & the blaster live in these slots;
// the active slot is what the avatar holds and what E/fire uses.
export const HOTBAR_SIZE = 6;
export const HOTBAR_ITEMS: Record<string, { icon: string; label: string }> = {
  blaster:  { icon: "🔫", label: "Бластер" },
  axe:      { icon: "🪓", label: "Топор" },
  pickaxe:  { icon: "⛏", label: "Кирка" },
};

// Repositionable HUD widgets exposed in the interface-customization editor.
export const HUD_ELEMENTS: { id: string; label: string }[] = [
  { id: "title", label: "Заголовок и статус" },
  { id: "resources", label: "Панель ресурсов" },
  { id: "toolbar", label: "Кнопки-иконки" },
  { id: "minimap", label: "Мини-карта" },
];

export const SAVE_KEY = "vanguard-grid-save-v2";
export const BLUEPRINT_KEY = "vanguard-grid-blueprints-v2";
