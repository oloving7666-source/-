import { GRID } from "./config";
import type { Cell } from "./types";

const key = (x: number, z: number) => x * GRID + z;

// 4-directional A* over the build grid. `blocked` holds impassable cells
// (walls & structures); the goal cell is always treated as reachable.
export function findPath(start: Cell, goal: Cell, blocked: Set<number>): Cell[] {
  const goalK = key(goal.x, goal.z);
  const startK = key(start.x, start.z);
  const open = new Map<number, number>(); // cell -> fScore
  const came = new Map<number, number>();
  const g = new Map<number, number>();
  g.set(startK, 0);
  open.set(startK, heur(start, goal));

  const cellOf = (k: number): Cell => ({ x: Math.floor(k / GRID), z: k % GRID });

  let guard = 0;
  while (open.size && guard++ < GRID * GRID) {
    // pick lowest fScore
    let cur = -1, best = Infinity;
    for (const [k, f] of open) if (f < best) { best = f; cur = k; }
    if (cur === goalK) return reconstruct(came, cur, cellOf);
    open.delete(cur);
    const c = cellOf(cur);
    const gc = g.get(cur)!;
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = c.x + dx, nz = c.z + dz;
      if (nx < 0 || nz < 0 || nx >= GRID || nz >= GRID) continue;
      const nk = key(nx, nz);
      if (blocked.has(nk) && nk !== goalK) continue;
      const tentative = gc + 1;
      if (tentative < (g.get(nk) ?? Infinity)) {
        came.set(nk, cur);
        g.set(nk, tentative);
        open.set(nk, tentative + heur({ x: nx, z: nz }, goal));
      }
    }
  }
  return []; // no path (fall back to straight line)
}

function heur(a: Cell, b: Cell) {
  return Math.abs(a.x - b.x) + Math.abs(a.z - b.z);
}
function reconstruct(came: Map<number, number>, cur: number, cellOf: (k: number) => Cell): Cell[] {
  const path = [cellOf(cur)];
  while (came.has(cur)) {
    cur = came.get(cur)!;
    path.unshift(cellOf(cur));
  }
  return path;
}
