import { useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { BIOMES, BRIDGE_CX, BRIDGE_DECK_Y, BRIDGE_Z, HALF, POLLUTION_THRESHOLD, RIVER_HALF_WIDTH, WATER_LEVEL, isWater, mountainMask, riverCenterX, terrainHeight } from "./config";
import type { BiomeMeta } from "./config";
import { getState, useGame } from "./store";
import { audio } from "./audio";
import { daytime } from "./daynight";
import type { Tree } from "./types";

const STORM = { sky: new THREE.Color("#3a3226"), sun: new THREE.Color("#ffb14e") };
const SMOG = new THREE.Color("#9c8a5e"); // muddy haze the sky drifts toward as pollution climbs
const RAIN_SKY = new THREE.Color("#6a747a"); // cool overcast the sky drifts toward in rain

// Time-of-day palettes cycled by a continuous clock (0..1 = one full day).
const SKY_STOPS: [number, string][] = [
  [0.0, "#0e1220"], [0.20, "#141a2c"], [0.27, "#e9a066"], [0.35, "#a7cfc6"],
  [0.65, "#a7cfc6"], [0.73, "#e08a52"], [0.82, "#141a2c"], [1.0, "#0e1220"],
];
const SUN_STOPS: [number, string][] = [
  [0.0, "#2a3a5a"], [0.24, "#3a4a6a"], [0.30, "#ffcf9a"], [0.40, "#fff4dc"],
  [0.60, "#fff4dc"], [0.74, "#ff9a5a"], [0.82, "#3a4a6a"], [1.0, "#2a3a5a"],
];
const _cA = new THREE.Color(), _cB = new THREE.Color();
function gradient(stops: [number, string][], t: number, out: THREE.Color) {
  t = ((t % 1) + 1) % 1;
  for (let i = 0; i < stops.length - 1; i++) {
    const [t0, c0] = stops[i], [t1, c1] = stops[i + 1];
    if (t >= t0 && t <= t1) {
      const f = (t - t0) / (t1 - t0 || 1);
      return out.copy(_cA.set(c0)).lerp(_cB.set(c1), f);
    }
  }
  return out.set(stops[stops.length - 1][1]);
}

function seeded(seed: number) {
  return () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
}

function Ground({ b }: { b: BiomeMeta }) {
  const geo = useMemo(() => {
    const g = new THREE.PlaneGeometry(HALF * 2.4, HALF * 2.4, 200, 200);
    g.rotateX(-Math.PI / 2);
    const pos = g.attributes.position;
    const colors: number[] = [];
    const grass = new THREE.Color(b.ground.field);
    const grass2 = new THREE.Color(b.ground.field2);
    const sand = new THREE.Color(b.ground.shore);
    const bed = new THREE.Color(b.ground.bed);
    const rock = new THREE.Color(b.ground.rock);
    const rockHi = new THREE.Color(b.ground.rockHi);
    const snow = new THREE.Color(b.ground.peak);
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      const h = terrainHeight(x, z);
      pos.setY(i, h);
      let c: THREE.Color;
      if (h < WATER_LEVEL - 0.3) c = bed;
      else if (h < WATER_LEVEL + 0.4) c = sand;
      else if (h > 8.5) c = snow;                                    // mountain peaks
      else if (h > 4) c = rock.clone().lerp(rockHi, (h - 4) / 4.5);  // rocky slopes
      else if (h > 2.2) c = grass2.clone().lerp(rock, (h - 2.2) / 1.8); // treeline
      else c = grass.clone().lerp(grass2, (Math.sin(x * 0.3) + 1) / 2 * 0.6 + Math.min(0.4, h * 0.15));
      colors.push(c.r, c.g, c.b);
    }
    g.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
    g.computeVertexNormals();
    return g;
  }, [b]);
  return (
    <mesh geometry={geo} receiveShadow>
      <meshStandardMaterial vertexColors roughness={1} />
    </mesh>
  );
}

// Big translucent water sheet at the waterline; terrain above it hides it, so
// only the river & low basins read as water. Gentle animated ripples.
function Water({ b }: { b: BiomeMeta }) {
  const ref = useRef<THREE.Mesh>(null);
  const geo = useMemo(() => {
    const g = new THREE.PlaneGeometry(HALF * 2.4, HALF * 2.4, 90, 90);
    g.rotateX(-Math.PI / 2);
    return g;
  }, []);
  useFrame((s) => {
    if (getState().paused) return;
    const t = s.clock.elapsedTime;
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      pos.setY(i, WATER_LEVEL + Math.sin(x * 0.25 + t * 1.3) * 0.08 + Math.cos(z * 0.3 + t) * 0.08);
    }
    pos.needsUpdate = true;
  });
  return (
    <mesh ref={ref} geometry={geo}>
      <meshStandardMaterial color={b.water} transparent opacity={b.waterOpacity} metalness={0.5} roughness={0.15} />
    </mesh>
  );
}

// Drifting motes of light — pollen by day, embers during a storm.
function Particles({ count, storm, b }: { count: number; storm: boolean; b: BiomeMeta }) {
  const ref = useRef<THREE.Points>(null);
  const falling = b.particle.kind === "snow";
  const data = useMemo(() => {
    const rnd = seeded(9001);
    const pos = new Float32Array(count * 3);
    const seeds = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (rnd() - 0.5) * HALF * 1.6;
      pos[i * 3 + 1] = 1 + rnd() * 8;
      pos[i * 3 + 2] = (rnd() - 0.5) * HALF * 1.6;
      seeds[i] = rnd() * 100;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return { geo, seeds, pos };
  }, [count]);
  useFrame((s) => {
    if (getState().paused) return;
    const t = s.clock.elapsedTime;
    const arr = data.pos;
    for (let i = 0; i < count; i++) {
      if (falling) {
        arr[i * 3 + 1] -= 0.04 + Math.sin(data.seeds[i]) * 0.01;   // snow drifts down
        if (arr[i * 3 + 1] < 0) arr[i * 3 + 1] = 9 + Math.random();
        arr[i * 3] += Math.sin(t * 0.8 + data.seeds[i]) * 0.02;    // gentle lateral sway
      } else {
        arr[i * 3 + 1] += Math.sin(t + data.seeds[i]) * 0.004 + 0.006;
        if (arr[i * 3 + 1] > 10) arr[i * 3 + 1] = 1;
        arr[i * 3] += Math.sin(t * 0.5 + data.seeds[i]) * 0.006;
      }
    }
    data.geo.attributes.position.needsUpdate = true;
    if (ref.current) ref.current.rotation.y = t * 0.01;
  });
  const col = storm ? "#ff9a4e" : b.particle.color;
  const size = falling ? 0.4 : b.particle.kind === "sand" ? 0.16 : storm ? 0.35 : 0.22;
  return (
    <points ref={ref} geometry={data.geo}>
      <pointsMaterial size={size} color={col} transparent opacity={falling ? 0.95 : 0.85} sizeAttenuation depthWrite={false} />
    </points>
  );
}

// Falling rain — vertical streaks recycling from the sky to the ground, drawn
// as line segments so drops read as streaks rather than dots.
function Rain({ count }: { count: number }) {
  const ref = useRef<THREE.LineSegments>(null);
  const data = useMemo(() => {
    const rnd = seeded(6161);
    const pos = new Float32Array(count * 6); // two verts per drop
    const yv = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      const x = (rnd() - 0.5) * HALF * 1.8;
      const y = rnd() * 40;
      const z = (rnd() - 0.5) * HALF * 1.8;
      const len = 0.8 + rnd() * 0.6;
      pos[i * 6] = x; pos[i * 6 + 1] = y; pos[i * 6 + 2] = z;
      pos[i * 6 + 3] = x; pos[i * 6 + 4] = y + len; pos[i * 6 + 5] = z;
      yv[i] = 0;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return { geo, pos, yv };
  }, [count]);
  useFrame((_, delta) => {
    if (getState().paused) return;
    const arr = data.pos;
    const fall = delta * 42;
    for (let i = 0; i < count; i++) {
      arr[i * 6 + 1] -= fall; arr[i * 6 + 4] -= fall;
      if (arr[i * 6 + 1] < 0) { const dy = 40 + Math.random() * 6; arr[i * 6 + 1] += dy; arr[i * 6 + 4] += dy; }
    }
    data.geo.attributes.position.needsUpdate = true;
  });
  return (
    <lineSegments ref={ref} geometry={data.geo}>
      <lineBasicMaterial color="#bcd0da" transparent opacity={0.35} />
    </lineSegments>
  );
}

// Instanced trees — one draw call per layer (trunk + two canopy cones) instead
// of ~3 meshes per tree, so hundreds of trees stay cheap. A per-frame sway is
// applied by rebuilding each instance matrix.
const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const _pos = new THREE.Vector3();
const _scl = new THREE.Vector3();
function Trees({ trees, shadows, b }: { trees: Tree[]; shadows: boolean; b: BiomeMeta }) {
  const trunk = useRef<THREE.InstancedMesh>(null);
  const c1 = useRef<THREE.InstancedMesh>(null);
  const c2 = useRef<THREE.InstancedMesh>(null);

  // Per-tree static params derived from the id (base y, rotation, tint, scale).
  // Foliage hue/spread comes from the active biome, so the same forest reads as
  // snowy pines, dry desert scrub or dark swamp growth.
  const fo = b.foliage;
  const frost = new THREE.Color("#eef4f8");
  const data = useMemo(() => trees.map((t) => {
    const h = (t.id.charCodeAt(1) * 37 + (t.id.charCodeAt(2) || 7) * 13) % 100;
    const rr = h / 100;
    const hue = fo.hue + rr * fo.spread;
    const sat = fo.sat + (h % 17) / 60;
    const lit = fo.lit + (h % 23) / 110;
    const tint = new THREE.Color().setHSL(hue, sat, lit);
    // in temperate forest a few trees lean warm (early autumn) for variety
    if (b.id === "forest" && h % 11 === 0) tint.setHSL(0.11 + rr * 0.05, 0.55, 0.4);
    const trunkTint = new THREE.Color().setHSL(0.08, 0.35, 0.18 + (h % 7) / 60);
    return { x: t.x, y: terrainHeight(t.x, t.z), z: t.z, rot: h, s: t.s, slim: 0.8 + (h % 30) / 55, tint, trunkTint };
  }), [trees, b]);

  // Bake per-instance colours (re-bake when the biome/data changes).
  useEffect(() => {
    for (let i = 0; i < data.length; i++) {
      trunk.current?.setColorAt(i, data[i].trunkTint);
      const lower = data[i].tint.clone().offsetHSL(0, 0, -0.04);
      const crown = data[i].tint.clone().offsetHSL(0, -0.05, 0.08);
      if (fo.frost > 0) { lower.lerp(frost, fo.frost * 0.5); crown.lerp(frost, fo.frost); } // snow-capped
      c1.current?.setColorAt(i, lower);
      c2.current?.setColorAt(i, crown);
    }
    [trunk, c1, c2].forEach((r) => { if (r.current?.instanceColor) r.current.instanceColor.needsUpdate = true; });
  }, [data]);

  useFrame((s) => {
    if (getState().paused || !trunk.current) return;
    const t = s.clock.elapsedTime;
    for (let i = 0; i < data.length; i++) {
      const d = data[i];
      const sway = Math.sin(t * 0.9 + d.x * 0.25 + d.z * 0.15) * 0.035;
      _e.set(0, d.rot, sway);
      _q.setFromEuler(_e);
      _pos.set(d.x, d.y, d.z);
      _scl.set(d.s, d.s, d.s);
      _m.compose(_pos, _q, _scl);
      trunk.current!.setMatrixAt(i, _m);
      c1.current!.setMatrixAt(i, _m);
      c2.current!.setMatrixAt(i, _m);
      // per-instance canopy width (slim) folded via a second compose pass
      _scl.set(d.s * d.slim, d.s, d.s * d.slim);
      _m.compose(_pos, _q, _scl);
      c1.current!.setMatrixAt(i, _m);
      c2.current!.setMatrixAt(i, _m);
    }
    trunk.current.instanceMatrix.needsUpdate = true;
    if (c1.current) c1.current.instanceMatrix.needsUpdate = true;
    if (c2.current) c2.current.instanceMatrix.needsUpdate = true;
  });

  // Geometries carry their local height offset (instances share one matrix).
  const geo = useMemo(() => {
    const g0 = new THREE.CylinderGeometry(0.14, 0.22, 1.05, 6); g0.translate(0, 0.5, 0);
    const g1 = new THREE.ConeGeometry(0.9, 1.6, 7); g1.translate(0, 1.7, 0);
    const g2 = new THREE.ConeGeometry(0.65, 1.2, 7); g2.translate(0, 2.5, 0);
    return [g0, g1, g2] as const;
  }, []);
  const mat = useMemo(() => [
    new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 1 }),
    new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 1 }),
    new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 1 }),
  ] as const, []);

  const n = data.length;
  if (n === 0) return null;
  return (
    <group>
      <instancedMesh ref={trunk} args={[undefined, undefined, n]} castShadow={shadows}>
        <primitive object={geo[0]} attach="geometry" />
        <primitive object={mat[0]} attach="material" />
      </instancedMesh>
      <instancedMesh ref={c1} args={[undefined, undefined, n]} castShadow={shadows}>
        <primitive object={geo[1]} attach="geometry" />
        <primitive object={mat[1]} attach="material" />
      </instancedMesh>
      <instancedMesh ref={c2} args={[undefined, undefined, n]} castShadow={shadows}>
        <primitive object={geo[2]} attach="geometry" />
        <primitive object={mat[2]} attach="material" />
      </instancedMesh>
    </group>
  );
}

// Decorative (non-minable) boulders scattered on dry land.
function Rocks({ count, b }: { count: number; b: BiomeMeta }) {
  // Boulders spawn in clusters: a large anchor stone with a few smaller
  // companions scattered around it, like a natural outcrop.
  const rocks = useMemo(() => {
    const rnd = seeded(77123);
    const out: { x: number; z: number; s: number; r: number; tilt: number; grey: number }[] = [];
    const clusters = Math.max(3, Math.round(count / 4));
    for (let c = 0; c < clusters && out.length < count; c++) {
      const cx = (rnd() - 0.5) * HALF * 1.9;
      const cz = (rnd() - 0.5) * HALF * 1.9;
      if (isWater(cx, cz)) continue;
      const members = 2 + Math.floor(rnd() * 4);
      for (let m = 0; m < members && out.length < count; m++) {
        const a = rnd() * Math.PI * 2;
        const d = m === 0 ? 0 : (0.6 + rnd() * 2.2);
        const x = cx + Math.cos(a) * d;
        const z = cz + Math.sin(a) * d;
        if (isWater(x, z)) continue;
        out.push({
          x, z,
          s: (m === 0 ? 1.3 + rnd() * 1.8 : 0.4 + rnd() * 1.1),
          r: rnd() * Math.PI,
          tilt: (rnd() - 0.5) * 0.5,
          grey: rnd(),
        });
      }
    }
    return out;
  }, [count]);
  const ref = useRef<THREE.InstancedMesh>(null);
  useEffect(() => {
    if (!ref.current) return;
    for (let i = 0; i < rocks.length; i++) {
      const r = rocks[i];
      _e.set(r.tilt, r.r * 2, r.tilt * 0.7);
      _q.setFromEuler(_e);
      _pos.set(r.x, terrainHeight(r.x, r.z) + r.s * 0.18, r.z);
      _scl.set(r.s, r.s * (0.7 + r.grey * 0.4), r.s);
      _m.compose(_pos, _q, _scl);
      ref.current.setMatrixAt(i, _m);
      // grey → mossy: lerp a cool stone grey toward a green-tinted damp stone
      const base = new THREE.Color().setHSL(0.28, 0.12, 0.34 + r.grey * 0.18);
      const stone = new THREE.Color(b.rockTint);
      base.lerp(stone, 0.45 + r.grey * 0.4);
      ref.current.setColorAt(i, base);
    }
    ref.current.instanceMatrix.needsUpdate = true;
    if (ref.current.instanceColor) ref.current.instanceColor.needsUpdate = true;
  }, [rocks, b]);
  if (rocks.length === 0) return null;
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, rocks.length]} castShadow receiveShadow>
      <dodecahedronGeometry args={[0.6, 0]} />
      <meshStandardMaterial roughness={0.95} metalness={0.02} />
    </instancedMesh>
  );
}

// Cheap grass tufts for ground texture.
function Grass({ count }: { count: number }) {
  const blades = useMemo(() => {
    const rnd = seeded(4242);
    const out: { x: number; z: number; s: number }[] = [];
    for (let i = 0; i < count * 3 && out.length < count; i++) {
      const x = (rnd() - 0.5) * HALF * 1.85;
      const z = (rnd() - 0.5) * HALF * 1.85;
      if (isWater(x, z)) continue;
      out.push({ x, z, s: 0.6 + rnd() });
    }
    return out;
  }, [count]);
  const grp = useRef<THREE.Group>(null);
  useFrame((s) => {
    if (getState().paused || !grp.current) return;
    const t = s.clock.elapsedTime;
    grp.current.children.forEach((c) => {
      c.rotation.z = Math.sin(t * 1.6 + c.position.x * 0.6) * 0.18;
    });
  });
  return (
    <group ref={grp}>
      {blades.map((b, i) => (
        <mesh key={i} position={[b.x, terrainHeight(b.x, b.z) + 0.2 * b.s, b.z]} scale={[1, b.s, 1]}>
          <coneGeometry args={[0.12, 0.5, 4]} />
          <meshStandardMaterial color="#6f9a4a" roughness={1} />
        </mesh>
      ))}
    </group>
  );
}

// Night sky — a fixed dome of stars that fades in after dusk.
function Stars() {
  const mat = useRef<THREE.PointsMaterial>(null);
  const geo = useMemo(() => {
    const rnd = seeded(31337);
    const n = 600;
    const pos = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const r = HALF * 1.7;
      const theta = rnd() * Math.PI * 2;
      const phi = rnd() * Math.PI * 0.42; // upper dome only
      pos[i * 3] = Math.cos(theta) * Math.sin(phi) * r;
      pos[i * 3 + 1] = Math.cos(phi) * r + 20;
      pos[i * 3 + 2] = Math.sin(theta) * Math.sin(phi) * r;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    return g;
  }, []);
  useFrame(() => { if (mat.current) mat.current.opacity = daytime.night; });
  return (
    <points geometry={geo}>
      <pointsMaterial ref={mat} size={0.7} color="#dfe7ff" transparent opacity={0} sizeAttenuation depthWrite={false} />
    </points>
  );
}

// Soft low-poly clouds drifting slowly across the sky.
function Clouds() {
  const grp = useRef<THREE.Group>(null);
  const puffs = useMemo(() => {
    const rnd = seeded(8842);
    return Array.from({ length: 10 }, () => ({
      x: (rnd() - 0.5) * HALF * 2,
      y: 26 + rnd() * 12,
      z: (rnd() - 0.5) * HALF * 2,
      s: 4 + rnd() * 6,
      speed: 0.4 + rnd() * 0.5,
      lobes: Array.from({ length: 4 + Math.floor(rnd() * 3) }, () => [(rnd() - 0.5) * 2.4, (rnd() - 0.5) * 0.6, (rnd() - 0.5) * 1.6, 0.6 + rnd() * 0.6] as const),
    }));
  }, []);
  useFrame((_, delta) => {
    if (getState().paused || !grp.current) return;
    grp.current.children.forEach((c, i) => {
      c.position.x += puffs[i].speed * delta;
      if (c.position.x > HALF * 1.1) c.position.x = -HALF * 1.1;
    });
  });
  return (
    <group ref={grp}>
      {puffs.map((p, i) => (
        <group key={i} position={[p.x, p.y, p.z]} scale={p.s}>
          {p.lobes.map(([lx, ly, lz, ls], j) => (
            <mesh key={j} position={[lx, ly, lz]} scale={[ls, ls * 0.6, ls]}>
              <dodecahedronGeometry args={[1, 0]} />
              <meshStandardMaterial color="#f5f7f6" roughness={1} transparent opacity={0.85} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

// A small flock of birds lazily circling the plains.
function Birds() {
  const grp = useRef<THREE.Group>(null);
  const birds = useMemo(() => {
    const rnd = seeded(551);
    return Array.from({ length: 7 }, () => ({ r: 14 + rnd() * 22, h: 14 + rnd() * 8, off: rnd() * Math.PI * 2, sp: 0.25 + rnd() * 0.2, flap: rnd() * 10 }));
  }, []);
  const refs = useRef<(THREE.Group | null)[]>([]);
  useFrame((s) => {
    if (getState().paused) return;
    const t = s.clock.elapsedTime;
    birds.forEach((b, i) => {
      const g = refs.current[i];
      if (!g) return;
      const a = t * b.sp + b.off;
      g.position.set(Math.cos(a) * b.r, b.h + Math.sin(t + b.off) * 1.2, Math.sin(a) * b.r);
      g.rotation.y = -a + Math.PI / 2;
      const flap = Math.sin(t * 8 + b.flap) * 0.5;
      (g.children[0] as THREE.Mesh).rotation.z = 0.3 + flap;
      (g.children[1] as THREE.Mesh).rotation.z = -0.3 - flap;
    });
  });
  return (
    <group ref={grp}>
      {birds.map((_, i) => (
        <group key={i} ref={(el) => { refs.current[i] = el; }}>
          {[1, -1].map((s) => (
            <mesh key={s} position={[0, 0, 0]}>
              <boxGeometry args={[0.9, 0.04, 0.28]} />
              <meshStandardMaterial color="#2a2f26" />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

// Deer wandering the open field — gentle Timberborn-style wildlife.
function Deer() {
  const deer = useMemo(() => {
    const rnd = seeded(9090);
    const out: { x: number; z: number; dir: number; sp: number }[] = [];
    for (let i = 0; i < 6; i++) {
      let x = 0, z = 0, ok = false;
      for (let tries = 0; tries < 40 && !ok; tries++) {
        x = (rnd() - 0.5) * HALF * 1.2;
        z = (rnd() - 0.5) * HALF * 1.4;
        ok = !isWater(x, z) && mountainMask(x) < 0.15 && Math.hypot(x, z) > 12;
      }
      out.push({ x, z, dir: rnd() * Math.PI * 2, sp: 0.6 + rnd() * 0.7 });
    }
    return out;
  }, []);
  const refs = useRef<(THREE.Group | null)[]>([]);
  const st = useRef(deer.map((d) => ({ ...d, turn: 0 })));
  useFrame((s, delta) => {
    if (getState().paused) return;
    st.current.forEach((d, i) => {
      const g = refs.current[i];
      if (!g) return;
      d.turn += (Math.sin(s.clock.elapsedTime * 0.3 + i) - 0.5) * delta * 0.6;
      d.dir += d.turn * delta;
      const nx = d.x + Math.sin(d.dir) * d.sp * delta;
      const nz = d.z + Math.cos(d.dir) * d.sp * delta;
      if (!isWater(nx, nz) && mountainMask(nx) < 0.2 && Math.abs(nx) < HALF * 0.9 && Math.abs(nz) < HALF * 0.9) { d.x = nx; d.z = nz; }
      else d.dir += Math.PI * 0.7;
      g.position.set(d.x, terrainHeight(d.x, d.z), d.z);
      g.rotation.y = d.dir;
      g.position.y += Math.abs(Math.sin(s.clock.elapsedTime * 4 + i)) * 0.06; // gentle bob
    });
  });
  return (
    <group>
      {deer.map((_, i) => (
        <group key={i} ref={(el) => { refs.current[i] = el; }}>
          <mesh position={[0, 0.7, 0]} castShadow>
            <boxGeometry args={[0.4, 0.42, 1]} />
            <meshStandardMaterial color="#9a6b43" roughness={1} />
          </mesh>
          <mesh position={[0, 1.0, 0.55]} castShadow>
            <boxGeometry args={[0.26, 0.4, 0.3]} />
            <meshStandardMaterial color="#8a5f3a" roughness={1} />
          </mesh>
          {[[0.12, 0.4], [-0.12, 0.4], [0.12, -0.4], [-0.12, -0.4]].map(([lx, lz], j) => (
            <mesh key={j} position={[lx, 0.25, lz]}>
              <boxGeometry args={[0.1, 0.5, 0.1]} />
              <meshStandardMaterial color="#6f4a2c" roughness={1} />
            </mesh>
          ))}
          {[1, -1].map((s) => (
            <mesh key={s} position={[s * 0.1, 1.35, 0.55]} rotation={[0, 0, s * 0.4]}>
              <boxGeometry args={[0.04, 0.3, 0.04]} />
              <meshStandardMaterial color="#e6ddc8" />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

// Reeds clustered along the river shoreline.
function Reeds() {
  const reeds = useMemo(() => {
    const rnd = seeded(2024);
    const out: { x: number; z: number; s: number }[] = [];
    for (let z = -HALF; z < HALF && out.length < 260; z += 2.5) {
      const cx = riverCenterX(z);
      for (let k = 0; k < 3; k++) {
        const side = k === 2 ? 0 : (rnd() < 0.5 ? -1 : 1);
        const x = cx + side * (RIVER_HALF_WIDTH + 0.5 + rnd() * 1.5);
        const h = terrainHeight(x, z);
        if (h > WATER_LEVEL - 0.1 && h < WATER_LEVEL + 0.7) out.push({ x, z, s: 0.7 + rnd() * 0.8 });
      }
    }
    return out;
  }, []);
  const grp = useRef<THREE.Group>(null);
  useFrame((s) => {
    if (getState().paused || !grp.current) return;
    const t = s.clock.elapsedTime;
    grp.current.children.forEach((c) => {
      c.rotation.z = 0.05 + Math.sin(t * 1.2 + c.position.z * 0.4) * 0.12;
    });
  });
  return (
    <group ref={grp}>
      {reeds.map((r, i) => (
        <group key={i} position={[r.x, terrainHeight(r.x, r.z), r.z]}>
          {[0, 1, 2].map((j) => (
            <mesh key={j} position={[(j - 1) * 0.12, 0.5 * r.s, (j - 1) * 0.1]} rotation={[0, 0, (j - 1) * 0.12]}>
              <cylinderGeometry args={[0.025, 0.04, 1 * r.s, 4]} />
              <meshStandardMaterial color="#7a8a3a" roughness={1} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

// Saguaro-style cacti dotting the desert — a trunk with a couple of raised arms.
function Cacti({ count, shadows }: { count: number; shadows: boolean }) {
  const cacti = useMemo(() => {
    const rnd = seeded(3131);
    const out: { x: number; z: number; s: number; arms: number; rot: number }[] = [];
    for (let i = 0; i < count * 4 && out.length < count; i++) {
      const x = (rnd() - 0.5) * HALF * 1.8;
      const z = (rnd() - 0.5) * HALF * 1.8;
      if (isWater(x, z) || mountainMask(x) > 0.2) continue;
      out.push({ x, z, s: 0.8 + rnd() * 1.1, arms: Math.floor(rnd() * 3), rot: rnd() * Math.PI });
    }
    return out;
  }, [count]);
  const mat = useMemo(() => new THREE.MeshStandardMaterial({ color: "#4f7a45", roughness: 0.9 }), []);
  return (
    <group>
      {cacti.map((c, i) => (
        <group key={i} position={[c.x, terrainHeight(c.x, c.z), c.z]} rotation={[0, c.rot, 0]}>
          <mesh position={[0, 0.9 * c.s, 0]} castShadow={shadows} material={mat}>
            <cylinderGeometry args={[0.16 * c.s, 0.2 * c.s, 1.8 * c.s, 7]} />
          </mesh>
          {Array.from({ length: c.arms }).map((_, j) => {
            const side = j % 2 === 0 ? 1 : -1;
            return (
              <group key={j} position={[0.14 * c.s * side, (0.8 + j * 0.35) * c.s, 0]}>
                <mesh position={[0.16 * c.s * side, 0, 0]} rotation={[0, 0, -side * 0.5]} material={mat}>
                  <cylinderGeometry args={[0.07 * c.s, 0.08 * c.s, 0.5 * c.s, 6]} />
                </mesh>
                <mesh position={[0.32 * c.s * side, 0.22 * c.s, 0]} material={mat}>
                  <cylinderGeometry args={[0.07 * c.s, 0.08 * c.s, 0.55 * c.s, 6]} />
                </mesh>
              </group>
            );
          })}
        </group>
      ))}
    </group>
  );
}

// Scattered wildflowers dotting the plains.
function Flowers({ count }: { count: number }) {
  const flowers = useMemo(() => {
    const rnd = seeded(1357);
    const cols = ["#e4626f", "#e8c14a", "#d68ad0", "#f4f0e6"];
    const out: { x: number; z: number; c: string }[] = [];
    for (let i = 0; i < count * 3 && out.length < count; i++) {
      const x = (rnd() - 0.5) * HALF * 1.7;
      const z = (rnd() - 0.5) * HALF * 1.7;
      if (isWater(x, z) || mountainMask(x) > 0.15) continue;
      out.push({ x, z, c: cols[Math.floor(rnd() * cols.length)] });
    }
    return out;
  }, [count]);
  return (
    <group>
      {flowers.map((f, i) => (
        <group key={i} position={[f.x, terrainHeight(f.x, f.z), f.z]}>
          <mesh position={[0, 0.18, 0]}>
            <cylinderGeometry args={[0.015, 0.015, 0.36, 3]} />
            <meshStandardMaterial color="#5f7a3a" />
          </mesh>
          <mesh position={[0, 0.38, 0]}>
            <icosahedronGeometry args={[0.09, 0]} />
            <meshStandardMaterial color={f.c} emissive={f.c} emissiveIntensity={0.15} roughness={0.9} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

// A wooden plank bridge spanning the river so the player can cross on foot.
function Bridge() {
  const span = RIVER_HALF_WIDTH * 2 + 6; // deck length across the channel (X)
  const width = 4;
  const planks = Math.round(span / 0.6);
  const y = BRIDGE_DECK_Y;
  return (
    <group position={[BRIDGE_CX, 0, BRIDGE_Z]}>
      {/* deck */}
      <mesh position={[0, y, 0]} receiveShadow castShadow>
        <boxGeometry args={[span, 0.18, width]} />
        <meshStandardMaterial color="#8a6a44" roughness={1} />
      </mesh>
      {/* plank seams */}
      {Array.from({ length: planks }).map((_, i) => (
        <mesh key={i} position={[-span / 2 + 0.3 + i * 0.6, y + 0.1, 0]}>
          <boxGeometry args={[0.5, 0.04, width - 0.2]} />
          <meshStandardMaterial color="#6f5232" roughness={1} />
        </mesh>
      ))}
      {/* railings + posts on both sides */}
      {[-1, 1].map((s) => (
        <group key={s} position={[0, 0, (s * width) / 2]}>
          <mesh position={[0, y + 0.55, 0]}>
            <boxGeometry args={[span, 0.1, 0.1]} />
            <meshStandardMaterial color="#5a4128" roughness={1} />
          </mesh>
          {Array.from({ length: 6 }).map((_, i) => (
            <mesh key={i} position={[-span / 2 + 0.6 + (i * (span - 1.2)) / 5, y + 0.3, 0]} castShadow>
              <boxGeometry args={[0.12, 0.7, 0.12]} />
              <meshStandardMaterial color="#5a4128" roughness={1} />
            </mesh>
          ))}
        </group>
      ))}
      {/* support piers into the water */}
      {[-span / 3, 0, span / 3].map((dx, i) => (
        <mesh key={i} position={[dx, y - 1, 0]} castShadow>
          <cylinderGeometry args={[0.25, 0.3, 2.4, 6]} />
          <meshStandardMaterial color="#4a3826" roughness={1} />
        </mesh>
      ))}
    </group>
  );
}

export default function Environment() {
  const phase = useGame((s) => s.phase);
  const weather = useGame((s) => s.weather);
  const quality = useGame((s) => s.settings.quality);
  const shadows = useGame((s) => s.settings.shadows);
  const particles = useGame((s) => s.settings.particles);
  const clouds = useGame((s) => s.settings.clouds);
  const trees = useGame((s) => s.trees);
  const biome = useGame((s) => s.biome);
  const B = BIOMES[biome];
  const biomeSky = useRef(new THREE.Color(B.sky));
  const { scene } = useThree();
  const sun = useRef<THREE.DirectionalLight>(null);
  const hemi = useRef<THREE.HemisphereLight>(null);
  const storm = useRef(0);
  const skyC = useRef(new THREE.Color("#a7cfc6"));
  const sunC = useRef(new THREE.Color("#fff4dc"));
  const bolt = useRef<THREE.PointLight>(null);
  const flash = useRef(0);           // 0..1 lightning brightness, decays fast
  const nextBolt = useRef(5 + Math.random() * 7);
  const FLASH_WHITE = useRef(new THREE.Color("#eaf0ff"));
  const hi = quality === "high";
  const med = quality === "medium";

  useFrame((_, delta) => {
    // advance a continuous day clock (~4 min/day), frozen while paused — unless
    // the creator has locked a fixed time of day.
    const lock = getState().timeOfDay;
    if (lock != null) daytime.t = lock;
    else if (!getState().paused) daytime.t = (daytime.t + delta / 240) % 1;
    const theta = daytime.t * Math.PI * 2 - Math.PI / 2; // sun angle
    const elev = Math.sin(theta);                          // -1..1
    daytime.light = Math.max(0, elev);
    daytime.night = Math.max(0, Math.min(1, -elev * 2.2 + 0.15));

    // storm blend
    const target = phase === "storm" ? 1 : 0;
    storm.current += (target - storm.current) * Math.min(1, delta * 1.2);
    const k = storm.current;

    gradient(SKY_STOPS, daytime.t, skyC.current);
    gradient(SUN_STOPS, daytime.t, sunC.current);
    if (k > 0) { skyC.current.lerp(STORM.sky, k); sunC.current.lerp(STORM.sun, k); }
    // pollution haze: the air turns muddy and the fog closes in as the world
    // gets dirtier — the visible cost of the industrial chain.
    const smog = Math.min(1, getState().pollution / POLLUTION_THRESHOLD);
    if (smog > 0) skyC.current.lerp(SMOG, smog * 0.45);
    // rain drapes a cool grey overcast across the sky
    const raining = getState().weather === "rain";
    if (raining) { skyC.current.lerp(RAIN_SKY, 0.5); sunC.current.lerp(RAIN_SKY, 0.35); }

    // biome atmosphere: pull the sky/sun toward the region's signature tint
    // (warm sand / cold blue snow / murky green swamp), strongest by daylight.
    if (B.skyMix > 0) {
      biomeSky.current.set(B.sky);
      const mix = B.skyMix * (0.45 + daytime.light * 0.55);
      skyC.current.lerp(biomeSky.current, mix);
      sunC.current.lerp(biomeSky.current, mix * 0.4);
    }

    // ---- lightning: during a storm or heavy rain, occasional bright flashes.
    const stormy = phase === "storm" || raining;
    if (stormy && !getState().paused) {
      nextBolt.current -= delta;
      if (nextBolt.current <= 0) {
        flash.current = 1;
        nextBolt.current = 4 + Math.random() * (phase === "storm" ? 6 : 11); // storms strike more often
        audio.play("hit"); // short crack as the bolt lands
      }
    }
    flash.current = Math.max(0, flash.current - delta * 4);
    if (flash.current > 0) skyC.current.lerp(FLASH_WHITE.current, flash.current * 0.7);

    scene.background = skyC.current;
    if (scene.fog) {
      const f = scene.fog as THREE.Fog;
      f.color.copy(skyC.current);
      f.near = B.fogNear;
      // rain + pollution pull the murk closer; lightning momentarily clears it
      f.far = B.fogFar - smog * 150 - (raining ? 90 : 0) + flash.current * 60;
    }

    if (sun.current) {
      sun.current.position.set(Math.cos(theta) * 70, Math.max(6, elev * 80), 24);
      sun.current.color.copy(sunC.current);
      sun.current.intensity = (0.25 + daytime.light * 1.35) * (1 - k * 0.45) + flash.current * 1.5;
    }
    if (hemi.current) hemi.current.intensity = (0.28 + daytime.light * 0.5) * B.ambient + flash.current * 2.2;
    if (bolt.current) bolt.current.intensity = flash.current * flash.current * 60;
  });

  const baseTrees = hi ? trees : med ? trees.slice(0, 360) : trees.slice(0, 160);
  // sparser canopy in arid/cold biomes
  const shownTrees = B.treeDensity >= 1 ? baseTrees : baseTrees.slice(0, Math.round(baseTrees.length * B.treeDensity));
  const rockCount = hi ? 96 : med ? 60 : 32;
  const grassCount = hi ? 340 : med ? 190 : 80;
  const particleCount = hi ? 220 : med ? 130 : 60;
  const flowerCount = hi ? 170 : med ? 100 : 50;

  return (
    <>
      <hemisphereLight ref={hemi} args={["#e6ecc9", "#33402a", 0.8]} />
      <directionalLight
        ref={sun} position={[40, 55, 24]} intensity={1.5} castShadow={shadows}
        shadow-mapSize={hi ? [2048, 2048] : [1024, 1024]}
        shadow-camera-left={-HALF} shadow-camera-right={HALF}
        shadow-camera-top={HALF} shadow-camera-bottom={-HALF}
      />
      <pointLight ref={bolt} position={[0, 120, -20]} color="#dfe8ff" intensity={0} distance={800} decay={0.4} />
      <Stars />
      {clouds && <Clouds />}
      <Ground b={B} />
      <Water b={B} />
      <Bridge />
      <Trees trees={shownTrees} shadows={shadows} b={B} />
      <Rocks count={rockCount} b={B} />
      {B.id !== "desert" && <Grass count={B.id === "snow" ? Math.round(grassCount * 0.3) : grassCount} />}
      {(B.decor === "reeds" || B.id === "forest") && <Reeds />}
      {B.decor === "flowers" && <Flowers count={flowerCount} />}
      {B.decor === "cacti" && <Cacti count={hi ? 90 : 55} shadows={shadows} />}
      <Birds />
      {B.id !== "snow" && <Deer />}
      {particles && <Particles count={B.particle.kind === "snow" ? Math.round(particleCount * 1.6) : particleCount} storm={phase === "storm"} b={B} />}
      {weather === "rain" && <Rain count={hi ? 900 : med ? 550 : 300} />}
    </>
  );
}
