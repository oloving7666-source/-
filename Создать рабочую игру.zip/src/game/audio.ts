// Lightweight WebAudio engine — synthesised ambience + SFX, plus a looping
// background-music track streamed from an audio asset.
import musicUrl from "../imports/Pastoral_Peace.mp3";

type Sfx = "place" | "remove" | "shoot" | "hit" | "alarm" | "click";

class AudioEngine {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private musicGain!: GainNode;
  private sfxGain!: GainNode;
  private humOsc?: OscillatorNode;
  private padOsc?: OscillatorNode[];
  private musicEl?: HTMLAudioElement;
  private started = false;
  private musicOn = true; // user toggle for the background-music track
  vol = { master: 0.8, music: 0.6, sfx: 0.8 };

  isStarted() { return this.started; }
  isMusicOn() { return this.musicOn; }

  // Toggle the looping music track on/off (pause/resume). Returns the new state.
  toggleMusic(): boolean {
    this.musicOn = !this.musicOn;
    if (this.musicEl) {
      if (this.musicOn) this.musicEl.play().catch(() => { /* awaiting gesture */ });
      else this.musicEl.pause();
    }
    return this.musicOn;
  }

  private ensure() {
    if (this.ctx) return;
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    this.ctx = new Ctx();
    this.master = this.ctx.createGain();
    this.musicGain = this.ctx.createGain();
    this.sfxGain = this.ctx.createGain();
    this.musicGain.connect(this.master);
    this.sfxGain.connect(this.master);
    this.master.connect(this.ctx.destination);
    this.applyVolumes();
  }

  applyVolumes() {
    if (!this.ctx) return;
    this.master.gain.value = this.vol.master;
    this.musicGain.gain.value = this.vol.music;
    this.sfxGain.gain.value = this.vol.sfx;
  }

  setVolumes(v: Partial<typeof this.vol>) {
    this.vol = { ...this.vol, ...v };
    this.applyVolumes();
  }

  // Must be called from a user gesture (menu button).
  start() {
    this.ensure();
    if (!this.ctx) return;
    this.ctx.resume();
    if (this.started) return;
    this.started = true;

    // Looping background-music track, routed through musicGain so the volume
    // sliders control it. Created here (inside the user gesture) so autoplay
    // policies don't block it.
    if (!this.musicEl) {
      const el = new Audio(musicUrl);
      el.loop = true;
      this.musicEl = el;
      const src = this.ctx.createMediaElementSource(el);
      const mg = this.ctx.createGain();
      mg.gain.value = 0.9;
      src.connect(mg).connect(this.musicGain);
    }
    this.musicEl.currentTime = 0;
    if (this.musicOn) this.musicEl.play().catch(() => { /* awaiting gesture */ });
  }

  // Shift the pad up a tense minor chord during storms.
  setPhase(phase: "day" | "storm") {
    if (!this.padOsc || !this.ctx) return;
    const day = [130.8, 196, 261.6];
    const storm = [123.5, 185, 220]; // darker, dissonant
    const set = phase === "storm" ? storm : day;
    this.padOsc.forEach((o, i) =>
      o.frequency.linearRampToValueAtTime(set[i], this.ctx!.currentTime + 1.2),
    );
    if (this.humOsc)
      this.humOsc.frequency.linearRampToValueAtTime(
        phase === "storm" ? 58 : 46,
        this.ctx.currentTime + 1.2,
      );
  }

  play(type: Sfx) {
    if (!this.ctx || !this.started) return;
    const t = this.ctx.currentTime;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.connect(g).connect(this.sfxGain);
    const spec: Record<Sfx, [OscillatorType, number, number, number]> = {
      // type, startFreq, endFreq, duration
      place: ["triangle", 320, 520, 0.12],
      remove: ["square", 240, 90, 0.14],
      shoot: ["sawtooth", 680, 180, 0.1],
      hit: ["square", 160, 60, 0.12],
      alarm: ["sawtooth", 440, 660, 0.5],
      click: ["sine", 520, 620, 0.06],
    };
    const [type2, f0, f1, dur] = spec[type];
    o.type = type2;
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.5, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
}

export const audio = new AudioEngine();
