export type CameraMode = "explore" | "architect";
export type Phase = "day" | "storm";
export type Screen = "menu" | "playing";

export type Ore = "iron" | "copper" | "coal" | "stone" | "gold" | "water";

export type RawKey = "wood" | "stone" | "coal" | "iron" | "copper" | "gold";
export type ItemKey = "plates" | "gears" | "ammo";
export type ResKey = RawKey | ItemKey;

export type BuildingKind =
  | "drill" | "conveyor" | "splitter" | "merger" | "smelter" | "assembler"
  | "pylon" | "turret" | "wall" | "pump" | "complex" | "hub"
  | "waterwheel" | "recycler" | "storage"
  // structural (Satisfactory-style) — foundations, ramps, pillars, glass
  | "found1" | "found2" | "found4" | "ramp" | "cramp" | "stairs" | "pillar" | "glass";

export interface Cell { x: number; z: number; }

export interface Building {
  id: string;
  kind: BuildingKind;
  x: number;
  z: number;
  level: number;
  rot: number;
  hp: number;
}

export interface Belt {
  id: string;
  cells: Cell[];
}

export interface Tree { id: string; x: number; z: number; s: number; }

// Programmable ground hauler: follows a looping route the player draws.
export interface Vehicle { id: string; cells: Cell[]; cargo: ResKey; }
// Aerial logistics drone: ferries between two ports along an arc.
export interface Drone { id: string; a: Cell; b: Cell; cargo: ResKey; }

export type SpecialTool = "vehicle" | "drone";

export interface ResourceNode {
  id: string;
  x: number;
  z: number;
  ore: Ore;
}

export interface Blueprint {
  id: string;
  name: string;
  buildings: { kind: BuildingKind; dx: number; dz: number; level: number }[];
}

export type Quality = "low" | "medium" | "high";

export interface Settings {
  master: number;
  music: number;
  sfx: number;
  ambient: number;
  quality: Quality;
  shadows: boolean;
  particles: boolean;
  clouds: boolean;
  maxZoom: number; // max top-down (architect) camera pull-back
  bloom: boolean;            // post-processing glow on/off
  bloomIntensity: number;    // 0..2 glow strength
  bloomThreshold: number;    // 0..1 brightness cutoff for glow

  pauseInMenu: boolean;
  pauseInInventory: boolean;
  pauseInArchitect: boolean;
  hints: boolean;
  difficulty: 1 | 2 | 3;
  playerName: string;
}

// Loose ground items — only used to craft the first axe & pickaxe.
export interface Pickup { id: string; x: number; z: number; kind: "stick" | "pebble"; }

// Per-element HUD customization: drag offset, scale and visibility.
export interface HudLayoutEntry { dx: number; dy: number; scale: number; hidden: boolean; }

// God-mode: decorative world objects the player can freely paint & erase.
export type PropKind =
  | "tree" | "pine" | "bush" | "rock" | "flower"
  | "house" | "well" | "lamp"
  | "monster" | "deer";
export interface PlacedProp { id: string; kind: PropKind; x: number; z: number; rot: number; scale: number; }

export type Biome = "forest" | "desert" | "snow" | "swamp";

export interface GameState {
  screen: Screen;
  biome: Biome;
  worldMapOpen: boolean;
  paused: boolean;
  tutorial: boolean;
  tutorialStep: number;
  adminOpen: boolean;
  inventoryOpen: boolean;
  craftOpen: boolean;
  pauseMenuOpen: boolean;
  settings: Settings;

  mode: CameraMode;
  phase: Phase;
  day: number;
  buildLevel: number; // current floor for placement
  buildRot: number;   // 0..3 rotation applied to the next placed building
  architectZoom: number; // top-down camera zoom (smaller = closer)
  architectPan: { x: number; z: number }; // middle-drag camera offset in TAB view

  selected: BuildingKind | null;
  buildings: Building[];
  belts: Belt[];
  vehicles: Vehicle[];
  drones: Drone[];
  special: SpecialTool | null;
  trees: Tree[];
  pickups: Pickup[];
  mats: { stick: number; pebble: number };
  blueprints: Blueprint[];
  nodes: ResourceNode[];
  hover: Cell | null;
  beltDraft: { start: Cell; end: Cell } | null;
  player: { x: number; z: number };

  hotbar: (string | null)[]; // equipped tool/weapon belt (item ids)
  hotbarActive: number;      // index of the currently-held slot
  tools: { axe: number; pickaxe: number }; // 0 = not owned, else tier level
  harvestUntil: number; // performance.now() timestamp while swing anim plays
  harvestTool: "axe" | "pickaxe";
  resources: Record<ResKey, number>;
  power: { produced: number; consumed: number };
  efficiency: number;
  unpoweredIds: string[]; // buildings currently lacking power (for HUD markers)
  pollution: number;
  pollutionRate: number;

  completedObjectives: string[];
  researched: string[];                       // unlocked tech-tree node ids

  hudLayout: Record<string, HudLayoutEntry>; // custom placement of HUD widgets
  hudEditing: boolean;                        // drag-to-arrange mode active

  props: PlacedProp[];                        // god-mode decorative objects
  godBrush: PropKind | "erase" | null;        // active creator-mode brush

  selection: string[];                        // marquee-selected building ids
  weather: "clear" | "rain";                  // ambient weather overlay
  timeOfDay: number | null;                   // 0..1 locked time, or null = auto
  stats: { produced: number; consumed: number; pollution: number }[]; // rolling history

  baseHp: number;
  baseHpMax: number;
  wave: number;
  monstersAlive: number;
  alert: string | null;
}
