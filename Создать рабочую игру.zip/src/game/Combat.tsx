import { useFrame } from "@react-three/fiber";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { BIOMES, GRID, cellToWorld, worldToCell } from "./config";
import { findPath } from "./pathfind";
import { actions, getState, useGame } from "./store";
import { audio } from "./audio";
import type { Cell } from "./types";

interface Monster {
  id: number;
  pos: THREE.Vector3;
  hp: number;
  speed: number;
  path: Cell[];
  wp: number;
  repath: number;
}
interface Bolt { id: number; pos: THREE.Vector3; target: number; dmg: number; color: string; }

let uid = 1;

function blockedSet() {
  const s = getState();
  const set = new Set<number>();
  for (const b of s.buildings) {
    if (b.kind === "hub") continue; // goal is reachable
    set.add(b.x * GRID + b.z);
  }
  return set;
}

export default function Combat({ pref }: { pref: React.MutableRefObject<THREE.Vector3> }) {
  const phase = useGame((s) => s.phase);
  const wave = useGame((s) => s.wave);
  const [monsters, setMonsters] = useState<Monster[]>([]);
  const [bolts, setBolts] = useState<Bolt[]>([]);
  const quota = useRef(0);
  const spawned = useRef(0);
  const spawnTimer = useRef(0);
  const turretCd = useRef<Record<string, number>>({});
  const monstersRef = useRef<Monster[]>([]);
  monstersRef.current = monsters;

  useEffect(() => {
    if (phase === "storm") {
      const diff = getState().settings.difficulty; // 1 спокойно · 2 норма · 3 хардкор
      const mult = diff === 1 ? 0.7 : diff === 3 ? 1.5 : 1;
      const biomeMul = BIOMES[getState().biome].mod.waveMul; // harsh biomes send larger hordes
      quota.current = Math.round((6 + wave * 3) * mult * biomeMul);
      spawned.current = 0;
    }
  }, [phase, wave]);

  // Player fires at the nearest monster (explore mode, costs ammo).
  useEffect(() => {
    const fire = (e: KeyboardEvent | MouseEvent) => {
      const s = getState();
      if (s.paused || s.mode !== "explore" || s.phase !== "storm" || s.resources.ammo <= 0) return;
      if ("code" in e && e.code !== "Space") return;
      const ms = monstersRef.current;
      if (!ms.length) return;
      let best: Monster | null = null, bd = Infinity;
      for (const m of ms) { const d = m.pos.distanceTo(pref.current); if (d < bd) { bd = d; best = m; } }
      if (best) {
        actions.addResource("ammo", -1);
        audio.play("shoot");
        setBolts((bs) => [...bs, { id: uid++, pos: new THREE.Vector3(pref.current.x, 1, pref.current.z), target: best!.id, dmg: 40, color: "#ffd98a" }]);
      }
    };
    window.addEventListener("keydown", fire);
    window.addEventListener("mousedown", fire);
    return () => { window.removeEventListener("keydown", fire); window.removeEventListener("mousedown", fire); };
  }, [pref]);

  useFrame((_, delta) => {
    const s = getState();
    if (s.paused || s.screen !== "playing") return;
    const dt = Math.min(delta, 0.05);
    const hub = s.buildings.find((b) => b.kind === "hub");
    if (!hub) return;
    const goal: Cell = { x: hub.x, z: hub.z };
    const [hx, hz] = cellToWorld(hub.x, hub.z);
    const hubPos = new THREE.Vector3(hx, 0.7, hz);

    // spawn
    if (s.phase === "storm" && spawned.current < quota.current) {
      spawnTimer.current -= dt;
      if (spawnTimer.current <= 0) {
        spawnTimer.current = 0.9;
        spawned.current++;
        const a = Math.random() * Math.PI * 2;
        const wx = Math.cos(a) * 42, wz = Math.sin(a) * 42;
        const startCell = { x: THREE.MathUtils.clamp(worldToCell(wx, wz)[0], 0, GRID - 1), z: THREE.MathUtils.clamp(worldToCell(wx, wz)[1], 0, GRID - 1) };
        const path = findPath(startCell, goal, blockedSet());
        const diff = s.settings.difficulty;
        const hpMult = diff === 1 ? 0.75 : diff === 3 ? 1.4 : 1;
        setMonsters((m) => [...m, { id: uid++, pos: new THREE.Vector3(wx, 0.7, wz), hp: (60 + s.wave * 15) * hpMult, speed: (3 + Math.random() * 1.2) * (diff === 3 ? 1.2 : 1), path, wp: 0, repath: 2 }]);
      }
    }

    // move along A* path
    let baseHit = 0;
    setMonsters((ms) => {
      const next: Monster[] = [];
      for (const m of ms) {
        m.repath -= dt;
        if (m.repath <= 0) {
          const c = worldToCell(m.pos.x, m.pos.z);
          m.path = findPath({ x: THREE.MathUtils.clamp(c[0], 0, GRID - 1), z: THREE.MathUtils.clamp(c[1], 0, GRID - 1) }, goal, blockedSet());
          m.wp = 0;
          m.repath = 2 + Math.random();
        }
        // target: next waypoint, or hub directly if no path
        let tx: number, tz: number;
        if (m.path.length > 1 && m.wp < m.path.length) {
          const wc = m.path[Math.min(m.wp, m.path.length - 1)];
          [tx, tz] = cellToWorld(wc.x, wc.z);
          if (Math.hypot(tx - m.pos.x, tz - m.pos.z) < 1) m.wp++;
        } else {
          tx = hx; tz = hz;
        }
        const dist = Math.hypot(hx - m.pos.x, hz - m.pos.z);
        if (dist < 2.4) { baseHit += 20 * dt; continue; }
        const dx = tx - m.pos.x, dz = tz - m.pos.z;
        const len = Math.hypot(dx, dz) || 1;
        m.pos.x += (dx / len) * m.speed * dt;
        m.pos.z += (dz / len) * m.speed * dt;
        next.push(m);
      }
      return next;
    });
    if (baseHit > 0) actions.damageBuilding(hub.id, baseHit);

    // turrets auto-fire
    for (const b of s.buildings) {
      if (b.kind !== "turret") continue;
      turretCd.current[b.id] = (turretCd.current[b.id] ?? 0) - dt;
      if (turretCd.current[b.id] > 0) continue;
      const [tx, tz] = cellToWorld(b.x, b.z);
      const tp = new THREE.Vector3(tx, 1, tz);
      let best: Monster | null = null, bd = 16;
      for (const m of monstersRef.current) { const d = m.pos.distanceTo(tp); if (d < bd) { bd = d; best = m; } }
      if (best) {
        turretCd.current[b.id] = 0.6;
        audio.play("shoot");
        setBolts((bs) => [...bs, { id: uid++, pos: tp.clone(), target: best!.id, dmg: 25, color: "#b5563f" }]);
      }
    }

    // bolts
    const kills: number[] = [];
    setBolts((bs) => {
      const next: Bolt[] = [];
      for (const bolt of bs) {
        const target = monstersRef.current.find((m) => m.id === bolt.target);
        if (!target) continue;
        const d = target.pos.clone().sub(bolt.pos);
        if (d.length() < 0.8) { target.hp -= bolt.dmg; if (target.hp <= 0) kills.push(target.id); audio.play("hit"); continue; }
        bolt.pos.addScaledVector(d.normalize(), 45 * dt);
        next.push(bolt);
      }
      return next;
    });
    if (kills.length) {
      const set = new Set(kills);
      setMonsters((ms) => ms.filter((m) => !set.has(m.id)));
      actions.addResource("copper", kills.length * 3);
      if (Math.random() < 0.5) actions.addResource("ammo", kills.length);
    }

    if (s.phase === "storm" && spawned.current >= quota.current && monstersRef.current.length === 0) {
      actions.endStorm();
    }
    actions.setCombat(monstersRef.current.length, s.wave);
    // keep player avatar height at hub reference
    void hubPos;
  });

  return (
    <group>
      {monsters.map((m) => (
        <group key={m.id} position={m.pos}>
          <mesh castShadow>
            <icosahedronGeometry args={[0.55, 0]} />
            <meshStandardMaterial color="#7a3b2a" emissive="#d64f2f" emissiveIntensity={0.5} roughness={0.6} />
          </mesh>
          <mesh position={[0, 0.5, 0.2]}>
            <sphereGeometry args={[0.12, 8, 8]} />
            <meshStandardMaterial color="#ffe08a" emissive="#ffcc55" emissiveIntensity={1.5} toneMapped={false} />
          </mesh>
        </group>
      ))}
      {bolts.map((b) => (
        <mesh key={b.id} position={b.pos}>
          <sphereGeometry args={[0.16, 8, 8]} />
          <meshStandardMaterial color={b.color} emissive={b.color} emissiveIntensity={2} toneMapped={false} />
        </mesh>
      ))}
    </group>
  );
}
