import { useSyncExternalStore } from "react";
import type { Belt, Blueprint, Building, BuildingKind, Cell, Drone, GameState, Ore, Pickup, PlacedProp, PropKind, RawKey, ResKey, ResourceNode, SpecialTool, Tree, Vehicle } from "./types";
import { BIOMES, BUILDINGS, BLUEPRINT_KEY, CELL, DEFAULT_UNLOCKED, GRID, HALF, HOTBAR_SIZE, MAX_LEVEL, OBJECTIVES, POLLUTION_THRESHOLD, POWER_LINK, RAW_KEYS, SAVE_KEY, TECHS, TOOL_TIERS, cellToWorld, isBuildable, isWater, riverCenterX } from "./config";
import { audio } from "./audio";
import { daytime } from "./daynight";

let state: GameState = initialState();
const listeners = new Set<() => void>();
let pendingBlueprint: Blueprint | null = null;

// ---- belt item-simulation (transient, not persisted) ----
// Each belt buffers real cargo: a source pushes items onto it, a wired sink
// drains them. If the belt fills faster than it empties, it jams (backpressure)
// and the upstream machine can't offload — visualised as a red, stalled belt.
const BELT_CAP_BASE = 8;   // base max items a belt can hold in flight
const BELT_RATE_BASE = 2;  // base items moved on/off per tick
// Logistics research raises both. Recomputed from the researched tech list.
export function beltRate(researched = state.researched): number {
  return TECHS.reduce((r, t) => r + (researched.includes(t.id) ? t.effect?.beltRate ?? 0 : 0), BELT_RATE_BASE);
}
export function beltCap(researched = state.researched): number {
  return TECHS.reduce((c, t) => c + (researched.includes(t.id) ? t.effect?.beltCap ?? 0 : 0), BELT_CAP_BASE);
}
export interface BeltSim { load: number; res: ResKey | null; jam: boolean; toSink: boolean }
const beltSim = new Map<string, BeltSim>();
let jamAlarmUntil = 0; // throttle for the belt-jam alarm sound
export function beltInfo(id: string): BeltSim | null { return beltSim.get(id) ?? null; }
// Snapshot of every belt's sim for the logistics overview panel.
export function beltStatuses(): (BeltSim & { id: string })[] {
  return state.belts.map((b) => {
    const s = beltSim.get(b.id) ?? { load: 0, res: null, jam: false, toSink: false };
    return { id: b.id, ...s };
  });
}

function seeded(seed: number) {
  return () => ((seed = (seed * 9301 + 49297) % 233280) / 233280);
}

// Procedural open world: ore deposits in clustered veins, dense forest, river.
function generateWorld(): { nodes: ResourceNode[]; trees: Tree[]; pickups: Pickup[] } {
  const rnd = seeded(20260905);
  const nodes: ResourceNode[] = [];
  const hub = GRID / 2;
  const onWater = (x: number, z: number) => isWater(x * CELL - HALF + 1, z * CELL - HALF + 1);

  // Ore veins: pick a centre + ore type, scatter a cluster around it.
  const veinTypes: Ore[] = ["stone", "stone", "coal", "coal", "iron", "iron", "copper", "gold"];
  for (let v = 0; v < 26; v++) {
    const cx = Math.floor(rnd() * GRID);
    const cz = Math.floor(rnd() * GRID);
    const ore = veinTypes[Math.floor(rnd() * veinTypes.length)];
    const count = 4 + Math.floor(rnd() * 5);
    for (let i = 0; i < count; i++) {
      const x = Math.round(cx + (rnd() - 0.5) * 6);
      const z = Math.round(cz + (rnd() - 0.5) * 6);
      if (x < 1 || z < 1 || x >= GRID - 1 || z >= GRID - 1) continue;
      if (Math.hypot(x - hub, z - hub) < 5) continue; // keep spawn clear
      if (onWater(x, z)) continue;
      nodes.push({ id: `n${v}-${i}`, x, z, ore });
    }
  }

  // River water tiles (sampled along the channel) for pumps to draw from.
  for (let z = 0; z < GRID; z += 1) {
    const rx = Math.round((riverCenterX(z * CELL - HALF) + HALF) / CELL);
    for (let dx = -1; dx <= 1; dx++) {
      const x = rx + dx;
      if (x < 0 || x >= GRID) continue;
      if (onWater(x, z)) nodes.push({ id: `w${x}-${z}`, x, z, ore: "water" });
    }
  }

  const trees: Tree[] = [];
  for (let i = 0; i < 620; i++) {
    const x = (rnd() - 0.5) * HALF * 1.95;
    const z = (rnd() - 0.5) * HALF * 1.95;
    if (Math.hypot(x, z) < 9) continue;
    if (isWater(x, z)) continue; // no trees in the river
    trees.push({ id: `t${i}`, x, z, s: 0.7 + rnd() * 1.5 });
  }

  // Loose sticks & pebbles for crafting the first tools — scattered on land,
  // some near spawn so the player can bootstrap immediately.
  const pickups: Pickup[] = [];
  for (let i = 0; i < 180; i++) {
    const near = i < 24; // guarantee a starter supply around the hub
    const x = near ? (rnd() - 0.5) * 40 : (rnd() - 0.5) * HALF * 1.9;
    const z = near ? (rnd() - 0.5) * 40 : (rnd() - 0.5) * HALF * 1.9;
    if (isWater(x, z)) continue;
    pickups.push({ id: `p${i}`, x, z, kind: rnd() < 0.5 ? "stick" : "pebble" });
  }
  return { nodes, trees, pickups };
}

function emptyRes(): Record<ResKey, number> {
  return { wood: 30, stone: 0, coal: 0, iron: 0, copper: 0, gold: 0, plates: 0, gears: 0, ammo: 20 };
}

function defaultSettings(): GameState["settings"] {
  return {
    master: 0.8, music: 0.6, sfx: 0.8, ambient: 0.5,
    quality: "high", shadows: true, particles: true, clouds: true, maxZoom: 2,
    bloom: true, bloomIntensity: 0.55, bloomThreshold: 0.62,
    pauseInMenu: true, pauseInInventory: false, pauseInArchitect: true, hints: true, difficulty: 2,
    playerName: "Смотритель",
  };
}

function initialState(): GameState {
  const { nodes, trees, pickups } = generateWorld();
  const hubX = Math.floor(GRID / 2), hubZ = Math.floor(GRID / 2);
  return {
    screen: "menu", biome: "forest", worldMapOpen: false, paused: false, tutorial: true, tutorialStep: 0,
    adminOpen: false, inventoryOpen: false, craftOpen: false, pauseMenuOpen: false,
    settings: defaultSettings(),

    mode: "architect", phase: "day", day: 1, buildLevel: 0, buildRot: 0, architectZoom: 1, architectPan: { x: 0, z: 0 },

    selected: null, special: null,
    buildings: [{ id: "hub-0", kind: "hub", x: hubX, z: hubZ, level: 0, rot: 0, hp: 500 }],
    belts: [], vehicles: [], drones: [], trees, pickups, mats: { stick: 0, pebble: 0 }, blueprints: loadBlueprints(), nodes,
    hover: null, beltDraft: null, player: { x: 0, z: 0 },

    hotbar: (() => { const hb = Array(HOTBAR_SIZE).fill(null) as (string | null)[]; hb[0] = "blaster"; return hb; })(),
    hotbarActive: 0,
    tools: { axe: 0, pickaxe: 0 },
    harvestUntil: 0, harvestTool: "axe",
    resources: emptyRes(),
    power: { produced: 20, consumed: 0 }, efficiency: 1, unpoweredIds: [],
    pollution: 0, pollutionRate: 1,
    completedObjectives: [],
    researched: [],
    hudLayout: {}, hudEditing: false,
    props: [], godBrush: null,
    selection: [], weather: "clear", timeOfDay: null, stats: [],
    baseHp: 500, baseHpMax: 500, wave: 0, monstersAlive: 0, alert: null,
  };
}

function set(next: Partial<GameState>) {
  state = { ...state, ...next };
  listeners.forEach((l) => l());
}
export function subscribe(l: () => void) { listeners.add(l); return () => listeners.delete(l); }
export function getState() { return state; }
export function useGame<T>(selector: (s: GameState) => T): T {
  return useSyncExternalStore(subscribe, () => selector(state), () => selector(state));
}
export function getPendingBlueprint() { return pendingBlueprint; }

const nodeAt = (x: number, z: number) => state.nodes.find((n) => n.x === x && n.z === z && n.ore !== "water");
const occupied = (x: number, z: number, level: number) => state.buildings.some((b) => b.x === x && b.z === z && b.level === level);

// Endfield-style grid: energy flows hub → pylon → pylon. A pylon is live only
// if it chains back to the hub through links no longer than POWER_LINK.
export function poweredPylons(buildings = state.buildings): Set<string> {
  const hub = buildings.find((b) => b.kind === "hub");
  const powered = new Set<string>();
  if (!hub) return powered;
  const pylons = buildings.filter((b) => b.kind === "pylon");
  let changed = true;
  while (changed) {
    changed = false;
    for (const p of pylons) {
      if (powered.has(p.id)) continue;
      const linkedToHub = Math.hypot(p.x - hub.x, p.z - hub.z) <= POWER_LINK;
      const linkedToLive = pylons.some((q) => powered.has(q.id) && Math.hypot(p.x - q.x, p.z - q.z) <= POWER_LINK);
      if (linkedToHub || linkedToLive) { powered.add(p.id); changed = true; }
    }
  }
  return powered;
}

export function isPowered(b: Building, buildings = state.buildings, live?: Set<string>): boolean {
  if (b.kind === "hub" || b.kind === "pump" || b.kind === "waterwheel" || b.kind === "wall") return true;
  const pp = live ?? poweredPylons(buildings);
  if (b.kind === "pylon") return pp.has(b.id);
  const hub = buildings.find((x) => x.kind === "hub");
  if (hub && Math.hypot(hub.x - b.x, hub.z - b.z) <= 11) return true; // hub aura
  const r = BUILDINGS.pylon.radius ?? 6;
  return buildings.some((p) => p.kind === "pylon" && pp.has(p.id) && Math.hypot(p.x - b.x, p.z - b.z) <= r);
}

function canAfford(cost: Partial<Record<RawKey, number>>) {
  return RAW_KEYS.every((k) => (state.resources[k] ?? 0) >= (cost[k] ?? 0));
}
function payCost(cost: Partial<Record<RawKey, number>>) {
  const r = { ...state.resources };
  for (const k of RAW_KEYS) r[k] -= cost[k] ?? 0;
  return r;
}
function costLabel(cost: Partial<Record<RawKey, number>>) {
  return Object.entries(cost).map(([k, v]) => `${v} ${k}`).join(", ");
}
function tierCostLabel(t: { cost: Partial<Record<RawKey, number>>; mats?: { stick?: number; pebble?: number } }) {
  const parts: string[] = [];
  if (t.mats?.stick) parts.push(`${t.mats.stick} палок`);
  if (t.mats?.pebble) parts.push(`${t.mats.pebble} камней`);
  const raw = costLabel(t.cost);
  if (raw) parts.push(raw);
  return parts.join(", ") || "бесплатно";
}

// What resources are currently flowing into a given sink (hub/storage) via
// belts, and at what per-tick rate. Mirrors the delivery logic in tick().
export function incomingCargo(sink: { x: number; z: number }): { res: ResKey; rate: number }[] {
  const g = getState();
  const totals: Partial<Record<ResKey, number>> = {};
  for (const belt of g.belts) {
    const end = belt.cells[belt.cells.length - 1];
    if (!end) continue;
    if (Math.abs(end.x - sink.x) > 1 || Math.abs(end.z - sink.z) > 1) continue;
    const sim = beltSim.get(belt.id);
    if (!sim || !sim.res || sim.load <= 0) continue;
    const rate = Math.min(beltRate(), sim.load);
    totals[sim.res] = (totals[sim.res] ?? 0) + rate;
  }
  return (Object.entries(totals) as [ResKey, number][]).map(([res, rate]) => ({ res, rate }));
}

// Base-wide logistics snapshot for the overview panel: belt health plus every
// sink and what's currently flowing into it. Recomputed each tick.
export function logistics(): {
  total: number; active: number; jammed: number;
  sinks: { b: Building; incoming: { res: ResKey; rate: number }[] }[];
} {
  let active = 0, jammed = 0;
  for (const belt of state.belts) {
    const sim = beltSim.get(belt.id);
    if (!sim) continue;
    if (sim.res && sim.load > 0) active++;
    if (sim.jam) jammed++;
  }
  const sinks = state.buildings
    .filter((b) => b.kind === "hub" || b.kind === "storage")
    .map((b) => ({ b, incoming: incomingCargo(b) }));
  return { total: state.belts.length, active, jammed, sinks };
}

// A building kind is buildable if it's tier-1 (default) or its unlocking tech
// has been researched.
export function isUnlocked(kind: BuildingKind): boolean {
  if (DEFAULT_UNLOCKED.includes(kind)) return true;
  const done = state.researched;
  return TECHS.some((t) => done.includes(t.id) && t.unlocks.includes(kind));
}

// Whether the top-down architect view should freeze time, per the player's setting.
function architectPaused() { return state.mode === "architect" && state.settings.pauseInArchitect; }

export const actions = {
  startGame() { audio.start(); actions.autosave(); set({ screen: "playing", pauseMenuOpen: false, paused: architectPaused() }); },
  openMenu() { actions.save(); set({ screen: "menu", pauseMenuOpen: false, paused: true }); },
  togglePause() { set({ paused: !state.paused }); },
  toggleAdmin() {
    const closing = state.adminOpen;
    set({ adminOpen: !state.adminOpen, hudEditing: closing ? false : state.hudEditing, godBrush: closing ? null : state.godBrush });
  },

  // ---- god mode (creator): free-paint decorative props ----
  setGodBrush(brush: PropKind | "erase" | null) {
    pendingBlueprint = null;
    set({ godBrush: state.godBrush === brush ? null : brush, selected: null, special: null });
  },
  placeProp(x: number, z: number) {
    const kind = state.godBrush;
    if (!kind || kind === "erase") return;
    const p: PlacedProp = {
      id: `pr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      kind, x, z, rot: Math.random() * Math.PI * 2, scale: 0.85 + Math.random() * 0.4,
    };
    audio.play("place");
    set({ props: [...state.props, p] });
  },
  erasePropNear(x: number, z: number) {
    let best: PlacedProp | null = null, bd = 3.5;
    for (const p of state.props) { const d = Math.hypot(p.x - x, p.z - z); if (d < bd) { bd = d; best = p; } }
    if (!best) return;
    audio.play("remove");
    set({ props: state.props.filter((p) => p.id !== best!.id) });
  },
  clearProps() {
    if (!state.props.length) return;
    audio.play("remove");
    set({ props: [] });
  },

  // ---- HUD layout customization ----
  toggleHudEdit() { set({ hudEditing: !state.hudEditing }); },
  setHudLayout(id: string, patch: Partial<import("./types").HudLayoutEntry>) {
    const cur = state.hudLayout[id] ?? { dx: 0, dy: 0, scale: 1, hidden: false };
    set({ hudLayout: { ...state.hudLayout, [id]: { ...cur, ...patch } } });
  },
  resetHudLayout() { set({ hudLayout: {}, hudEditing: false }); },
  openPauseMenu() { set({ pauseMenuOpen: true, paused: architectPaused() || state.settings.pauseInMenu }); },
  closePauseMenu() { set({ pauseMenuOpen: false, paused: architectPaused() }); },
  quitToMenu() { actions.save(); set({ screen: "menu", pauseMenuOpen: false, adminOpen: false, inventoryOpen: false, craftOpen: false, paused: true }); },
  quitGame() { actions.save(); try { window.close(); } catch { /* web */ } set({ screen: "menu", pauseMenuOpen: false, paused: true }); },
  openWorldMap() { set({ worldMapOpen: true }); },
  closeWorldMap() { set({ worldMapOpen: false }); },
  setBiome(biome: GameState["biome"]) {
    if (biome === state.biome) { set({ worldMapOpen: false }); return; }
    set({ biome, worldMapOpen: false, alert: `Локация: ${biome === "forest" ? "Лес" : biome === "desert" ? "Пустыня" : biome === "snow" ? "Снега" : "Болото"}` });
    audio.play("place");
  },
  toggleInventory() {
    const open = !state.inventoryOpen;
    const paused = architectPaused() || (open && state.settings.pauseInInventory) || (state.pauseMenuOpen && state.settings.pauseInMenu);
    set({ inventoryOpen: open, paused });
  },
  toggleCraft() {
    const open = !state.craftOpen;
    const paused = architectPaused() || (open && state.settings.pauseInInventory) || (state.pauseMenuOpen && state.settings.pauseInMenu);
    set({ craftOpen: open, paused });
  },
  nextTutorial() { set({ tutorialStep: state.tutorialStep + 1 }); },
  skipTutorial() { set({ tutorial: false, tutorialStep: 0 }); },
  startTutorial() { set({ tutorial: true, tutorialStep: 0 }); },
  setSettings(patch: Partial<GameState["settings"]>) {
    const settings = { ...state.settings, ...patch };
    audio.setVolumes({ master: settings.master, music: settings.music, sfx: settings.sfx });
    const max = Math.max(1, settings.maxZoom || 2);
    set({ settings, architectZoom: Math.min(state.architectZoom, max) });
  },
  admin(patch: Partial<GameState>) { set(patch); },

  toggleMode() {
    const mode = state.mode === "explore" ? "architect" : "explore";
    set({ mode, paused: mode === "architect" && state.settings.pauseInArchitect });
  },
  setBuildLevel(dir: number) {
    set({ buildLevel: Math.max(0, Math.min(MAX_LEVEL, state.buildLevel + dir)) });
  },
  rotateBuild() { set({ buildRot: (state.buildRot + 1) % 4 }); },
  zoomArchitect(dir: number) {
    // dir > 0 zooms out, dir < 0 zooms in; upper bound is player-configurable
    const max = Math.max(1, state.settings.maxZoom || 2);
    const z = Math.max(0.4, Math.min(max, state.architectZoom + dir * 0.12));
    set({ architectZoom: z });
  },
  // Middle-mouse free pan of the top-down (architect) camera.
  panArchitect(dx: number, dz: number) {
    set({ architectPan: { x: state.architectPan.x + dx, z: state.architectPan.z + dz } });
  },
  resetArchitectPan() { set({ architectPan: { x: 0, z: 0 } }); },
  // Jump the top-down camera to an absolute world point (minimap click).
  setArchitectPan(x: number, z: number) { set({ architectPan: { x: x - state.player.x, z: z - state.player.z } }); },

  // ---- marquee multi-select & mass ops ----
  setSelection(ids: string[]) { set({ selection: ids }); },
  clearSelection() { if (state.selection.length) set({ selection: [] }); },
  deleteSelection() {
    if (!state.selection.length) return;
    const ids = new Set(state.selection);
    const doomed = state.buildings.filter((b) => ids.has(b.id) && b.kind !== "hub");
    if (!doomed.length) { set({ selection: [] }); return; }
    audio.play("remove");
    set({ buildings: state.buildings.filter((b) => !(ids.has(b.id) && b.kind !== "hub")), selection: [] });
  },
  // Turn the current selection into a stamp: next ground click drops a copy.
  copySelection() {
    const ids = new Set(state.selection);
    const parts = state.buildings.filter((b) => ids.has(b.id) && b.kind !== "hub");
    if (!parts.length) return;
    const minX = Math.min(...parts.map((b) => b.x));
    const minZ = Math.min(...parts.map((b) => b.z));
    pendingBlueprint = {
      id: `copy-${Date.now()}`, name: "копия",
      buildings: parts.map((b) => ({ kind: b.kind, dx: b.x - minX, dz: b.z - minZ, level: b.level })),
    };
    set({ selection: [], selected: null, special: null, alert: "📋 Копия готова — кликните по земле, куда поставить" });
  },
  // Nudge every selected building by a cell offset, if the whole group fits.
  moveSelection(dx: number, dz: number) {
    const ids = new Set(state.selection);
    const sel = state.buildings.filter((b) => ids.has(b.id) && b.kind !== "hub");
    if (!sel.length) return;
    const occ = new Set(state.buildings.filter((b) => !ids.has(b.id)).map((b) => `${b.x},${b.z},${b.level}`));
    for (const b of sel) {
      const nx = b.x + dx, nz = b.z + dz;
      if (!isBuildable(nx, nz) || occ.has(`${nx},${nz},${b.level}`)) { set({ alert: "Не поместится — мешает препятствие" }); return; }
    }
    audio.play("place");
    set({ buildings: state.buildings.map((b) => (ids.has(b.id) && b.kind !== "hub" ? { ...b, x: b.x + dx, z: b.z + dz } : b)) });
  },

  // ---- weather & time-of-day (creator atmosphere controls) ----
  setWeather(weather: GameState["weather"]) { set({ weather }); },
  setTimeOfDay(t: number | null) { set({ timeOfDay: t }); },

  // ---- hotbar (tool belt) ----
  setHotbarActive(i: number) { if (i >= 0 && i < HOTBAR_SIZE) set({ hotbarActive: i }); },
  scrollHotbar(dir: number) {
    const n = HOTBAR_SIZE;
    set({ hotbarActive: ((state.hotbarActive + dir) % n + n) % n });
  },
  // Drop an owned item into a slot (active one if unspecified); if it already
  // sits somewhere, just make that slot active instead of duplicating it.
  placeInHotbar(item: string, slot?: number) {
    const existing = state.hotbar.indexOf(item);
    if (existing >= 0) { set({ hotbarActive: existing }); return; }
    const hb = [...state.hotbar];
    let target = slot ?? state.hotbarActive;
    if (hb[target] != null && slot == null) {
      const free = hb.indexOf(null);
      if (free >= 0) target = free;
    }
    hb[target] = item;
    set({ hotbar: hb, hotbarActive: target });
  },
  clearHotbarSlot(i: number) {
    if (state.hotbar[i] == null) return;
    const hb = [...state.hotbar];
    hb[i] = null;
    set({ hotbar: hb });
  },
  select(kind: BuildingKind | null) {
    pendingBlueprint = null;
    if (kind && !isUnlocked(kind)) {
      const tech = TECHS.find((t) => t.unlocks.includes(kind));
      set({ alert: `🔒 «${BUILDINGS[kind].label}» — сначала исследуйте «${tech?.name ?? "технологию"}» (🔬)` });
      return;
    }
    set({ selected: state.selected === kind ? null : kind, special: null, beltDraft: null });
  },

  // ---- tech tree ----
  research(id: string) {
    if (state.researched.includes(id)) return;
    const tech = TECHS.find((t) => t.id === id);
    if (!tech) return;
    if (!tech.requires.every((r) => state.researched.includes(r))) {
      set({ alert: "🔒 Сначала изучите предыдущую технологию" });
      return;
    }
    if (!canAfford(tech.cost)) { set({ alert: `Мало ресурсов для «${tech.name}»: ${costLabel(tech.cost)}` }); return; }
    audio.play("place");
    set({
      researched: [...state.researched, id],
      resources: payCost(tech.cost),
      alert: `🔬 Изучено: ${tech.name} — ${tech.effect ? tech.effect.label : "открыто " + tech.unlocks.map((k) => BUILDINGS[k].label).join(", ")}`,
    });
  },
  selectSpecial(tool: SpecialTool | null) {
    pendingBlueprint = null;
    set({ special: state.special === tool ? null : tool, selected: null, beltDraft: null });
  },
  hover(cell: Cell | null) {
    if (cell?.x === state.hover?.x && cell?.z === state.hover?.z) return;
    set({ hover: cell });
  },

  // ---- tools (upgradeable) & hand harvesting ----
  craftTool(tool: "axe" | "pickaxe") {
    const cur = state.tools[tool];
    const tiers = TOOL_TIERS[tool];
    if (cur >= tiers.length) { set({ alert: "Максимальный уровень инструмента" }); return; }
    const next = tiers[cur];
    const needStick = next.mats?.stick ?? 0, needPebble = next.mats?.pebble ?? 0;
    const matsOk = state.mats.stick >= needStick && state.mats.pebble >= needPebble;
    if (!canAfford(next.cost) || !matsOk) { set({ alert: `Мало ресурсов: нужно ${tierCostLabel(next)}` }); return; }
    audio.play("place");
    // Newly-crafted tool joins the hotbar in the first free slot.
    let hotbar = state.hotbar;
    let hotbarActive = state.hotbarActive;
    if (!hotbar.includes(tool)) {
      hotbar = [...hotbar];
      let slot = hotbar.indexOf(null);
      if (slot < 0) slot = hotbar.length - 1;
      hotbar[slot] = tool;
      hotbarActive = slot;
    }
    set({
      tools: { ...state.tools, [tool]: next.level },
      resources: payCost(next.cost),
      mats: { stick: state.mats.stick - needStick, pebble: state.mats.pebble - needPebble },
      hotbar, hotbarActive,
      alert: `${cur === 0 ? "Создано" : "Улучшено"}: ${next.label}`,
    });
  },
  chopNearest() {
    // grab a loose stick/pebble first if standing near one
    const pp = state.player;
    let bestP: Pickup | null = null, bpd = 3.4;
    for (const pk of state.pickups) { const d = Math.hypot(pk.x - pp.x, pk.z - pp.z); if (d < bpd) { bpd = d; bestP = pk; } }
    if (bestP) {
      audio.play("click");
      set({
        pickups: state.pickups.filter((k) => k.id !== bestP!.id),
        mats: { ...state.mats, [bestP.kind]: state.mats[bestP.kind] + 1 },
      });
      return;
    }
    // Respect the equipped tool: a pickaxe mines, a blaster gathers nothing.
    const equipped = state.hotbar[state.hotbarActive];
    if (equipped === "pickaxe") return actions.mineNearest();
    if (equipped === "blaster") return;
    const p = state.player;
    let best: Tree | null = null, bd = 3;
    for (const t of state.trees) { const d = Math.hypot(t.x - p.x, t.z - p.z); if (d < bd) { bd = d; best = t; } }
    if (best) {
      if (!state.tools.axe) { set({ alert: "Нужен топор (скрафтите в мастерской, C)" }); return; }
      const gain = TOOL_TIERS.axe[state.tools.axe - 1].yield;
      audio.play("remove");
      set({ trees: state.trees.filter((t) => t.id !== best!.id), resources: { ...state.resources, wood: state.resources.wood + gain }, harvestUntil: performance.now() + 500, harvestTool: "axe" });
      return;
    }
    actions.mineNearest();
  },
  mineNearest() {
    const p = state.player;
    let best: ResourceNode | null = null, bd = 3.2;
    for (const n of state.nodes) {
      if (n.ore === "water") continue;
      const [wx, wz] = cellToWorld(n.x, n.z);
      const d = Math.hypot(wx - p.x, wz - p.z);
      if (d < bd) { bd = d; best = n; }
    }
    if (!best) return;
    if (!state.tools.pickaxe) { set({ alert: "Нужна кирка (скрафтите в мастерской, C)" }); return; }
    const gain = TOOL_TIERS.pickaxe[state.tools.pickaxe - 1].yield;
    audio.play("hit");
    set({ resources: { ...state.resources, [best.ore]: state.resources[best.ore as ResKey] + gain }, harvestUntil: performance.now() + 500, harvestTool: "pickaxe" });
  },

  place(x: number, z: number) {
    if (pendingBlueprint) return actions.placeBlueprint(x, z);
    const kind = state.selected;
    if (!kind || kind === "conveyor") return;
    if (!isBuildable(x, z) || occupied(x, z, state.buildLevel)) return;
    const meta = BUILDINGS[kind];
    if (!canAfford(meta.cost)) { set({ alert: `Мало ресурсов для «${meta.label}»: ${costLabel(meta.cost)}` }); return; }
    const b: Building = { id: `b-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, kind, x, z, level: state.buildLevel, rot: state.buildRot, hp: 100 };
    audio.play("place");
    set({ buildings: [...state.buildings, b], resources: payCost(meta.cost), alert: null });
  },
  remove(x: number, z: number) {
    const lvl = state.buildLevel;
    const had = state.buildings.some((b) => b.x === x && b.z === z && b.level === lvl && b.kind !== "hub");
    const hadBelt = state.belts.some((bl) => bl.cells.some((c) => c.x === x && c.z === z));
    if (had || hadBelt) audio.play("remove");
    set({
      buildings: state.buildings.filter((b) => !(b.x === x && b.z === z && b.level === lvl && b.kind !== "hub")),
      belts: state.belts.filter((bl) => !bl.cells.some((c) => c.x === x && c.z === z)),
    });
  },

  // ---- belt drag ----
  beltStart(cell: Cell) { set({ beltDraft: { start: cell, end: cell } }); },
  beltMove(cell: Cell) { if (state.beltDraft) set({ beltDraft: { start: state.beltDraft.start, end: cell } }); },
  beltCommit() {
    const d = state.beltDraft;
    if (!d) return;
    const cells = lPath(d.start, d.end);

    // Programmable route vehicle: the drawn path becomes its looping circuit.
    if (state.special === "vehicle") {
      const cost = { wood: 12, iron: 8 };
      if (cells.length < 3) { set({ beltDraft: null, alert: "Маршрут слишком короткий — тяни длиннее" }); return; }
      if (!canAfford(cost)) { set({ beltDraft: null, alert: `Мало ресурсов для тягача: ${costLabel(cost)}` }); return; }
      audio.play("place");
      set({ vehicles: [...state.vehicles, { id: `v-${Date.now()}`, cells, cargo: "iron" }], resources: payCost(cost), beltDraft: null });
      return;
    }
    // Aerial drone route: start & end become its two ports.
    if (state.special === "drone") {
      const cost = { wood: 8, copper: 6 };
      if (Math.hypot(d.end.x - d.start.x, d.end.z - d.start.z) < 2) { set({ beltDraft: null, alert: "Разнеси порты дрона дальше" }); return; }
      if (!canAfford(cost)) { set({ beltDraft: null, alert: `Мало ресурсов для дрона: ${costLabel(cost)}` }); return; }
      audio.play("place");
      set({ drones: [...state.drones, { id: `d-${Date.now()}`, a: d.start, b: d.end, cargo: "plates" }], resources: payCost(cost), beltDraft: null });
      return;
    }

    const cost = { wood: cells.length * (BUILDINGS.conveyor.cost.wood ?? 1) };
    if (cells.length < 2 || !canAfford(cost)) {
      set({ beltDraft: null, alert: cells.length < 2 ? null : "Мало древесины для ленты" });
      return;
    }
    audio.play("place");
    set({ belts: [...state.belts, { id: `belt-${Date.now()}`, cells }], resources: payCost(cost), beltDraft: null });
  },

  // ---- blueprints ----
  saveBlueprint(name: string) {
    const parts = state.buildings.filter((b) => b.kind !== "hub");
    if (!parts.length) return;
    const minX = Math.min(...parts.map((b) => b.x));
    const minZ = Math.min(...parts.map((b) => b.z));
    const bp: Blueprint = {
      id: `bp-${Date.now()}`,
      name: name || `Чертёж ${state.blueprints.length + 1}`,
      buildings: parts.map((b) => ({ kind: b.kind, dx: b.x - minX, dz: b.z - minZ, level: b.level })),
    };
    const blueprints = [...state.blueprints, bp];
    localStorage.setItem(BLUEPRINT_KEY, JSON.stringify(blueprints));
    set({ blueprints, alert: `Чертёж «${bp.name}» сохранён` });
  },
  pickBlueprint(id: string) { pendingBlueprint = state.blueprints.find((b) => b.id === id) ?? null; set({ selected: null }); },
  placeBlueprint(x: number, z: number) {
    const bp = pendingBlueprint;
    if (!bp) return;
    const add: Building[] = [];
    for (const p of bp.buildings) {
      const cx = x + p.dx, cz = z + p.dz;
      if (!isBuildable(cx, cz) || occupied(cx, cz, p.level)) continue;
      add.push({ id: `b-${Date.now()}-${Math.random().toString(36).slice(2, 5)}-${p.dx}${p.dz}`, kind: p.kind, x: cx, z: cz, level: p.level, rot: 0, hp: 100 });
    }
    audio.play("place");
    pendingBlueprint = null;
    set({ buildings: [...state.buildings, ...add] });
  },

  setPlayer(x: number, z: number) { state.player.x = x; state.player.z = z; },
  // Auto-vacuum loose sticks & pebbles the avatar walks over — no key needed.
  grabPickupsNear() {
    const p = state.player;
    let stick = state.mats.stick, pebble = state.mats.pebble, got = false;
    const keep: Pickup[] = [];
    for (const pk of state.pickups) {
      if (Math.hypot(pk.x - p.x, pk.z - p.z) < 1.8) {
        if (pk.kind === "stick") stick++; else pebble++;
        got = true;
      } else keep.push(pk);
    }
    if (got) { audio.play("click"); set({ pickups: keep, mats: { stick, pebble } }); }
  },
  damageBuilding(id: string, dmg: number) {
    const b = state.buildings.find((x) => x.id === id);
    if (!b) return;
    b.hp -= dmg;
    if (b.kind === "hub") set({ baseHp: Math.max(0, state.baseHp - dmg) });
    else if (b.hp <= 0) set({ buildings: state.buildings.filter((x) => x.id !== id) });
  },
  addResource(kind: ResKey, amount: number) { set({ resources: { ...state.resources, [kind]: state.resources[kind] + amount } }); },
  setCombat(monstersAlive: number, wave: number) { if (monstersAlive !== state.monstersAlive || wave !== state.wave) set({ monstersAlive, wave }); },
  clearAlert() { if (state.alert) set({ alert: null }); },

  tick() {
    if (state.paused || state.screen !== "playing") return;
    const live = poweredPylons(state.buildings);
    let produced = 0, consumed = 0;
    const unpowered: string[] = [];
    for (const b of state.buildings) {
      const p = BUILDINGS[b.kind].power;
      const powered = isPowered(b, state.buildings, live);
      if (p > 0) produced += p;
      else if (p < 0 && powered) consumed += -p;
      // mark consumers and disconnected pylons for the "no power" marker
      if ((p < 0 && !powered) || (b.kind === "pylon" && !powered)) unpowered.push(b.id);
    }
    // Biome energy modifier: sunny desert overproduces, frozen snow underproduces.
    produced = Math.round(produced * BIOMES[state.biome].mod.powerMul);
    const efficiency = consumed === 0 ? 1 : Math.min(1, produced / consumed);

    const r = { ...state.resources };
    let pollutionDelta = 0;
    for (const b of state.buildings) {
      const meta = BUILDINGS[b.kind];
      if (meta.power < 0 && !isPowered(b, state.buildings, live)) continue;
      const eff = meta.power < 0 ? efficiency : 1;
      pollutionDelta += meta.pollution * eff;
      switch (b.kind) {
        case "drill": { const n = nodeAt(b.x, b.z); if (n) r[n.ore as ResKey] += 2 * eff; break; }
        case "complex": r.plates += 2 * eff; break;
        case "smelter": if (r.iron >= 2 && r.coal >= 1) { r.iron -= 2; r.coal -= 1; r.plates += 1 * eff; } break;
        case "assembler":
          if (r.plates >= 1) { r.plates -= 1; r.gears += 1 * eff; r.ammo += 2 * eff; }
          break;
        // Эко-переработчик: превращает мусор/биомассу обратно в древесину и
        // активно чистит воздух (отрицательное pollution учтено выше).
        case "recycler": r.wood += 2 * eff; break;
      }
    }

    // ---- belt item-sim: cargo buffers on the belt, then drains into a sink.
    // A belt carries the output of the machine feeding its first cell. Powered
    // sources push items onto the belt; a wired hub/storage at the far end pulls
    // them into the stockpile. When intake outpaces delivery the belt fills to
    // capacity and jams — real backpressure the player can see and untangle.
    const sinks = state.buildings.filter((b) => b.kind === "hub" || b.kind === "storage");
    const beltIds = new Set<string>();
    const rate = beltRate(), cap = beltCap();
    let newJams = 0; // belts that jammed this tick but weren't jammed before
    for (const belt of state.belts) {
      beltIds.add(belt.id);
      const sim = beltSim.get(belt.id) ?? { load: 0, res: null, jam: false, toSink: false };
      const wasJammed = sim.jam;
      const start = belt.cells[0], end = belt.cells[belt.cells.length - 1];
      if (!start || !end) { sim.jam = false; beltSim.set(belt.id, sim); continue; }

      // What (if anything) the powered source is feeding onto the belt this tick.
      const src = state.buildings.find((b) => Math.abs(b.x - start.x) <= 1 && Math.abs(b.z - start.z) <= 1 && b.kind !== "conveyor");
      let res: ResKey | null = null;
      if (src && !(BUILDINGS[src.kind].power < 0 && !isPowered(src, state.buildings, live))) {
        if (src.kind === "drill") { const n = nodeAt(src.x, src.z); res = n && n.ore !== "water" ? (n.ore as ResKey) : null; }
        else if (src.kind === "smelter" || src.kind === "complex") res = "plates";
        else if (src.kind === "assembler") res = "gears";
        else if (src.kind === "recycler") res = "wood";
      }
      if (res) sim.res = res; // remember cargo type even after the source stalls

      // Intake: push up to `rate` while there's room; no room ⇒ jammed.
      if (res) {
        const room = cap - sim.load;
        sim.load = Math.min(cap, sim.load + Math.min(rate * efficiency, room));
        sim.jam = room < rate * efficiency - 1e-6;
      } else {
        sim.jam = false;
      }

      // Delivery: a wired sink drains up to `rate` into the stockpile.
      sim.toSink = sinks.some((s) => Math.abs(end.x - s.x) <= 1 && Math.abs(end.z - s.z) <= 1);
      if (sim.toSink && sim.res && sim.load > 0) {
        const out = Math.min(rate, sim.load);
        sim.load -= out;
        r[sim.res] += out;
      }
      if (sim.load <= 1e-6) sim.res = res; // fully drained: reset to live cargo (or empty)
      if (sim.jam && !wasJammed) newJams++;
      beltSim.set(belt.id, sim);
    }
    for (const id of beltSim.keys()) if (!beltIds.has(id)) beltSim.delete(id); // drop removed belts
    // Alarm when a fresh jam appears (throttled so it doesn't nag every tick).
    if (newJams > 0 && performance.now() > jamAlarmUntil) {
      audio.play("alarm");
      jamAlarmUntil = performance.now() + 8000;
    }

    // Night raises the threat: emissions linger and the horde stirs, so
    // pollution climbs faster after dusk — you build by day, defend by night.
    const nightPush = 1 + daytime.night * 0.7;
    const biomePollMul = BIOMES[state.biome].mod.pollutionMul;
    let pollution = Math.max(0, state.pollution + pollutionDelta * 0.6 * state.pollutionRate * nightPush * biomePollMul - 0.4);
    let { phase, alert, wave } = state;
    if (phase === "day" && pollution >= POLLUTION_THRESHOLD) {
      phase = "storm"; wave = state.wave + 1;
      alert = `⚠ ВОЛНА ${wave}: орда идёт на источник загрязнения`;
      audio.setPhase("storm"); audio.play("alarm");
    }
    for (const k of Object.keys(r) as ResKey[]) r[k] = Math.floor(r[k]);

    // Objectives: bank any newly-satisfied goals and pay their reward once.
    let completedObjectives = state.completedObjectives;
    let objAlert: string | null = null;
    const view = { ...state, resources: r, pollution } as GameState;
    for (const o of OBJECTIVES) {
      if (completedObjectives.includes(o.id)) continue;
      if (o.progress(view) >= o.goal) {
        completedObjectives = [...completedObjectives, o.id];
        for (const [k, v] of Object.entries(o.reward)) r[k as ResKey] += v as number;
        objAlert = `🎯 Задача выполнена: ${o.title}`;
        audio.play("place");
      }
    }
    if (objAlert && phase !== "storm") alert = objAlert;

    const stats = [...state.stats, { produced, consumed, pollution }];
    if (stats.length > 120) stats.shift(); // keep ~2 min of history

    set({ power: { produced, consumed }, efficiency, resources: r, unpoweredIds: unpowered, pollution, phase, wave, alert, completedObjectives, stats });
  },
  endStorm() {
    audio.setPhase("day");
    set({
      phase: "day", day: state.day + 1,
      // Пробиваем загрязнение ниже порога шторма, иначе следующий тик тут же
      // снова запустит бурю и волны пойдут без остановки. Даём окно на отстройку.
      pollution: Math.min(Math.max(0, state.pollution - 55), POLLUTION_THRESHOLD * 0.5),
      alert: `✓ Волна отражена. День ${state.day + 1}`,
      resources: { ...state.resources, gold: state.resources.gold + 5 },
    });
  },

  autosave() {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(snapshot())); } catch { /* quota */ }
  },
  save() {
    actions.autosave();
    set({ alert: "База сохранена" });
  },
  load() {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) { set({ alert: "Нет сохранения" }); return; }
    try {
      const s = JSON.parse(raw);
      set({
        day: s.day, buildings: s.buildings, belts: s.belts ?? [], vehicles: s.vehicles ?? [], drones: s.drones ?? [],
        trees: s.trees ?? state.trees, nodes: s.nodes ?? state.nodes, pickups: s.pickups ?? state.pickups,
        mats: { stick: Number(s.mats?.stick) || 0, pebble: Number(s.mats?.pebble) || 0 },
        resources: { ...emptyRes(), ...(s.resources ?? {}) },
        tools: { axe: Number(s.tools?.axe) || 0, pickaxe: Number(s.tools?.pickaxe) || 0 },
        hotbar: Array.isArray(s.hotbar) && s.hotbar.length === HOTBAR_SIZE ? s.hotbar : state.hotbar,
        hotbarActive: Number.isInteger(s.hotbarActive) ? s.hotbarActive : 0,
        pollution: s.pollution ?? 0, baseHp: s.baseHp ?? 500, wave: s.wave ?? 0,
        completedObjectives: Array.isArray(s.completedObjectives) ? s.completedObjectives : [],
        researched: Array.isArray(s.researched) ? s.researched : [],
        hudLayout: s.hudLayout && typeof s.hudLayout === "object" ? s.hudLayout : {},
        props: Array.isArray(s.props) ? s.props : [],
        weather: s.weather === "rain" ? "rain" : "clear",
        biome: ["forest", "desert", "snow", "swamp"].includes(s.biome) ? s.biome : "forest",
        timeOfDay: typeof s.timeOfDay === "number" ? s.timeOfDay : null,
        selection: [],
        settings: { ...defaultSettings(), ...(s.settings ?? {}) }, phase: "day", alert: "База загружена",
      });
    } catch { set({ alert: "Сохранение повреждено" }); }
  },
  reset() {
    pendingBlueprint = null;
    const bp = state.blueprints, settings = state.settings, tutorial = state.tutorial;
    state = initialState();
    state.blueprints = bp; state.settings = settings; state.tutorial = tutorial; state.screen = "playing";
    listeners.forEach((l) => l());
  },
};

function snapshot() {
  return {
    day: state.day, buildings: state.buildings, belts: state.belts, vehicles: state.vehicles, drones: state.drones,
    trees: state.trees, nodes: state.nodes, pickups: state.pickups, mats: state.mats,
    resources: state.resources, tools: state.tools, pollution: state.pollution, baseHp: state.baseHp, wave: state.wave, settings: state.settings,
    completedObjectives: state.completedObjectives, researched: state.researched, hotbar: state.hotbar, hotbarActive: state.hotbarActive,
    hudLayout: state.hudLayout, props: state.props,
    weather: state.weather, timeOfDay: state.timeOfDay, biome: state.biome,
  };
}
function loadBlueprints(): Blueprint[] {
  try { return JSON.parse(localStorage.getItem(BLUEPRINT_KEY) ?? "[]"); } catch { return []; }
}
function lPath(a: Cell, b: Cell): Cell[] {
  const cells: Cell[] = [];
  const sx = Math.sign(b.x - a.x) || 1;
  for (let x = a.x; x !== b.x + sx; x += sx) cells.push({ x, z: a.z });
  const sz = Math.sign(b.z - a.z) || 1;
  for (let z = a.z + sz; z !== b.z + sz; z += sz) cells.push({ x: b.x, z });
  return cells;
}
