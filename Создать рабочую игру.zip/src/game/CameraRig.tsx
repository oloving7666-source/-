import { useFrame, useThree } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";
import { getState } from "./store";
import type { CameraMode } from "./types";

interface Props {
  mode: CameraMode;
  playerRef: React.MutableRefObject<THREE.Vector3>;
  href: React.MutableRefObject<number>; // player heading (radians)
}

// Cinematic interpolation between a trailing 3rd-person explorer rig and a
// high orthographic-feel architect overview.
export default function CameraRig({ mode, playerRef, href }: Props) {
  const { camera } = useThree();
  const target = useRef(new THREE.Vector3());
  const desiredPos = useRef(new THREE.Vector3());
  const lookAt = useRef(new THREE.Vector3());

  const DIST = 10;   // how far the rig trails behind the avatar
  const HEIGHT = 6;  // rig elevation

  useFrame((state, delta) => {
    const p = playerRef.current;
    if (mode === "explore") {
      // Sit directly behind the avatar relative to its heading, so turning the
      // character swings the camera to face the same way (over-the-shoulder).
      const h = href.current;
      const fx = Math.sin(h), fz = Math.cos(h); // avatar forward on XZ
      const bob = Math.sin(state.clock.elapsedTime * 2) * 0.12;
      desiredPos.current.set(p.x - fx * DIST, HEIGHT + bob, p.z - fz * DIST);
      lookAt.current.set(p.x + fx * 3, 1.6, p.z + fz * 3);
    } else {
      const g = getState();
      const z = g.architectZoom;
      const px = p.x + g.architectPan.x, pz = p.z + g.architectPan.z;
      desiredPos.current.set(px + 0.001, 68 * z, pz + 26 * z);
      lookAt.current.set(px, 0, pz);
    }
    // frame-rate independent smoothing (the "camera swoop")
    const k = 1 - Math.pow(0.0022, delta);
    camera.position.lerp(desiredPos.current, k);
    target.current.lerp(lookAt.current, k);
    camera.lookAt(target.current);
  });

  return null;
}
