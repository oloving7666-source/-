import { useFrame, type ThreeEvent } from "@react-three/fiber";
import { Select } from "@react-three/postprocessing";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { Machine } from "./buildings";
import { GodProps } from "./props";
import { BUILDINGS, CELL, HALF, LEVEL_HEIGHT, ORE_COLOR, RES_META, cellToWorld, isBuildable, terrainHeight, worldToCell } from "./config";
import type { ResKey } from "./types";

// world-space [x, y, z] centre of a cell, resting on the terrain surface
function cellSurface(x: number, z: number): [number, number, number] {
  const [wx, wz] = cellToWorld(x, z);
  return [wx, terrainHeight(wx, wz), wz];
}
import { actions, beltInfo, beltRate, getPendingBlueprint, getState, poweredPylons, useGame } from "./store";
import type { Belt, Building, Cell, Drone, ResourceNode, Vehicle } from "./types";

function lPath(a: Cell, b: Cell): Cell[] {
  const cells: Cell[] = [];
  const sx = Math.sign(b.x - a.x) || 1;
  for (let x = a.x; x !== b.x + sx; x += sx) cells.push({ x, z: a.z });
  const sz = Math.sign(b.z - a.z) || 1;
  for (let z = a.z + sz; z !== b.z + sz; z += sz) cells.push({ x: b.x, z });
  return cells;
}

// What a belt actually carries: the output of the machine feeding its first
// cell. Drives crate colour so logistics reads at a glance. null = empty belt.
function beltCargo(belt: Belt): { res: ResKey; running: boolean } | null {
  const g = getState();
  const start = belt.cells[0];
  if (!start) return null;
  const src = g.buildings.find((b) => Math.abs(b.x - start.x) <= 1 && Math.abs(b.z - start.z) <= 1 && b.kind !== "conveyor");
  if (!src) return null;
  let res: ResKey | null = null;
  switch (src.kind) {
    case "drill": { const n = g.nodes.find((nd) => nd.x === src.x && nd.z === src.z); res = n && n.ore !== "water" ? (n.ore as ResKey) : null; break; }
    case "smelter": case "complex": res = "plates"; break;
    case "assembler": res = "gears"; break;
    case "recycler": res = "wood"; break;
    default: res = null;
  }
  if (!res) return null;
  const live = poweredPylons(g.buildings);
  const running = BUILDINGS[src.kind].power >= 0 || live.has(src.id) ||
    g.buildings.some((p) => p.kind === "pylon" && live.has(p.id) && Math.hypot(p.x - src.x, p.z - src.z) <= (BUILDINGS.pylon.radius ?? 6));
  return { res, running };
}

// Continuous belt: tiles orient along travel (so corners read), crates flow.
function BeltMesh({ belt, ghost = false }: { belt: Belt; ghost?: boolean }) {
  const flow = useRef<THREE.Group>(null);
  const pts = useMemo(() => belt.cells.map((c) => cellSurface(c.x, c.z)), [belt.cells]);
  const cargo = ghost ? null : beltCargo(belt);
  const crateColor = cargo ? RES_META[cargo.res].color : "#c98a3c";
  const idle = !!cargo && !cargo.running;

  useFrame((s) => {
    if (getState().paused || !flow.current || pts.length < 2) return;
    const jammed = !ghost && !!beltInfo(belt.id)?.jam;
    // Recolour crates: red when the belt is backed up, dim when starved.
    flow.current.children.forEach((c) => {
      const mat = (c as THREE.Mesh).material as THREE.MeshStandardMaterial;
      if (jammed) { mat.emissive.set("#e04a2a"); mat.emissiveIntensity = 0.5 + Math.sin(s.clock.elapsedTime * 6) * 0.25; }
      else { mat.emissive.set(crateColor); mat.emissiveIntensity = idle ? 0 : 0.12; }
    });
    if (idle || jammed) return; // starved or backed up — crates sit still
    const speed = 0.45 * beltRate(); // upgraded belts run visibly faster
    flow.current.children.forEach((child, i) => {
      const t = (s.clock.elapsedTime * speed + i * 1.3) % (pts.length - 1);
      const seg = Math.floor(t), f = t - seg;
      const a = pts[seg], b = pts[seg + 1];
      child.position.set(a[0] + (b[0] - a[0]) * f, a[1] + 0.55 + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f);
    });
  });

  return (
    <group>
      {belt.cells.map((c, i) => {
        const [wx, wy, wz] = cellSurface(c.x, c.z);
        const nb = belt.cells[i + 1] ?? belt.cells[i - 1] ?? c;
        const angle = Math.atan2(nb.z - c.z, nb.x - c.x);
        return (
          <group key={i} position={[wx, wy + 0.3, wz]} rotation={[0, -angle, 0]}>
            <mesh receiveShadow>
              <boxGeometry args={[CELL * 0.98, 0.14, CELL * 0.5]} />
              <meshStandardMaterial color={ghost ? "#e0b45a" : "#2c2620"} transparent={ghost} opacity={ghost ? 0.4 : 1} />
            </mesh>
            {!ghost && [-1, 1].map((s) => (
              <mesh key={s} position={[0, 0.05, s * CELL * 0.28]}>
                <boxGeometry args={[CELL * 0.98, 0.16, 0.08]} />
                <meshStandardMaterial color="#6f4e30" />
              </mesh>
            ))}
            {!ghost && (
              <mesh position={[0.2, 0.12, 0]} rotation={[0, 0, -Math.PI / 2]}>
                <coneGeometry args={[0.12, 0.3, 3]} />
                <meshStandardMaterial color="#e0b45a" emissive="#e0b45a" emissiveIntensity={0.3} />
              </mesh>
            )}
          </group>
        );
      })}
      {!ghost && cargo && (
        <group ref={flow}>
          {Array.from({ length: Math.max(1, Math.floor(pts.length / 2)) }).map((_, i) => (
            <mesh key={i} castShadow>
              <boxGeometry args={[0.4, 0.4, 0.4]} />
              <meshStandardMaterial color={crateColor} emissive={crateColor} emissiveIntensity={idle ? 0 : 0.12} />
            </mesh>
          ))}
        </group>
      )}
    </group>
  );
}

// Programmable hauler that loops its drawn route, carrying a crate.
function VehicleMesh({ v }: { v: Vehicle }) {
  const g = useRef<THREE.Group>(null);
  const pts = useMemo(() => v.cells.map((c) => cellSurface(c.x, c.z)), [v.cells]);
  useFrame((s) => {
    if (getState().paused || !g.current || pts.length < 2) return;
    const loop = pts.length; // wrap back to start
    const t = (s.clock.elapsedTime * 2.2) % loop;
    const seg = Math.floor(t), f = t - seg;
    const a = pts[seg % loop], b = pts[(seg + 1) % loop];
    g.current.position.set(a[0] + (b[0] - a[0]) * f, a[1] + 0.45 + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f);
    g.current.rotation.y = -Math.atan2(b[2] - a[2], b[0] - a[0]);
  });
  return (
    <group>
      {/* route markers */}
      {v.cells.map((c, i) => {
        const [wx, wy, wz] = cellSurface(c.x, c.z);
        return (
          <mesh key={i} position={[wx, wy + 0.06, wz]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[0.25, 0.32, 12]} />
            <meshBasicMaterial color="#c98a3c" transparent opacity={0.5} side={THREE.DoubleSide} />
          </mesh>
        );
      })}
      <group ref={g}>
        <mesh position={[0, 0.25, 0]} castShadow>
          <boxGeometry args={[1.1, 0.45, 0.7]} />
          <meshStandardMaterial color="#b5763a" metalness={0.3} roughness={0.6} />
        </mesh>
        <mesh position={[0.45, 0.55, 0]} castShadow>
          <boxGeometry args={[0.35, 0.4, 0.6]} />
          <meshStandardMaterial color="#4a3a28" />
        </mesh>
        <mesh position={[-0.2, 0.6, 0]}>
          <boxGeometry args={[0.5, 0.35, 0.5]} />
          <meshStandardMaterial color="#c98a3c" emissive="#e0b45a" emissiveIntensity={0.3} />
        </mesh>
        {[[-0.35, 0.36], [-0.35, -0.36], [0.35, 0.36], [0.35, -0.36]].map(([x, z], i) => (
          <mesh key={i} position={[x, 0.12, z]} rotation={[Math.PI / 2, 0, 0]}>
            <cylinderGeometry args={[0.14, 0.14, 0.12, 10]} />
            <meshStandardMaterial color="#20180f" />
          </mesh>
        ))}
      </group>
    </group>
  );
}

// Aerial drone ferrying between two ports along a bobbing arc.
function DroneMesh({ d }: { d: Drone }) {
  const g = useRef<THREE.Group>(null);
  const rotor = useRef<THREE.Group>(null);
  const a = useMemo(() => cellSurface(d.a.x, d.a.z), [d.a]);
  const b = useMemo(() => cellSurface(d.b.x, d.b.z), [d.b]);
  useFrame((s) => {
    if (getState().paused || !g.current) return;
    const raw = (s.clock.elapsedTime * 0.4) % 2;
    const f = raw < 1 ? raw : 2 - raw; // ping-pong 0..1..0
    const x = a[0] + (b[0] - a[0]) * f;
    const z = a[2] + (b[2] - a[2]) * f;
    const y = a[1] + (b[1] - a[1]) * f + 3.2 + Math.sin(f * Math.PI) * 2.2;
    g.current.position.set(x, y, z);
    g.current.rotation.y = -Math.atan2(b[2] - a[2], b[0] - a[0]);
    if (rotor.current) rotor.current.rotation.y = s.clock.elapsedTime * 25;
  });
  return (
    <group>
      {[a, b].map((p, i) => (
        <mesh key={i} position={[p[0], p[1] + 0.15, p[2]]} castShadow>
          <cylinderGeometry args={[0.5, 0.6, 0.3, 8]} />
          <meshStandardMaterial color="#5a6b7a" metalness={0.4} roughness={0.5} />
        </mesh>
      ))}
      <group ref={g}>
        <mesh castShadow>
          <boxGeometry args={[0.5, 0.28, 0.5]} />
          <meshStandardMaterial color="#3a4a58" metalness={0.5} roughness={0.4} />
        </mesh>
        <mesh position={[0, -0.28, 0]}>
          <boxGeometry args={[0.3, 0.28, 0.3]} />
          <meshStandardMaterial color="#c98a3c" emissive="#e0b45a" emissiveIntensity={0.4} />
        </mesh>
        <group ref={rotor}>
          {[[0.45, 0.45], [0.45, -0.45], [-0.45, 0.45], [-0.45, -0.45]].map(([x, z], i) => (
            <group key={i} position={[x, 0.18, z]}>
              <mesh><boxGeometry args={[0.06, 0.1, 0.06]} /><meshStandardMaterial color="#20272e" /></mesh>
              <mesh position={[0, 0.08, 0]} rotation={[0, i * 0.7, 0]}>
                <boxGeometry args={[0.7, 0.02, 0.08]} />
                <meshStandardMaterial color="#cfd8dd" transparent opacity={0.7} />
              </mesh>
            </group>
          ))}
        </group>
        <pointLight position={[0, -0.3, 0]} intensity={2} distance={4} color="#e0b45a" />
      </group>
    </group>
  );
}

// Loose ground clutter — sticks & pebbles used only to craft first tools.
function Pickups() {
  const pickups = useGame((s) => s.pickups);
  return (
    <group>
      {pickups.map((p) => {
        const y = terrainHeight(p.x, p.z);
        const rot = (p.x * 13 + p.z * 7) % Math.PI;
        return p.kind === "stick" ? (
          <mesh key={p.id} position={[p.x, y + 0.08, p.z]} rotation={[Math.PI / 2, 0, rot]} castShadow>
            <cylinderGeometry args={[0.05, 0.06, 0.7, 5]} />
            <meshStandardMaterial color="#6f4e30" roughness={1} />
          </mesh>
        ) : (
          <mesh key={p.id} position={[p.x, y + 0.1, p.z]} rotation={[rot, rot * 2, 0]} scale={0.5 + (rot % 0.4)} castShadow>
            <dodecahedronGeometry args={[0.32, 0]} />
            <meshStandardMaterial color="#9a9a92" roughness={1} />
          </mesh>
        );
      })}
    </group>
  );
}

function NodeMesh({ n }: { n: ResourceNode }) {
  if (n.ore === "water") return null;
  const [wx, wz] = cellToWorld(n.x, n.z);
  const color = ORE_COLOR[n.ore];
  return (
    <group position={[wx, terrainHeight(wx, wz) + 0.12, wz]}>
      {[[0, 0], [0.4, 0.3], [-0.3, 0.4]].map(([dx, dz], i) => (
        <mesh key={i} position={[dx, 0.15 + i * 0.05, dz]} castShadow>
          <dodecahedronGeometry args={[0.36 - i * 0.06, 0]} />
          <meshStandardMaterial color={color} roughness={0.8} metalness={n.ore === "gold" ? 0.6 : 0.2} />
        </mesh>
      ))}
    </group>
  );
}

function PowerField({ b }: { b: Building }) {
  const r = b.kind === "hub" ? 11 : BUILDINGS.pylon.radius ?? 6;
  const [wx, wz] = cellToWorld(b.x, b.z);
  const color = b.kind === "hub" ? "#ffd98a" : "#7db56b";
  return (
    <mesh position={[wx, 0.06 + b.level * LEVEL_HEIGHT, wz]} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[r * CELL - 0.2, r * CELL, 48]} />
      <meshBasicMaterial color={color} transparent opacity={0.35} side={THREE.DoubleSide} />
    </mesh>
  );
}

function Player({ pref, href }: { pref: React.MutableRefObject<THREE.Vector3>; href: React.MutableRefObject<number> }) {
  const g = useRef<THREE.Group>(null);
  const body = useRef<THREE.Group>(null);
  const legL = useRef<THREE.Group>(null);
  const legR = useRef<THREE.Group>(null);
  const armL = useRef<THREE.Group>(null);
  const armR = useRef<THREE.Group>(null);
  const tool = useRef<THREE.Group>(null);
  const equipped = useGame((s) => s.hotbar[s.hotbarActive]);
  // walk-cycle bookkeeping
  const prev = useRef(new THREE.Vector3());
  const phase = useRef(0);
  const gait = useRef(0); // eased 0..1 "am I walking" factor

  useFrame((_, delta) => {
    const paused = getState().paused;
    const y = terrainHeight(pref.current.x, pref.current.z);
    // ground speed from position delta (Movement drives pref)
    const dx = pref.current.x - prev.current.x;
    const dz = pref.current.z - prev.current.z;
    prev.current.copy(pref.current);
    const speed = paused || delta <= 0 ? 0 : Math.hypot(dx, dz) / delta;
    const walking = speed > 0.4 ? 1 : 0;
    gait.current += (walking - gait.current) * Math.min(1, delta * 10);
    if (!paused) phase.current += delta * (2.2 + Math.min(speed, 12) * 0.9);

    if (g.current) {
      g.current.position.set(pref.current.x, y, pref.current.z);
      g.current.rotation.y = href.current;
    }

    const sw = Math.sin(phase.current);
    const amp = gait.current;
    if (legL.current) legL.current.rotation.x = sw * 0.8 * amp;
    if (legR.current) legR.current.rotation.x = -sw * 0.8 * amp;
    // body bob + subtle idle breathing when standing still
    if (body.current) {
      const bob = Math.abs(Math.sin(phase.current)) * 0.06 * amp;
      const breathe = paused ? 0 : Math.sin(phase.current * 0.5) * 0.015 * (1 - amp);
      body.current.position.y = bob + breathe;
    }

    // tool swing while harvesting takes over the right arm; otherwise arms
    // swing opposite the legs for a natural gait.
    const left = getState().harvestUntil - performance.now();
    const harvesting = left > 0;
    if (tool.current) tool.current.visible = !!equipped;
    if (armR.current) {
      if (harvesting) {
        const swing = Math.sin((1 - left / 500) * Math.PI * 3) * 1.1;
        armR.current.rotation.x = -0.9 - Math.abs(swing);
      } else if (equipped) {
        // hold the tool ready in front, plus a little gait swing
        armR.current.rotation.x = -0.5 - sw * 0.3 * amp;
      } else {
        armR.current.rotation.x = -sw * 0.6 * amp;
      }
    }
    if (armL.current) armL.current.rotation.x = sw * 0.6 * amp;
  });

  const skin = "#d8a15a";
  const cloth = "#e8dcc0";
  return (
    <group ref={g}>
      <group ref={body}>
        {/* torso */}
        <mesh position={[0, 1.0, 0]} castShadow>
          <capsuleGeometry args={[0.3, 0.5, 4, 12]} />
          <meshStandardMaterial color={cloth} />
        </mesh>
        {/* head */}
        <mesh position={[0, 1.5, 0]} castShadow>
          <sphereGeometry args={[0.26, 12, 12]} />
          <meshStandardMaterial color={skin} />
        </mesh>
        {/* left arm */}
        <group ref={armL} position={[-0.34, 1.28, 0]}>
          <mesh position={[0, -0.28, 0]} castShadow>
            <capsuleGeometry args={[0.08, 0.42, 4, 8]} />
            <meshStandardMaterial color={cloth} />
          </mesh>
        </group>
        {/* right arm (also holds the tool mid-harvest, forward +Z) */}
        <group ref={armR} position={[0.34, 1.28, 0]}>
          <mesh position={[0, -0.28, 0]} castShadow>
            <capsuleGeometry args={[0.08, 0.42, 4, 8]} />
            <meshStandardMaterial color={cloth} />
          </mesh>
          <group ref={tool} position={[0, -0.5, 0.1]} visible={false}>
            {equipped === "blaster" ? (
              <group position={[0, -0.1, 0.2]} rotation={[1.2, 0, 0]}>
                <mesh castShadow>
                  <boxGeometry args={[0.12, 0.12, 0.5]} />
                  <meshStandardMaterial color="#3a4650" metalness={0.6} roughness={0.4} />
                </mesh>
                <mesh position={[0, -0.12, -0.14]} rotation={[0.5, 0, 0]}>
                  <boxGeometry args={[0.1, 0.22, 0.1]} />
                  <meshStandardMaterial color="#26303a" />
                </mesh>
                <mesh position={[0, 0.02, 0.32]}>
                  <cylinderGeometry args={[0.04, 0.05, 0.2, 8]} />
                  <meshStandardMaterial color="#e0b45a" emissive="#e0b45a" emissiveIntensity={0.5} />
                </mesh>
              </group>
            ) : (
              <>
                <mesh position={[0, -0.15, 0.1]} rotation={[0.5, 0, 0]} castShadow>
                  <cylinderGeometry args={[0.045, 0.045, 0.7, 6]} />
                  <meshStandardMaterial color="#6f4e30" />
                </mesh>
                {equipped === "pickaxe" ? (
                  <mesh position={[0, -0.42, 0.36]} rotation={[0, 0, Math.PI / 2]} castShadow>
                    <coneGeometry args={[0.08, 0.45, 4]} />
                    <meshStandardMaterial color="#9aa2ab" metalness={0.6} roughness={0.3} />
                  </mesh>
                ) : (
                  <mesh position={[0, -0.4, 0.34]} rotation={[0.5, 0, 0]} castShadow>
                    <boxGeometry args={[0.26, 0.2, 0.07]} />
                    <meshStandardMaterial color="#b8bec6" metalness={0.6} roughness={0.3} />
                  </mesh>
                )}
              </>
            )}
          </group>
        </group>
        {/* legs */}
        <group ref={legL} position={[-0.14, 0.68, 0]}>
          <mesh position={[0, -0.34, 0]} castShadow>
            <capsuleGeometry args={[0.1, 0.5, 4, 8]} />
            <meshStandardMaterial color="#7a5a34" />
          </mesh>
        </group>
        <group ref={legR} position={[0.14, 0.68, 0]}>
          <mesh position={[0, -0.34, 0]} castShadow>
            <capsuleGeometry args={[0.1, 0.5, 4, 8]} />
            <meshStandardMaterial color="#7a5a34" />
          </mesh>
        </group>
      </group>
      <pointLight position={[0, 1.6, 0]} intensity={4} distance={7} color="#ffe8b0" />
    </group>
  );
}

// Glowing links between the hub and live pylons (Endfield power web).
function PowerLinks({ buildings }: { buildings: Building[] }) {
  const live = poweredPylons(buildings);
  const hub = buildings.find((b) => b.kind === "hub");
  if (!hub) return null;
  const pylons = buildings.filter((b) => b.kind === "pylon" && live.has(b.id));
  const nodes = [hub, ...pylons];
  const segs: [THREE.Vector3, THREE.Vector3][] = [];
  const LINK = 16;
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const a = nodes[i], b = nodes[j];
      if (Math.hypot(a.x - b.x, a.z - b.z) <= LINK) {
        const [ax, az] = cellToWorld(a.x, a.z);
        const [bx, bz] = cellToWorld(b.x, b.z);
        segs.push([new THREE.Vector3(ax, 2.2, az), new THREE.Vector3(bx, 2.2, bz)]);
      }
    }
  }
  return (
    <group>
      {segs.map(([a, b], i) => {
        const geo = new THREE.BufferGeometry().setFromPoints([a, b]);
        return (
          <primitive key={i} object={new THREE.Line(geo, new THREE.LineBasicMaterial({ color: "#ffe08a", transparent: true, opacity: 0.7 }))} />
        );
      })}
    </group>
  );
}

// Floating "no power" badge over disconnected machines.
function PowerMarker({ b }: { b: Building }) {
  const m = useRef<THREE.Group>(null);
  const [wx, wz] = cellToWorld(b.x, b.z);
  useFrame((s) => { if (m.current) m.current.position.y = terrainHeight(wx, wz) + b.level * LEVEL_HEIGHT + BUILDINGS[b.kind].height + 0.9 + (getState().paused ? 0 : Math.sin(s.clock.elapsedTime * 3) * 0.12); });
  return (
    <group ref={m} position={[wx, 0, wz]}>
      <mesh>
        <octahedronGeometry args={[0.28, 0]} />
        <meshStandardMaterial color="#e04a2a" emissive="#e04a2a" emissiveIntensity={1.4} toneMapped={false} />
      </mesh>
    </group>
  );
}

export default function World({ pref, href }: { pref: React.MutableRefObject<THREE.Vector3>; href: React.MutableRefObject<number> }) {
  const buildings = useGame((s) => s.buildings);
  const unpoweredIds = useGame((s) => s.unpoweredIds);
  const belts = useGame((s) => s.belts);
  const nodes = useGame((s) => s.nodes);
  const hover = useGame((s) => s.hover);
  const selected = useGame((s) => s.selected);
  const mode = useGame((s) => s.mode);
  const buildLevel = useGame((s) => s.buildLevel);
  const buildRot = useGame((s) => s.buildRot);
  const beltDraft = useGame((s) => s.beltDraft);
  const special = useGame((s) => s.special);
  const vehicles = useGame((s) => s.vehicles);
  const drones = useGame((s) => s.drones);
  const selection = useGame((s) => s.selection);
  const architect = mode === "architect";
  const dragging = useRef(false);
  const [marquee, setMarquee] = useState<{ x0: number; z0: number; x1: number; z1: number } | null>(null);
  const marqueeRef = useRef(false);

  const hoverWorld = useMemo(() => (hover ? cellToWorld(hover.x, hover.z) : null), [hover]);
  const draftBelt = useMemo<Belt | null>(
    () => (beltDraft ? { id: "draft", cells: lPath(beltDraft.start, beltDraft.end) } : null),
    [beltDraft],
  );

  const cellFrom = (e: ThreeEvent<PointerEvent>) => worldToCell(e.point.x, e.point.z);
  const godPainting = useRef(false);
  const panRef = useRef<{ lx: number; ly: number } | null>(null);

  // God/creator brush takes priority in either camera mode.
  const tryGod = (e: ThreeEvent<PointerEvent>) => {
    const g = getState();
    if (!g.adminOpen || !g.godBrush) return false;
    if (e.nativeEvent.button === 2 || g.godBrush === "erase") actions.erasePropNear(e.point.x, e.point.z);
    else actions.placeProp(e.point.x, e.point.z);
    return true;
  };

  const onMove = (e: ThreeEvent<PointerEvent>) => {
    if (marqueeRef.current) { setMarquee((m) => (m ? { ...m, x1: e.point.x, z1: e.point.z } : m)); return; }
    if (panRef.current) {
      const k = 0.09 * getState().architectZoom; // world units per pixel
      actions.panArchitect(-(e.nativeEvent.clientX - panRef.current.lx) * k, -(e.nativeEvent.clientY - panRef.current.ly) * k);
      panRef.current = { lx: e.nativeEvent.clientX, ly: e.nativeEvent.clientY };
      return;
    }
    if (godPainting.current) { const g = getState(); if (g.godBrush === "erase") actions.erasePropNear(e.point.x, e.point.z); else actions.placeProp(e.point.x, e.point.z); return; }
    if (!architect) return;
    const [cx, cz] = cellFrom(e);
    actions.hover({ x: cx, z: cz });
    if (dragging.current) actions.beltMove({ x: cx, z: cz });
  };
  const onDown = (e: ThreeEvent<PointerEvent>) => {
    if (tryGod(e)) { godPainting.current = getState().godBrush !== "erase" ? false : true; return; }
    if (!architect) return;
    const [cx, cz] = cellFrom(e);
    if (e.nativeEvent.button === 2) return actions.remove(cx, cz);
    // A pending blueprint / copy stamp places on the next left click.
    if (e.nativeEvent.button === 0 && getPendingBlueprint()) return actions.place(cx, cz);
    if (e.nativeEvent.button === 0 && !selected && !special) {
      // Shift+drag = rubber-band select; plain drag = pan the camera.
      if (e.nativeEvent.shiftKey) {
        marqueeRef.current = true;
        setMarquee({ x0: e.point.x, z0: e.point.z, x1: e.point.x, z1: e.point.z });
      } else {
        actions.clearSelection();
        panRef.current = { lx: e.nativeEvent.clientX, ly: e.nativeEvent.clientY };
      }
      return;
    }
    if (selected === "conveyor" || special) { dragging.current = true; actions.beltStart({ x: cx, z: cz }); }
    else actions.place(cx, cz);
  };
  const onUp = () => {
    godPainting.current = false;
    panRef.current = null;
    if (marqueeRef.current) {
      marqueeRef.current = false;
      setMarquee((m) => {
        if (m) {
          const minX = Math.min(m.x0, m.x1), maxX = Math.max(m.x0, m.x1);
          const minZ = Math.min(m.z0, m.z1), maxZ = Math.max(m.z0, m.z1);
          const ids = getState().buildings
            .filter((b) => b.kind !== "hub")
            .filter((b) => { const [wx, wz] = cellToWorld(b.x, b.z); return wx >= minX && wx <= maxX && wz >= minZ && wz <= maxZ; })
            .map((b) => b.id);
          actions.setSelection(ids);
        }
        return null;
      });
    }
    if (dragging.current) { dragging.current = false; actions.beltCommit(); }
  };
  useEffect(() => {
    window.addEventListener("pointerup", onUp);
    return () => window.removeEventListener("pointerup", onUp);
  }, []);


  return (
    <>
      <mesh
        rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}
        onPointerMove={onMove} onPointerDown={onDown} onPointerUp={onUp}
        onContextMenu={(e) => e.nativeEvent.preventDefault()}
      >
        <planeGeometry args={[HALF * 2, HALF * 2]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>

      {architect && buildings.filter((b) => b.kind === "pylon" || b.kind === "hub").map((b) => <PowerField key={`f${b.id}`} b={b} />)}
      <PowerLinks buildings={buildings} />
      {buildings.filter((b) => unpoweredIds.includes(b.id)).map((b) => <PowerMarker key={`pm${b.id}`} b={b} />)}
      {nodes.map((n) => <NodeMesh key={n.id} n={n} />)}
      <Pickups />
      {belts.map((belt) => <BeltMesh key={belt.id} belt={belt} />)}
      {draftBelt && <BeltMesh belt={draftBelt} ghost />}
      {vehicles.map((v) => <VehicleMesh key={v.id} v={v} />)}
      {drones.map((d) => <DroneMesh key={d.id} d={d} />)}

      {buildings.map((b) => {
        const [wx, wz] = cellToWorld(b.x, b.z);
        const picked = selection.includes(b.id);
        const body = (
          <group key={b.id} position={[wx, terrainHeight(wx, wz) + b.level * LEVEL_HEIGHT, wz]}>
            {/* support pillar for upper floors */}
            {b.level > 0 && (
              <mesh position={[0, -b.level * LEVEL_HEIGHT / 2, 0]}>
                <boxGeometry args={[0.4, b.level * LEVEL_HEIGHT, 0.4]} />
                <meshStandardMaterial color="#6f5a3e" />
              </mesh>
            )}
            <Machine b={b} />
          </group>
        );
        // Selected buildings get a real post-process outline (falls back to the
        // ground ring below when the composer is off).
        return picked ? <Select key={b.id} enabled>{body}</Select> : body;
      })}

      {architect && selected && selected !== "conveyor" && hoverWorld && hover && (
        <group
          position={[hoverWorld[0], terrainHeight(hoverWorld[0], hoverWorld[1]) + buildLevel * LEVEL_HEIGHT, hoverWorld[1]]}
          rotation={[0, (buildRot * Math.PI) / 2, 0]}
        >
          <mesh position={[0, BUILDINGS[selected].height / 2, 0]}>
            <boxGeometry args={[CELL * 0.9, BUILDINGS[selected].height, CELL * 0.9]} />
            <meshStandardMaterial color={isBuildable(hover.x, hover.z) ? BUILDINGS[selected].color : "#c04040"} transparent opacity={0.4} />
          </mesh>
          {/* facing arrow */}
          <mesh position={[0, 0.1, CELL * 0.5]} rotation={[Math.PI / 2, 0, 0]}>
            <coneGeometry args={[0.22, 0.5, 4]} />
            <meshBasicMaterial color="#eef3e6" transparent opacity={0.8} />
          </mesh>
        </group>
      )}

      {/* rubber-band selection rectangle */}
      {marquee && (
        <mesh
          rotation={[-Math.PI / 2, 0, 0]}
          position={[(marquee.x0 + marquee.x1) / 2, 0.08, (marquee.z0 + marquee.z1) / 2]}
        >
          <planeGeometry args={[Math.abs(marquee.x1 - marquee.x0) || 0.1, Math.abs(marquee.z1 - marquee.z0) || 0.1]} />
          <meshBasicMaterial color="#8fb46a" transparent opacity={0.25} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
      )}
      {/* highlight rings under selected buildings */}
      {selection.length > 0 && buildings.filter((b) => selection.includes(b.id)).map((b) => {
        const [wx, wz] = cellToWorld(b.x, b.z);
        return (
          <mesh key={`sel${b.id}`} position={[wx, terrainHeight(wx, wz) + 0.12 + b.level * LEVEL_HEIGHT, wz]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[CELL * 0.5, CELL * 0.62, 20]} />
            <meshBasicMaterial color="#c8ffa0" transparent opacity={1} side={THREE.DoubleSide} toneMapped={false} />
          </mesh>
        );
      })}

      <GodProps />
      <Player pref={pref} href={href} />
    </>
  );
}
