import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import { BUILDINGS, HOTBAR_ITEMS, HOTBAR_SIZE, HUD_ELEMENTS, ITEM_KEYS, MAX_LEVEL, OBJECTIVES, PALETTE_CATEGORIES, POLLUTION_THRESHOLD, RAW_KEYS, RES_META, TECHS, TOOL_TIERS } from "./config";
import type { BuildingKind, GameState } from "./types";
import { actions, beltStatuses, beltCap, incomingCargo, isPowered, isUnlocked, useGame } from "./store";
import type { RawKey } from "./types";
import Minimap from "./ui/Minimap";

function Meter({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className="min-w-[120px]">
      <div className="mb-1 flex justify-between text-[10px] uppercase tracking-widest text-[#93a986]">
        <span>{label}</span>
        <span className="font-mono text-[#d7e4c8]">{Math.round(value)}</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#d7dcc2]">
        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}
function Stat({ label, value, accent }: { label: string; value: number; accent?: string }) {
  return (
    <div className="flex flex-col">
      <span className="text-[10px] uppercase tracking-widest text-[#93a986]">{label}</span>
      <span className="font-mono text-lg leading-none" style={{ color: accent ?? "#2f3d26" }}>{value.toLocaleString("ru")}</span>
    </div>
  );
}

// Compact air-quality gauge for the architect tab strip: colour ramps from
// clean lilac to alarm orange, pulsing once it nears the storm threshold.
function PollutionBar({ pollution }: { pollution: number }) {
  const pct = Math.max(0, Math.min(100, (pollution / POLLUTION_THRESHOLD) * 100));
  const hot = pollution > 70;
  const color = hot ? "#d9663f" : pollution > 40 ? "#c99a4a" : "#8a7ac0";
  return (
    <span className={`flex items-center gap-1.5 ${hot ? "animate-pulse" : ""}`} title="Загрязнение воздуха — на пороге приходит волна">
      <span style={{ color }}>☁</span>
      <span className="h-1.5 w-16 overflow-hidden rounded-full bg-[#d7dcc2]">
        <span className="block h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
      </span>
      <span className="text-[10px]" style={{ color }}>{Math.round(pollution)}/{POLLUTION_THRESHOLD}</span>
    </span>
  );
}

const panel = "rounded-lg border border-[#3f5648] bg-[#161d17]/90 backdrop-blur";

// Repositionable HUD widget. Reads its offset/scale/visibility from the store;
// in "edit" mode it becomes draggable and shows a labelled dashed outline.
function Movable({ id, className = "", children }: { id: string; className?: string; children: ReactNode }) {
  const l = useGame((s) => s.hudLayout[id]);
  const editing = useGame((s) => s.hudEditing);
  const dx = l?.dx ?? 0, dy = l?.dy ?? 0, scale = l?.scale ?? 1, hidden = l?.hidden ?? false;
  const drag = useRef<{ sx: number; sy: number; ox: number; oy: number } | null>(null);
  if (hidden && !editing) return null;

  const onDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!editing) return;
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.setPointerCapture(e.pointerId);
    drag.current = { sx: e.clientX, sy: e.clientY, ox: dx, oy: dy };
  };
  const onMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!drag.current) return;
    actions.setHudLayout(id, { dx: drag.current.ox + (e.clientX - drag.current.sx), dy: drag.current.oy + (e.clientY - drag.current.sy) });
  };
  const onUp = (e: ReactPointerEvent<HTMLDivElement>) => {
    drag.current = null;
    try { e.currentTarget.releasePointerCapture(e.pointerId); } catch { /* ignore */ }
  };

  return (
    <div
      className={`${className} ${editing ? "pointer-events-auto relative cursor-move rounded-lg outline-dashed outline-2 outline-[#5a7a41]/80" : ""}`}
      style={{ transform: `translate(${dx}px, ${dy}px) scale(${scale})`, transformOrigin: "top left", opacity: hidden ? 0.4 : 1 }}
      onPointerDown={onDown}
      onPointerMove={onMove}
      onPointerUp={onUp}
    >
      {editing && (
        <span className="pointer-events-none absolute -top-4 left-0 z-10 whitespace-nowrap rounded bg-[#123c37] px-1 font-mono text-[9px] text-white">
          {HUD_ELEMENTS.find((h) => h.id === id)?.label ?? id}
        </span>
      )}
      {children}
    </div>
  );
}

function canAfford(res: Record<string, number>, cost: Partial<Record<RawKey, number>>) {
  return RAW_KEYS.every((k) => (res[k] ?? 0) >= (cost[k] ?? 0));
}
function costText(cost: Partial<Record<RawKey, number>>) {
  const parts = Object.entries(cost) as [RawKey, number][];
  if (!parts.length) return "free";
  return parts.map(([k, v]) => `${v}${RES_META[k].icon}`).join(" ");
}
function toolCostText(t: { cost: Partial<Record<RawKey, number>>; mats?: { stick?: number; pebble?: number } }) {
  const parts: string[] = [];
  if (t.mats?.stick) parts.push(`${t.mats.stick}🥢`);
  if (t.mats?.pebble) parts.push(`${t.mats.pebble}⚪`);
  const raw = costText(t.cost);
  if (raw !== "free") parts.push(raw);
  return parts.join(" ") || "free";
}

// Minecraft-style tool belt: a bottom-centre row of slots that auto-hides
// (Satisfactory-like) after a few seconds of inactivity. Scroll or number keys
// change the active slot; the tray above lets you drop owned tools/weapons in.
function Hotbar() {
  const hotbar = useGame((s) => s.hotbar);
  const active = useGame((s) => s.hotbarActive);
  const tools = useGame((s) => s.tools);
  const [visible, setVisible] = useState(true);
  const [trayOpen, setTrayOpen] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const wake = () => {
    setVisible(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => { setVisible(false); setTrayOpen(false); }, 4000);
  };
  // Any change to the belt (scroll/select/craft) wakes the bar back up.
  useEffect(() => { wake(); return () => clearTimeout(timer.current); }, [active, hotbar]);

  // Everything the player currently owns that could sit in a slot.
  const owned: string[] = ["blaster"];
  if (tools.axe > 0) owned.push("axe");
  if (tools.pickaxe > 0) owned.push("pickaxe");
  const unplaced = owned.filter((it) => !hotbar.includes(it));

  return (
    <div
      className="pointer-events-auto absolute inset-x-0 bottom-[7.5rem] flex flex-col items-center gap-2"
      onMouseEnter={wake}
      onMouseMove={wake}
      style={{ opacity: visible ? 1 : 0, transition: "opacity 400ms ease" }}
    >
      {/* assign tray — owned items not yet on the belt */}
      {trayOpen && unplaced.length > 0 && (
        <div className={`flex gap-1.5 ${panel} px-2 py-1.5`}>
          {unplaced.map((it) => (
            <button
              key={it}
              onClick={() => { actions.placeInHotbar(it); setTrayOpen(false); }}
              title={`Поставить: ${HOTBAR_ITEMS[it].label}`}
              className="flex h-11 w-11 items-center justify-center rounded-md border border-[#3f5648] bg-white/50 text-xl transition hover:border-[#5a7a41]"
            >
              {HOTBAR_ITEMS[it].icon}
            </button>
          ))}
        </div>
      )}

      <div className="flex items-end gap-1.5">
        <div className={`flex gap-1 rounded-xl border border-[#3f5648] bg-[#f2f3e4]/90 p-1.5 backdrop-blur`}>
          {hotbar.map((it, i) => {
            const on = i === active;
            const meta = it ? HOTBAR_ITEMS[it] : null;
            return (
              <button
                key={i}
                onClick={() => actions.setHotbarActive(i)}
                onContextMenu={(e) => { e.preventDefault(); actions.clearHotbarSlot(i); }}
                title={meta ? `${meta.label} · [${i + 1}] · ПКМ — убрать` : `Пусто · [${i + 1}]`}
                className={`relative flex h-14 w-14 items-center justify-center rounded-lg border-2 text-2xl transition ${
                  on ? "border-[#5a7a41] bg-[#222c1f] shadow-inner" : "border-[#d0d3b5] bg-white/40 hover:border-[#37c7ac]"
                }`}
              >
                <span className="absolute left-1 top-0.5 font-mono text-[9px] text-[#8a9b73]">{i + 1}</span>
                {meta?.icon}
              </button>
            );
          })}
        </div>
        {unplaced.length > 0 && (
          <button
            onClick={() => setTrayOpen((v) => !v)}
            title="Разместить инструмент/оружие"
            className={`flex h-14 w-10 items-center justify-center rounded-lg border-2 text-lg transition ${
              trayOpen ? "border-[#5a7a41] bg-[#222c1f]" : "border-[#d0d3b5] bg-white/40 hover:border-[#37c7ac]"
            }`}
          >
            +
          </button>
        )}
      </div>
    </div>
  );
}

// Floating chip shown while buildings are rubber-band selected in TAB view.
function SelectionChip() {
  const selection = useGame((s) => s.selection);
  const mode = useGame((s) => s.mode);
  if (mode !== "architect" || selection.length === 0) return null;
  const nudge = "flex h-6 w-6 items-center justify-center rounded border border-[#93a986] text-xs text-[#c8d4b3] hover:border-[#37c7ac]";
  return (
    <div className="pointer-events-auto absolute left-1/2 top-4 z-20 flex -translate-x-1/2 items-center gap-3 rounded-full border border-[#5a7a41] bg-[#33401f]/95 px-4 py-2 text-sm text-[#e9ead6] shadow-lg backdrop-blur">
      <span className="font-semibold">Выбрано: {selection.length}</span>
      {/* nudge the whole group by one cell */}
      <div className="grid grid-cols-3 grid-rows-2 gap-0.5">
        <span />
        <button className={nudge} title="Вверх" onClick={() => actions.moveSelection(0, -1)}>↑</button>
        <span />
        <button className={nudge} title="Влево" onClick={() => actions.moveSelection(-1, 0)}>←</button>
        <button className={nudge} title="Вниз" onClick={() => actions.moveSelection(0, 1)}>↓</button>
        <button className={nudge} title="Вправо" onClick={() => actions.moveSelection(1, 0)}>→</button>
      </div>
      <button onClick={() => actions.copySelection()} className="rounded-full bg-[#5a7a41] px-3 py-1 text-xs font-semibold text-white hover:bg-[#4c6836]">
        📋 Копия
      </button>
      <button onClick={() => actions.deleteSelection()} className="rounded-full bg-[#8a5a4a] px-3 py-1 text-xs font-semibold text-white hover:bg-[#a5695a]">
        🗑 Снести (Del)
      </button>
      <button onClick={() => actions.clearSelection()} className="rounded-full border border-[#93a986] px-3 py-1 text-xs text-[#c8d4b3] hover:border-[#37c7ac]">
        Отмена (Esc)
      </button>
    </div>
  );
}

// Group techs into dependency tiers (columns) so the research panel reads as a
// branching tree: tier 0 = no prerequisites, tier N = one past its deepest req.
const TECH_TIERS: (typeof TECHS)[] = (() => {
  const depth = new Map<string, number>();
  const of = (id: string): number => {
    if (depth.has(id)) return depth.get(id)!;
    const t = TECHS.find((x) => x.id === id);
    const d = !t || t.requires.length === 0 ? 0 : 1 + Math.max(...t.requires.map(of));
    depth.set(id, d);
    return d;
  };
  const cols: (typeof TECHS)[] = [];
  for (const t of TECHS) {
    const d = of(t.id);
    (cols[d] ||= []).push(t);
  }
  return cols;
})();

export default function HUD() {
  const mode = useGame((s) => s.mode);
  const phase = useGame((s) => s.phase);
  const paused = useGame((s) => s.paused);
  const day = useGame((s) => s.day);
  const selected = useGame((s) => s.selected);
  const res = useGame((s) => s.resources);
  const power = useGame((s) => s.power);
  const eff = useGame((s) => s.efficiency);
  const pollution = useGame((s) => s.pollution);
  const baseHp = useGame((s) => s.baseHp);
  const baseHpMax = useGame((s) => s.baseHpMax);
  const monsters = useGame((s) => s.monstersAlive);
  const wave = useGame((s) => s.wave);
  const alert = useGame((s) => s.alert);
  const tools = useGame((s) => s.tools);
  const mats = useGame((s) => s.mats);
  const buildLevel = useGame((s) => s.buildLevel);
  const inventoryOpen = useGame((s) => s.inventoryOpen);
  const craftOpen = useGame((s) => s.craftOpen);
  const special = useGame((s) => s.special);
  const buildRot = useGame((s) => s.buildRot);
  const buildings = useGame((s) => s.buildings);
  const hover = useGame((s) => s.hover);
  const completedObjectives = useGame((s) => s.completedObjectives);
  const researched = useGame((s) => s.researched);
  const architect = mode === "architect";
  const storm = phase === "storm";
  const [tab, setTab] = useState(0);
  const [goalsOpen, setGoalsOpen] = useState(false);
  const [researchOpen, setResearchOpen] = useState(false);
  const [logiOpen, setLogiOpen] = useState(false);
  // The belt sim lives outside the store, so poll it once a second to keep the
  // logistics overview and jam badge live.
  const [, setBeltNonce] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setBeltNonce((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  // Подсказка про TAB сама прячется через несколько секунд, но снова
  // всплывает при каждой смене режима.
  const [hintOn, setHintOn] = useState(true);
  useEffect(() => {
    setHintOn(true);
    const id = setTimeout(() => setHintOn(false), 5000);
    return () => clearTimeout(id);
  }, [mode]);
  const belts = beltStatuses();
  const jamCount = belts.filter((b) => b.jam).length;
  const cap = beltCap();

  // Live objective progress, derived from the same state the store checks.
  const objView = { tools, resources: res, buildings, pollution } as GameState;
  const activeGoal = OBJECTIVES.find((o) => !completedObjectives.includes(o.id));
  const goalsDone = completedObjectives.length;

  const hoverBuilding = architect && hover
    ? buildings.find((b) => b.x === hover.x && b.z === hover.z && b.level === buildLevel)
    : undefined;
  const ROT_LABEL = ["север ↑", "восток →", "юг ↓", "запад ←"];

  const buildBtn = (k: BuildingKind) => {
    const meta = BUILDINGS[k];
    const active = selected === k;
    const unlocked = isUnlocked(k);
    const afford = canAfford(res, meta.cost);
    const lockTech = unlocked ? null : TECHS.find((t) => t.unlocks.includes(k));
    return (
      <button
        key={k}
        onClick={() => (unlocked ? actions.select(k) : setResearchOpen(true))}
        title={unlocked
          ? `${meta.desc} · ${costText(meta.cost)} · ${meta.power >= 0 ? "+" : ""}${meta.power}⚡`
          : `🔒 Требуется исследование: ${lockTech?.name ?? "—"}`}
        className={`relative w-[112px] overflow-hidden rounded-lg border px-2 py-1.5 text-left transition ${
          active ? "border-[#5a7a41] bg-[#222c1f]" : "border-[#3f5648] bg-white/50 hover:border-[#37c7ac]"
        } ${!unlocked ? "opacity-70" : afford ? "" : "opacity-45"}`}
      >
        <div className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm" style={{ background: meta.color }} />
          <span className="text-[12px] font-semibold text-[#d7e4c8]">{meta.label}</span>
        </div>
        <div className="mt-0.5 font-mono text-[9px] uppercase tracking-wide text-[#93a986]">
          {unlocked ? `[${meta.hotkey}] ${costText(meta.cost)}` : `🔒 ${lockTech?.name ?? ""}`}
        </div>
        {!unlocked && <span className="absolute right-1.5 top-1.5 text-[13px] leading-none">🔒</span>}
      </button>
    );
  };

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {/* ---- TOP: title + raw resources + buttons ---- */}
      <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-4">
        <Movable id="title" className="flex flex-col gap-2">
          <div className={`pointer-events-auto ${panel} px-4 py-2`}>
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${storm ? "bg-[#d9663f]" : "bg-[#5a7a41]"}`} />
              <span className="text-sm font-bold tracking-tight text-[#e8f0dd]">Эко-Завод: Грань</span>
              <span className="font-mono text-[10px] uppercase tracking-widest text-[#93a986]">· День {day} · {storm ? "ШТОРМ" : "тишина"}</span>
            </div>
          </div>
        </Movable>

        {/* raw resource strip */}
        <Movable id="resources" className={`pointer-events-auto flex flex-wrap items-center gap-x-4 gap-y-1 ${panel} px-4 py-2`}>
          {RAW_KEYS.map((k) => (
            <div key={k} className="flex items-center gap-1.5" title={RES_META[k].label}>
              <span className="text-base leading-none">{RES_META[k].icon}</span>
              <span className="font-mono text-sm text-[#d7e4c8]">{Math.round(res[k])}</span>
            </div>
          ))}
          <span className="h-4 w-px bg-[#3f5648]" />
          <div className="flex items-center gap-1.5" title="Палки (для крафта)">
            <span className="text-base leading-none">🥢</span>
            <span className="font-mono text-sm text-[#d7e4c8]">{mats.stick}</span>
          </div>
          <div className="flex items-center gap-1.5" title="Камешки (для крафта)">
            <span className="text-base leading-none">⚪</span>
            <span className="font-mono text-sm text-[#d7e4c8]">{mats.pebble}</span>
          </div>
        </Movable>

        <Movable id="toolbar" className="pointer-events-auto flex gap-2">
          <button onClick={() => setGoalsOpen((v) => !v)} title="Задачи" className={`${panel} relative h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>
            🎯
            {activeGoal && <span className="absolute -right-1 -top-1 h-4 min-w-4 rounded-full bg-[#5a7a41] px-1 text-center font-mono text-[9px] leading-4 text-white">{goalsDone}/{OBJECTIVES.length}</span>}
          </button>
          <button onClick={() => actions.toggleCraft()} title="Мастерская (C)" className={`${panel} h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>🔨</button>
          <button onClick={() => setResearchOpen((v) => !v)} title="Исследования" className={`${panel} relative h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>
            🔬
            <span className="absolute -right-1 -top-1 h-4 min-w-4 rounded-full bg-[#5a7a41] px-1 text-center font-mono text-[9px] leading-4 text-white">{researched.length}/{TECHS.length}</span>
          </button>
          <button onClick={() => setLogiOpen((v) => !v)} title="Логистика — грузопотоки и заторы" className={`${panel} relative h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>
            🔗
            {jamCount > 0 && <span className="absolute -right-1 -top-1 h-4 min-w-4 animate-pulse rounded-full bg-[#c0402a] px-1 text-center font-mono text-[9px] leading-4 text-white">{jamCount}</span>}
          </button>
          <button onClick={() => actions.toggleInventory()} title="Инвентарь (I)" className={`${panel} h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>🎒</button>
          <button onClick={() => actions.togglePause()} title="Пауза (P)" className={`${panel} h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>{paused ? "▶" : "⏸"}</button>
          <button onClick={() => actions.toggleAdmin()} title="Центр управления (~)" className={`${panel} h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>⚙</button>
          <button onClick={() => actions.openPauseMenu()} title="Меню (Esc)" className={`${panel} h-9 w-9 text-lg leading-none text-[#e8f0dd] transition hover:border-[#5a7a41]`}>☰</button>
        </Movable>
      </div>

      {/* ---- alert / pause banner ---- */}
      <div className="pointer-events-none absolute inset-x-0 top-[9.25rem] flex flex-col items-center gap-2">
        {alert && (
          <div className={`rounded-lg border px-6 py-2 text-center font-mono text-sm tracking-wide backdrop-blur ${
            storm ? "border-[#d9663f]/60 bg-[#f7e4d8]/90 text-[#a8442a] animate-pulse" : "border-[#5a7a41]/50 bg-[#222c1f]/90 text-[#3c5a2a]"}`}>
            {alert}
          </div>
        )}
        {!alert && paused && !architect && (
          <div className={`${panel} px-5 py-2 font-mono text-sm tracking-widest text-[#e8f0dd]`}>⏸ ПАУЗА</div>
        )}
        <button
          onClick={() => actions.toggleMode()}
          className={`pointer-events-auto rounded-full border border-[#3f5648] bg-[#161d17]/90 px-6 py-2 font-mono text-xs tracking-widest text-[#e8f0dd] backdrop-blur transition-all duration-500 hover:border-[#5a7a41] ${
            hintOn ? "opacity-100" : "pointer-events-none translate-y-1 opacity-0"
          }`}
        >
          [TAB] {architect ? "◈ АРХИТЕКТОР (пауза) → ИССЛЕДОВАТЕЛЬ" : "▣ ИССЛЕДОВАТЕЛЬ → АРХИТЕКТОР"}
        </button>
      </div>

      {/* building inspector — appears when hovering a placed structure */}
      {hoverBuilding && (
        <div className={`pointer-events-none absolute left-4 top-24 w-56 ${panel} px-3 py-2.5`}>
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-sm" style={{ background: BUILDINGS[hoverBuilding.kind].color }} />
            <span className="text-sm font-bold text-[#d7e4c8]">{BUILDINGS[hoverBuilding.kind].label}</span>
          </div>
          <p className="mt-1 text-[11px] leading-snug text-[#93a986]">{BUILDINGS[hoverBuilding.kind].desc}</p>
          <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 font-mono text-[10px] text-[#e8f0dd]">
            <span>HP</span><span className="text-right">{Math.round(hoverBuilding.hp)}</span>
            <span>Энергия</span>
            <span className={`text-right ${BUILDINGS[hoverBuilding.kind].power >= 0 ? "text-[#4c7a2f]" : "text-[#c0402a]"}`}>
              {BUILDINGS[hoverBuilding.kind].power >= 0 ? "+" : ""}{BUILDINGS[hoverBuilding.kind].power}⚡
            </span>
            {BUILDINGS[hoverBuilding.kind].power < 0 && (
              <>
                <span>Питание</span>
                <span className={`text-right ${isPowered(hoverBuilding) ? "text-[#4c7a2f]" : "text-[#c0402a]"}`}>
                  {isPowered(hoverBuilding) ? "есть" : "нет"}
                </span>
              </>
            )}
            <span>Этаж</span><span className="text-right">{hoverBuilding.level + 1}</span>
          </div>
          {(hoverBuilding.kind === "storage" || hoverBuilding.kind === "hub") && (() => {
            const incoming = incomingCargo(hoverBuilding);
            return (
              <div className="mt-2 border-t border-[#d6d9bd] pt-1.5">
                <div className="font-mono text-[9px] uppercase tracking-widest text-[#8a9b73]">Приём с лент</div>
                {incoming.length === 0 ? (
                  <div className="mt-0.5 text-[11px] text-[#a0a890]">— подведите ленту от производителя</div>
                ) : (
                  <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                    {incoming.map(({ res, rate }) => (
                      <span key={res} className="flex items-center gap-1 font-mono text-[11px] text-[#e8f0dd]">
                        {RES_META[res].icon} {RES_META[res].label}
                        <span className="text-[#4c7a2f]">+{rate}/т</span>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            );
          })()}
          <div className="mt-1.5 font-mono text-[9px] uppercase tracking-widest text-[#8a9b73]">{hoverBuilding.kind === "hub" ? "ядро базы" : "ПКМ — снести"}</div>
        </div>
      )}

      {/* marquee selection chip */}
      <SelectionChip />

      {/* floating minimap, bottom-left above the dock */}
      <Movable id="minimap" className="pointer-events-auto absolute bottom-[7.5rem] left-4">
        <Minimap />
      </Movable>

      {/* explorer tool belt */}
      {!architect && <Hotbar />}

      {/* ---- BOTTOM DOCK: full-width department bar ---- */}
      <div className="pointer-events-auto absolute inset-x-0 bottom-0 border-t border-[#3f5648] bg-[#f2f3e4]/95 backdrop-blur">
        {/* department tabs along the top edge */}
        {architect ? (
          <div className="flex items-stretch border-b border-[#d6d9bd] px-2">
            {PALETTE_CATEGORIES.map((cat, i) => (
              <button
                key={cat.label}
                onClick={() => setTab(i)}
                className={`relative -mb-px border-b-2 px-4 py-2 font-mono text-[11px] uppercase tracking-widest transition ${
                  tab === i ? "border-[#5a7a41] text-[#d7e4c8]" : "border-transparent text-[#8a9b73] hover:text-[#e8f0dd]"
                }`}
              >
                {cat.icon} {cat.label}
              </button>
            ))}
            {/* live status pushed to the right edge of the tab strip */}
            <div className="ml-auto flex items-center gap-4 pr-3 font-mono text-[11px]">
              <span className="flex items-center gap-1 text-[#93a986]">
                Этаж
                <button onClick={() => actions.setBuildLevel(-1)} className="rounded border border-[#3f5648] px-1.5 leading-none hover:border-[#5a7a41]">−</button>
                <span className="text-[#d7e4c8]">{buildLevel + 1}/{MAX_LEVEL + 1}</span>
                <button onClick={() => actions.setBuildLevel(1)} className="rounded border border-[#3f5648] px-1.5 leading-none hover:border-[#5a7a41]">+</button>
              </span>
              <span className={power.produced >= power.consumed ? "text-[#4c7a2f]" : "text-[#c0402a]"}>
                ⚡ {power.produced}/{power.consumed} · {Math.round(eff * 100)}%
              </span>
              <PollutionBar pollution={pollution} />
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-5 border-b border-[#d6d9bd] px-4 py-2">
            <Meter label="Целостность базы" value={baseHp} max={baseHpMax} color="#5a7a41" />
            <Meter label="Боезапас" value={res.ammo} max={100} color="#7a5a34" />
            <Meter label="☁ Загрязнение" value={pollution} max={POLLUTION_THRESHOLD} color={pollution > 70 ? "#d9663f" : "#8a7ac0"} />
            {storm && <Stat label="Врагов" value={monsters} accent="#d9663f" />}
            <span className="ml-auto font-mono text-[11px] text-[#93a986]">TAB — вид сверху · C — крафт · I — инвентарь</span>
          </div>
        )}

        {/* department contents */}
        <div className="flex min-h-[64px] flex-wrap items-center gap-2 px-3 py-2.5">
          {architect ? (
            <>
              {PALETTE_CATEGORIES[tab].kinds.map((k: BuildingKind) => buildBtn(k))}
              {/* logistics department also offers programmable haulers & drones */}
              {PALETTE_CATEGORIES[tab].label === "Логистика" && (
                <>
                  <button
                    onClick={() => actions.selectSpecial("vehicle")}
                    title="Тягач: тяни ЛКМ — замкнутый маршрут (12🪵 8⛏)"
                    className={`w-[112px] rounded-lg border px-2 py-1.5 text-left transition ${special === "vehicle" ? "border-[#5a7a41] bg-[#222c1f]" : "border-[#3f5648] bg-white/50 hover:border-[#37c7ac]"}`}
                  >
                    <div className="text-[12px] font-semibold text-[#d7e4c8]">🚚 Тягач</div>
                    <div className="font-mono text-[9px] uppercase text-[#93a986]">маршрут-петля</div>
                  </button>
                  <button
                    onClick={() => actions.selectSpecial("drone")}
                    title="Дрон: тяни ЛКМ между двумя точками — порты (8🪵 6🟠)"
                    className={`w-[112px] rounded-lg border px-2 py-1.5 text-left transition ${special === "drone" ? "border-[#5a7a41] bg-[#222c1f]" : "border-[#3f5648] bg-white/50 hover:border-[#37c7ac]"}`}
                  >
                    <div className="text-[12px] font-semibold text-[#d7e4c8]">🛸 Дрон</div>
                    <div className="font-mono text-[9px] uppercase text-[#93a986]">порт → порт</div>
                  </button>
                </>
              )}
              <span className="ml-auto flex flex-col items-end gap-0.5 text-right font-mono text-[10px] leading-relaxed text-[#8a9b73]">
                <span>ЛКМ — строить · лента/маршрут: тяни ЛКМ · ПКМ — снести</span>
                <span>[R] поворот — <span className="text-[#5a7a41]">{ROT_LABEL[buildRot]}</span></span>
              </span>
            </>
          ) : (
            <span className="font-mono text-[11px] text-[#e8f0dd]">
              W/S — вперёд/назад · A/D — поворот · SHIFT — ускорение · E — рубить/копать{storm ? " · SPACE/ЛКМ — огонь" : ""}
            </span>
          )}
        </div>
      </div>

      {/* ---- CRAFT panel ---- */}
      {craftOpen && (
        <div className="pointer-events-auto absolute left-1/2 top-1/2 w-80 -translate-x-1/2 -translate-y-1/2 rounded-xl border border-[#3f5648] bg-[#161d17]/97 p-5 shadow-2xl backdrop-blur">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-lg font-bold text-[#e8f0dd]">🔨 Мастерская</h3>
            <button onClick={() => actions.toggleCraft()} className="text-[#8a9b73] hover:text-[#e8f0dd]">✕</button>
          </div>
          <p className="mb-2 text-xs text-[#93a986]">Крафтите и улучшайте инструменты. Первый уровень — из палок 🥢 и камешков ⚪ с земли (собирайте клавишей E). Топором — деревья, киркой — камень и руду.</p>
          <div className="mb-3 flex gap-4 rounded-md bg-[#eceedb] px-3 py-1.5 font-mono text-[11px] text-[#e8f0dd]">
            <span>🥢 палки: {mats.stick}</span>
            <span>⚪ камешки: {mats.pebble}</span>
          </div>
          {(["axe", "pickaxe"] as const).map((t) => {
            const tiers = TOOL_TIERS[t];
            const lvl = tools[t]; // 0 = none
            const maxed = lvl >= tiers.length;
            const next = maxed ? null : tiers[lvl];
            const afford = next ? canAfford(res, next.cost) && mats.stick >= (next.mats?.stick ?? 0) && mats.pebble >= (next.mats?.pebble ?? 0) : false;
            const curYield = lvl > 0 ? tiers[lvl - 1].yield : 0;
            return (
              <div key={t} className="mb-2 rounded-lg border border-[#3f5648] bg-white/40 px-3 py-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-[#d7e4c8]">{t === "axe" ? "🪓 Топор" : "⛏ Кирка"}</span>
                  <span className="font-mono text-[10px] text-[#5a7a41]">ур. {lvl}/{tiers.length}{lvl > 0 ? ` · +${curYield}/удар` : ""}</span>
                </div>
                {next ? (
                  <button
                    disabled={!afford}
                    onClick={() => actions.craftTool(t)}
                    className={`mt-1.5 flex w-full items-center justify-between rounded-md border px-2 py-1.5 text-left transition ${afford ? "border-[#5a7a41] bg-[#222c1f] hover:bg-[#2b3625]" : "border-[#3f5648] opacity-45"}`}
                  >
                    <span className="text-[12px] text-[#d7e4c8]">{lvl === 0 ? "Создать" : "Улучшить"}: {next.label} (+{next.yield})</span>
                    <span className="font-mono text-[10px] text-[#93a986]">{toolCostText(next)}</span>
                  </button>
                ) : (
                  <div className="mt-1.5 text-center font-mono text-[10px] text-[#8a9b73]">✓ максимальный уровень</div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ---- INVENTORY panel (processed items) ---- */}
      {inventoryOpen && (
        <div className="pointer-events-auto absolute left-1/2 top-1/2 w-96 -translate-x-1/2 -translate-y-1/2 rounded-xl border border-[#3f5648] bg-[#161d17]/97 p-5 shadow-2xl backdrop-blur">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-lg font-bold text-[#e8f0dd]">🎒 Инвентарь</h3>
            <button onClick={() => actions.toggleInventory()} className="text-[#8a9b73] hover:text-[#e8f0dd]">✕</button>
          </div>
          <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-[#8a9b73]">Сырьё</div>
          <div className="mb-4 grid grid-cols-3 gap-2">
            {RAW_KEYS.map((k) => (
              <div key={k} className="flex items-center gap-2 rounded-lg border border-[#3f5648] bg-white/40 px-2 py-1.5">
                <span className="text-lg">{RES_META[k].icon}</span>
                <div className="leading-tight">
                  <div className="text-[10px] text-[#93a986]">{RES_META[k].label}</div>
                  <div className="font-mono text-sm text-[#d7e4c8]">{Math.round(res[k])}</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mb-2 font-mono text-[10px] uppercase tracking-widest text-[#8a9b73]">Изделия</div>
          <div className="grid grid-cols-3 gap-2">
            {ITEM_KEYS.map((k) => (
              <div key={k} className="flex items-center gap-2 rounded-lg border border-[#3f5648] bg-white/40 px-2 py-1.5">
                <span className="text-lg">{RES_META[k].icon}</span>
                <div className="leading-tight">
                  <div className="text-[10px] text-[#93a986]">{RES_META[k].label}</div>
                  <div className="font-mono text-sm text-[#d7e4c8]">{Math.round(res[k])}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---- STORM threat readout: only during a wave ---- */}
      {storm && (
        <div className="pointer-events-none absolute bottom-28 left-1/2 -translate-x-1/2">
          <div className="flex items-center gap-3 rounded-xl border border-[#d9663f]/60 bg-[#22150f]/85 px-4 py-2 shadow-2xl backdrop-blur-md">
            <span className="text-xl leading-none">⚔</span>
            <div className="leading-tight">
              <div className="text-sm font-bold tracking-wide text-[#ffcbb0]">Волна {wave}</div>
              <div className="font-mono text-[10px] uppercase tracking-wider text-[#d9a08f]">
                {monsters > 0 ? `врагов: ${monsters}` : "зачистка…"}
              </div>
            </div>
            <span className="h-8 w-px bg-[#d9663f]/40" />
            <div className="w-40">
              <div className="mb-0.5 flex justify-between font-mono text-[9px] uppercase tracking-wider text-[#d9a08f]">
                <span>Ядро</span>
                <span>{Math.max(0, Math.round(baseHp))}/{baseHpMax}</span>
              </div>
              <span className="block h-2 overflow-hidden rounded-full bg-[#3a231a]">
                <span
                  className="block h-full rounded-full transition-all"
                  style={{
                    width: `${Math.max(0, Math.min(100, (baseHp / baseHpMax) * 100))}%`,
                    background: baseHp / baseHpMax < 0.3 ? "#d9663f" : baseHp / baseHpMax < 0.6 ? "#e0b45a" : "#7fb85f",
                  }}
                />
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ---- OBJECTIVES panel ---- */}
      {goalsOpen && (
        <div className="pointer-events-auto absolute right-4 top-24 w-80 rounded-xl border border-[#3f5648] bg-[#161d17]/97 p-4 shadow-2xl backdrop-blur">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-base font-bold text-[#e8f0dd]">🎯 Задачи · {goalsDone}/{OBJECTIVES.length}</h3>
            <button onClick={() => setGoalsOpen(false)} className="text-[#8a9b73] hover:text-[#e8f0dd]">✕</button>
          </div>
          <div className="flex max-h-[60vh] flex-col gap-2 overflow-y-auto pr-1">
            {OBJECTIVES.map((o) => {
              const done = completedObjectives.includes(o.id);
              const cur = Math.min(o.goal, Math.floor(o.progress(objView)));
              const pct = done ? 100 : Math.max(0, Math.min(100, (cur / o.goal) * 100));
              const reward = Object.entries(o.reward).map(([k, v]) => `${v}${RES_META[k].icon}`).join(" ");
              return (
                <div key={o.id} className={`rounded-lg border px-3 py-2 ${done ? "border-[#5a7a41] bg-[#222c1f]" : "border-[#3f5648] bg-white/40"}`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[13px] font-semibold text-[#d7e4c8]">{done ? "✓ " : ""}{o.title}</span>
                    <span className="font-mono text-[10px] text-[#5a7a41]">🎁 {reward}</span>
                  </div>
                  <p className="mt-0.5 text-[11px] leading-snug text-[#93a986]">{o.desc}</p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#d7dcc2]">
                      <span className="block h-full rounded-full transition-all" style={{ width: `${pct}%`, background: done ? "#5a7a41" : "#37c7ac" }} />
                    </span>
                    <span className="font-mono text-[10px] text-[#93a986]">{done ? o.goal : cur}/{o.goal}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ---- RESEARCH panel: a branching tech tree laid out in dependency tiers ---- */}
      {researchOpen && (
        <div className="pointer-events-auto absolute right-4 top-24 w-[600px] max-w-[92vw] rounded-xl border border-[#3f5648] bg-[#161d17]/97 p-4 shadow-2xl backdrop-blur">
          <div className="mb-1 flex items-center justify-between">
            <h3 className="text-base font-bold text-[#e8f0dd]">🔬 Дерево технологий · {researched.length}/{TECHS.length}</h3>
            <button onClick={() => setResearchOpen(false)} className="text-[#8a9b73] hover:text-[#e8f0dd]">✕</button>
          </div>
          <p className="mb-3 text-[11px] leading-snug text-[#93a986]">Ветви идут слева направо: каждый следующий узел открывается после своих предшественников.</p>
          <div className="flex max-h-[62vh] gap-3 overflow-auto pb-1 pr-1">
            {TECH_TIERS.map((col, ci) => (
              <div key={ci} className="flex min-w-[168px] flex-1 flex-col gap-2">
                <div className="mb-0.5 text-center font-mono text-[9px] uppercase tracking-widest text-[#6f7f57]">
                  {ci === 0 ? "Базовые" : `Уровень ${ci + 1}`}
                </div>
                {col.map((t) => {
                  const done = researched.includes(t.id);
                  const reqOk = t.requires.every((r) => researched.includes(r));
                  const afford = canAfford(res, t.cost);
                  const reqNames = t.requires.map((r) => TECHS.find((x) => x.id === r)?.name).filter(Boolean).join(", ");
                  const opens = t.unlocks.map((k) => BUILDINGS[k].label).join(", ");
                  return (
                    <div
                      key={t.id}
                      className={`relative rounded-lg border px-2.5 py-2 transition ${
                        done ? "border-[#5a7a41] bg-[#222c1f]" : reqOk ? "border-[#37c7ac]/50 bg-white/40" : "border-[#42463c] bg-black/20 opacity-75"
                      }`}
                    >
                      {/* rail stub linking back to the previous tier */}
                      {ci > 0 && <span className={`absolute -left-3 top-1/2 h-px w-3 ${done ? "bg-[#5a7a41]" : reqOk ? "bg-[#37c7ac]/60" : "bg-[#42463c]"}`} />}
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[12px] font-semibold text-[#d7e4c8]">{t.icon} {t.name}</span>
                        {done ? <span className="text-[11px] text-[#7fb85f]">✓</span> : <span className="font-mono text-[9px] text-[#93a986]">{costText(t.cost)}</span>}
                      </div>
                      <p className="mt-0.5 text-[10px] leading-snug text-[#93a986]">{t.desc}</p>
                      <p className="mt-0.5 font-mono text-[9px] text-[#7a8a5f]">🔓 {t.effect ? t.effect.label : opens}</p>
                      {!reqOk && !done && <p className="mt-0.5 font-mono text-[9px] text-[#c0805a]">← {reqNames}</p>}
                      {!done && (
                        <button
                          onClick={() => actions.research(t.id)}
                          disabled={!reqOk || !afford}
                          className={`mt-1.5 w-full rounded-md border px-2 py-1 font-mono text-[10px] transition ${
                            reqOk && afford ? "border-[#5a7a41] bg-[#5a7a41] text-white hover:bg-[#4c6a36]" : "cursor-not-allowed border-[#3f5648] bg-white/30 text-[#a0a890]"
                          }`}
                        >
                          {reqOk ? (afford ? "Исследовать" : "Мало ресурсов") : "🔒 Закрыто"}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---- LOGISTICS overview: live cargo & jams across every belt ---- */}
      {logiOpen && (
        <div className="pointer-events-auto absolute right-4 top-24 w-96 rounded-xl border border-[#3f5648] bg-[#161d17]/97 p-4 shadow-2xl backdrop-blur">
          <div className="mb-1 flex items-center justify-between">
            <h3 className="text-base font-bold text-[#e8f0dd]">🔗 Логистика · {belts.length} лент</h3>
            <button onClick={() => setLogiOpen(false)} className="text-[#8a9b73] hover:text-[#e8f0dd]">✕</button>
          </div>
          <p className="mb-3 text-[11px] leading-snug text-[#93a986]">
            {jamCount > 0
              ? <span className="text-[#c0402a]">⚠ Заторов: {jamCount} — лента переполнена. Подведите её к складу/ратуше или разгрузите приёмник.</span>
              : "Каждая лента буферизует груз. Зелёная — течёт к приёмнику, серая — в никуда."}
          </p>
          {belts.length === 0 ? (
            <div className="rounded-lg border border-[#3f5648] bg-white/40 px-3 py-4 text-center text-[11px] text-[#a0a890]">
              Лент пока нет. Постройте конвейер от производителя к складу.
            </div>
          ) : (
            <div className="flex max-h-[60vh] flex-col gap-1.5 overflow-y-auto pr-1">
              {belts.map((b, i) => {
                const pct = Math.max(0, Math.min(100, (b.load / cap) * 100));
                const empty = !b.res || b.load <= 0;
                const bar = b.jam ? "#c0402a" : empty ? "#3f5648" : b.res ? RES_META[b.res].color : "#37c7ac";
                const status = b.jam ? "затор" : empty ? "пусто" : b.toSink ? "→ склад" : "в никуда";
                const statusColor = b.jam ? "text-[#c0402a]" : b.toSink && !empty ? "text-[#4c7a2f]" : "text-[#8a9b73]";
                return (
                  <div key={b.id} className={`rounded-lg border px-3 py-1.5 ${b.jam ? "border-[#d9a08f] bg-[#f7e4d8]/60" : "border-[#3f5648] bg-white/40"}`}>
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-[12px] font-semibold text-[#d7e4c8]">
                        <span className="font-mono text-[10px] text-[#a0a890]">#{i + 1}</span>
                        {b.res ? `${RES_META[b.res].icon} ${RES_META[b.res].label}` : "— пусто"}
                      </span>
                      <span className={`font-mono text-[10px] ${statusColor}`}>{b.jam ? "⚠ " : ""}{status}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#d7dcc2]">
                        <span className="block h-full rounded-full transition-all" style={{ width: `${pct}%`, background: bar }} />
                      </span>
                      <span className="font-mono text-[10px] text-[#93a986]">{Math.round(b.load)}/{cap}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
