import { Canvas } from "@react-three/fiber";
import { Bloom, EffectComposer, Outline, Selection, Vignette } from "@react-three/postprocessing";
import { BlendFunction } from "postprocessing";
import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import CameraRig from "./CameraRig";
import Combat from "./Combat";
import Environment from "./Environment";
import HUD from "./HUD";
import Movement from "./Movement";
import World from "./World";
import Menu from "./ui/Menu";
import WorldMap from "./ui/WorldMap";
import BiomeTransition from "./ui/BiomeTransition";
import DayClock from "./ui/DayClock";
import Tutorial from "./ui/Tutorial";
import AdminPanel from "./ui/AdminPanel";
import PauseMenu from "./ui/PauseMenu";
import { KIND_ORDER } from "./config";
import { actions, getState, useGame } from "./store";
import { useKeyboard } from "./useKeyboard";

// Probe for a usable WebGL context so we can degrade gracefully instead of
// letting the renderer throw when the driver can't create one.
function hasWebGL(): boolean {
  try {
    const c = document.createElement("canvas");
    return !!(window.WebGLRenderingContext && (c.getContext("webgl") || c.getContext("experimental-webgl")));
  } catch {
    return false;
  }
}

function WebGLFallback({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="flex h-full w-full items-center justify-center bg-[#a7cfc6] p-6">
      <div className="max-w-md rounded-2xl border border-[#3f5648] bg-[#161d17] p-6 text-center shadow-2xl">
        <div className="mb-2 text-3xl">🌿</div>
        <h2 className="mb-2 text-lg font-bold text-[#e8f0dd]">Не удалось запустить 3D</h2>
        <p className="mb-4 text-sm leading-snug text-[#93a986]">
          Браузеру не удалось создать WebGL-контекст. Обычно помогает включить аппаратное ускорение в настройках браузера и перезагрузить страницу.
        </p>
        <button onClick={onRetry} className="rounded-lg border border-[#5a7a41] bg-[#222c1f] px-5 py-2 text-sm font-semibold text-[#e8f0dd] transition hover:bg-[#2b3625]">
          Повторить
        </button>
      </div>
    </div>
  );
}

export default function Game() {
  const screen = useGame((s) => s.screen);
  const mode = useGame((s) => s.mode);
  const tutorial = useGame((s) => s.tutorial);
  const adminOpen = useGame((s) => s.adminOpen);
  const pauseMenuOpen = useGame((s) => s.pauseMenuOpen);
  const worldMapOpen = useGame((s) => s.worldMapOpen);
  const alert = useGame((s) => s.alert);
  const quality = useGame((s) => s.settings.quality);
  const shadows = useGame((s) => s.settings.shadows);
  const bloom = useGame((s) => s.settings.bloom);
  const bloomIntensity = useGame((s) => s.settings.bloomIntensity);
  const bloomThreshold = useGame((s) => s.settings.bloomThreshold);
  const keys = useKeyboard();
  const pref = useRef(new THREE.Vector3(0, 0, 0));
  const href = useRef(0);
  const [webglOK, setWebglOK] = useState(hasWebGL);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (getState().screen !== "playing") return;
      if (e.code === "Tab") { e.preventDefault(); actions.toggleMode(); return; }
      if (document.activeElement?.tagName === "INPUT") return;
      if (e.code === "KeyP") actions.togglePause();
      if (e.code === "KeyE") actions.chopNearest();
      if (e.code === "KeyR") actions.rotateBuild();
      if (e.code === "KeyC") actions.toggleCraft();
      if (e.code === "KeyI") actions.toggleInventory();
      if (e.code === "BracketLeft") actions.setBuildLevel(-1);
      if (e.code === "BracketRight") actions.setBuildLevel(1);
      if (e.code === "Backquote") actions.toggleAdmin();
      if ((e.code === "Delete" || e.code === "Backspace") && getState().selection.length) { actions.deleteSelection(); return; }
      if (e.code === "Escape") {
        const s = getState();
        if (s.worldMapOpen) return actions.closeWorldMap();
        if (s.selection.length) return actions.clearSelection();
        if (s.craftOpen) return actions.toggleCraft();
        if (s.inventoryOpen) return actions.toggleInventory();
        if (s.adminOpen) return actions.toggleAdmin();
        if (s.pauseMenuOpen) return actions.closePauseMenu();
        actions.openPauseMenu();
        return;
      }
      const m = e.code.match(/^Digit([1-9])$/);
      if (m) {
        const n = Number(m[1]) - 1;
        if (getState().mode === "explore") actions.setHotbarActive(n);
        else actions.select(KIND_ORDER[n] ?? null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Mouse wheel: zoom the top-down architect view, or cycle the hotbar slot
  // while exploring.
  useEffect(() => {
    // Suppress page scroll while playing; the actual zoom/hotbar handling lives
    // on the container's React onWheel (fires reliably inside the preview frame).
    const onWheel = (e: WheelEvent) => {
      if (getState().screen === "playing") e.preventDefault();
    };
    window.addEventListener("wheel", onWheel, { passive: false });
    return () => window.removeEventListener("wheel", onWheel);
  }, []);

  useEffect(() => {
    const id = setInterval(() => actions.tick(), 1000);
    return () => clearInterval(id);
  }, []);

  // Autosave the running session so it persists across reloads / exits.
  useEffect(() => {
    const id = setInterval(() => { if (getState().screen === "playing") actions.autosave(); }, 15000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (alert && (getState().phase === "day")) {
      const id = setTimeout(() => actions.clearAlert(), 3500);
      return () => clearTimeout(id);
    }
  }, [alert]);

  if (!webglOK) return <WebGLFallback onRetry={() => setWebglOK(hasWebGL())} />;

  const onWheel = (e: React.WheelEvent) => {
    if (getState().screen !== "playing") return;
    if (getState().mode === "architect") actions.zoomArchitect(Math.sign(e.deltaY));
    else actions.scrollHotbar(Math.sign(e.deltaY));
  };

  return (
    <div className="relative h-full w-full" onWheel={onWheel}>
      <Canvas
        shadows={shadows}
        dpr={[1, quality === "high" ? 2 : quality === "medium" ? 1.5 : 1]}
        camera={{ position: [-6, 6.5, 11], fov: 52 }}
        gl={{ antialias: true, powerPreference: "high-performance", failIfMajorPerformanceCaveat: false, alpha: false }}
        onCreated={({ scene }) => {
          scene.fog = new THREE.Fog("#a7cfc6", 95, 320);
          scene.background = new THREE.Color("#a7cfc6");
        }}
      >
        <CameraRig mode={mode} playerRef={pref} href={href} />
        <Movement keys={keys} pref={pref} href={href} mode={mode} />
        <Environment />
        <Selection>
          <World pref={pref} href={href} />
          <Combat pref={pref} />
          {quality !== "low" && bloom && (
            <EffectComposer enableNormalPass={false} autoClear={false}>
              <Bloom intensity={bloomIntensity} luminanceThreshold={bloomThreshold} luminanceSmoothing={0.25} mipmapBlur />
              <Outline blur edgeStrength={6} visibleEdgeColor={0xc8ffa0} hiddenEdgeColor={0x6f9a3e} blendFunction={BlendFunction.SCREEN} />
              <Vignette offset={0.22} darkness={0.5} eskil={false} />
            </EffectComposer>
          )}
        </Selection>
      </Canvas>

      {screen === "playing" && <HUD />}
      {screen === "playing" && <DayClock />}
      {screen === "playing" && tutorial && <Tutorial />}
      {screen === "playing" && adminOpen && <AdminPanel />}
      {screen === "playing" && pauseMenuOpen && <PauseMenu />}
      {screen === "playing" && worldMapOpen && <WorldMap />}
      {screen === "playing" && <BiomeTransition />}
      {screen === "menu" && <Menu />}
    </div>
  );
}
