import { actions, useGame } from "../store";

const STEPS = [
  { t: "Два режима", d: "TAB переключает Исследователя (3D-бег) и Архитектора (вид сверху). В Архитекторе время на тактической паузе — стройте спокойно." },
  { t: "Стройте", d: "В Архитекторе выберите здание в панели снизу (или клавиши 1–9) и щёлкните по поляне. Начните с Бура на жиле руды и Печи рядом." },
  { t: "Тяните ленту", d: "Выберите «Лента» (2) и зажмите ЛКМ от одной точки к другой — конвейер протянется сам, как в Satisfactory." },
  { t: "Питание", d: "Зданиям нужна энергия. Ставьте «Столб» (пилон) — он питает всё в своём радиусе (зелёный круг). Ратуша тоже питает вокруг себя." },
  { t: "Экология и оборона", d: "Фабрики копят загрязнение. На пороге приходит ШТОРМ — орда идёт на базу. Ставьте Баллисты и Частокол, а в режиме Исследователя стреляйте (SPACE/ЛКМ)." },
  { t: "Готово!", d: "Сохраняйтесь и правьте показатели в Админ-панели (кнопка ⚙ справа сверху). Удачи, смотритель!" },
];

export default function Tutorial() {
  const step = useGame((s) => s.tutorialStep);
  const s = STEPS[Math.min(step, STEPS.length - 1)];
  const last = step >= STEPS.length - 1;
  return (
    <div className="absolute bottom-28 left-1/2 z-20 w-[440px] -translate-x-1/2 rounded-xl border border-[#5a7a41]/40 bg-[#161d17]/95 p-5 shadow-xl backdrop-blur">
      <div className="mb-1 flex items-center justify-between">
        <span className="font-mono text-[11px] uppercase tracking-widest text-[#5a7a41]">
          Обучение {step + 1}/{STEPS.length}
        </span>
        <button onClick={() => actions.skipTutorial()} className="text-xs text-[#8a9b73] hover:text-[#93a986]">
          пропустить ✕
        </button>
      </div>
      <h3 className="mb-1.5 text-lg font-bold text-[#d7e4c8]">{s.t}</h3>
      <p className="mb-4 text-sm leading-relaxed text-[#93a986]">{s.d}</p>
      <button
        onClick={() => (last ? actions.skipTutorial() : actions.nextTutorial())}
        className="rounded-lg bg-[#5a7a41] px-5 py-2 text-sm font-semibold text-white transition hover:bg-[#4c6836]"
      >
        {last ? "Начать игру" : "Далее →"}
      </button>
    </div>
  );
}
