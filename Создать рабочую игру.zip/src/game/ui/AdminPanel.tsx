import { useEffect, useRef, useState } from "react";
import { actions, getState, useGame } from "../store";
import { HUD_ELEMENTS, PROP_CATALOG } from "../config";
import { audio } from "../audio";
import type { PropKind } from "../types";

// Live-edit numeric field (blur / Enter commits).
function Num({ label, value, onCommit }: { label: string; value: number; onCommit: (v: number) => void }) {
  const [v, setV] = useState(String(value));
  return (
    <label className="flex items-center justify-between gap-3 py-1.5">
      <span className="text-sm text-[#c8d4b3]">{label}</span>
      <input
        type="number"
        value={v}
        onChange={(e) => setV(e.target.value)}
        onBlur={() => onCommit(Number(v) || 0)}
        onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
        className="w-24 rounded-md border border-[#93a986] bg-[#2c3720] px-2 py-1 text-right font-mono text-sm text-[#e9ead6] outline-none focus:border-[#37c7ac]"
      />
    </label>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return <div className="mb-1 font-mono text-[10px] uppercase tracking-widest text-[#a9b992]">{children}</div>;
}

// A single paintable prop button. Highlights when it's the active brush.
function PropButton({ kind, label, glyph }: { kind: PropKind; label: string; glyph: string }) {
  const active = useGame((s) => s.godBrush === kind);
  return (
    <button
      onClick={() => actions.setGodBrush(kind)}
      className={`flex w-[68px] shrink-0 flex-col items-center gap-1 rounded-lg border px-2 py-2 transition ${
        active ? "border-[#37c7ac] bg-[#4a5b32] shadow-[0_0_0_2px_#37c7ac55]" : "border-[#2c3720] bg-[#33401f]/70 hover:border-[#5a7a41]"
      }`}
    >
      <span className="text-2xl leading-none">{glyph}</span>
      <span className="text-[10px] leading-tight text-[#d4dcc4]">{label}</span>
    </button>
  );
}

// ---- section: paintable props (Природа / Строения / Существа) ----
function PropsSection({ index }: { index: number }) {
  const group = PROP_CATALOG[index];
  const eraseActive = useGame((s) => s.godBrush === "erase");
  const count = useGame((s) => s.props.length);
  return (
    <div className="flex items-center gap-3">
      <div className="flex gap-2 overflow-x-auto py-1">
        {group.items.map((it) => <PropButton key={it.kind} kind={it.kind} label={it.label} glyph={it.glyph} />)}
      </div>
      <div className="ml-auto flex shrink-0 flex-col gap-1.5 border-l border-[#2c3720] pl-3">
        <button
          onClick={() => actions.setGodBrush("erase")}
          className={`rounded-md px-3 py-1.5 text-xs font-semibold transition ${
            eraseActive ? "bg-[#8a5a4a] text-white" : "border border-[#93a986] text-[#e0a99a] hover:border-[#8a5a4a]"
          }`}
        >
          🩹 Ластик
        </button>
        <button
          onClick={() => actions.clearProps()}
          className="rounded-md border border-[#93a986] px-3 py-1.5 text-xs text-[#c8d4b3] hover:border-[#37c7ac]"
        >
          Очистить · {count}
        </button>
      </div>
    </div>
  );
}

// ---- section: atmosphere (weather / time / particles / audio) ----
function AtmosphereSection() {
  const settings = useGame((s) => s.settings);
  const weather = useGame((s) => s.weather);
  const timeOfDay = useGame((s) => s.timeOfDay);
  const chip = (on: boolean) =>
    `rounded-md px-3 py-1.5 text-xs font-semibold transition ${on ? "bg-[#5a7a41] text-white" : "border border-[#93a986] text-[#c8d4b3] hover:border-[#37c7ac]"}`;
  const auto = timeOfDay == null;
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-[10px] uppercase tracking-widest text-[#a9b992]">Погода</span>
        <button className={chip(weather === "clear")} onClick={() => actions.setWeather("clear")}>☀ Ясно</button>
        <button className={chip(weather === "rain")} onClick={() => actions.setWeather("rain")}>🌧 Дождь</button>
        <button className="rounded-md border border-[#93a986] px-3 py-1.5 text-xs text-[#c8d4b3] hover:border-[#37c7ac]" onClick={() => actions.admin({ phase: getState().phase === "storm" ? "day" : "storm" })}>
          🌩 День / Буря
        </button>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-[10px] uppercase tracking-widest text-[#a9b992]">Время</span>
        <button className={chip(auto)} onClick={() => actions.setTimeOfDay(auto ? 0.4 : null)}>{auto ? "🔄 Авто-цикл" : "⏸ Зафиксировано"}</button>
        <input
          type="range" min={0} max={1} step={0.01} value={timeOfDay ?? 0.4} disabled={auto}
          onChange={(e) => actions.setTimeOfDay(Number(e.target.value))}
          className="w-56 accent-[#37c7ac] disabled:opacity-40"
        />
        {!auto && <span className="font-mono text-xs text-[#c8d4b3]">{Math.round((timeOfDay ?? 0) * 24)}:00</span>}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-[10px] uppercase tracking-widest text-[#a9b992]">Эффекты</span>
        <button className={chip(settings.particles)} onClick={() => actions.setSettings({ particles: !settings.particles })}>✨ Частицы</button>
        <button className={chip(settings.clouds)} onClick={() => actions.setSettings({ clouds: !settings.clouds })}>☁ Облака</button>
        <button className={chip(settings.shadows)} onClick={() => actions.setSettings({ shadows: !settings.shadows })}>🌑 Тени</button>
        <button className={chip(settings.bloom)} onClick={() => actions.setSettings({ bloom: !settings.bloom })}>✨ Свечение</button>
        <span className="mx-1 h-6 w-px bg-[#2c3720]" />
        <span className="font-mono text-[10px] uppercase tracking-widest text-[#a9b992]">Звук</span>
        {(["place", "hit", "shoot", "alarm", "click"] as const).map((s) => (
          <button key={s} className="rounded-md border border-[#93a986] px-2.5 py-1.5 text-xs text-[#c8d4b3] hover:border-[#37c7ac]"
            onClick={() => { audio.start(); audio.play(s); }}>
            ♪ {s}
          </button>
        ))}
      </div>
      {settings.bloom && (
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
          <span className="font-mono text-[10px] uppercase tracking-widest text-[#a9b992]">Свечение</span>
          <label className="flex items-center gap-2 text-xs text-[#c8d4b3]">
            Сила
            <input type="range" min={0} max={2} step={0.05} value={settings.bloomIntensity}
              onChange={(e) => actions.setSettings({ bloomIntensity: Number(e.target.value) })} className="accent-[#37c7ac]" />
            <span className="w-8 font-mono">{settings.bloomIntensity.toFixed(2)}</span>
          </label>
          <label className="flex items-center gap-2 text-xs text-[#c8d4b3]">
            Порог
            <input type="range" min={0} max={1} step={0.02} value={settings.bloomThreshold}
              onChange={(e) => actions.setSettings({ bloomThreshold: Number(e.target.value) })} className="accent-[#37c7ac]" />
            <span className="w-8 font-mono">{settings.bloomThreshold.toFixed(2)}</span>
          </label>
        </div>
      )}
    </div>
  );
}

// ---- section: world numbers + save/load/reset ----
function WorldSection() {
  const res = useGame((s) => s.resources);
  const pollution = useGame((s) => s.pollution);
  const day = useGame((s) => s.day);
  const baseHp = useGame((s) => s.baseHp);
  const setRes = (k: keyof typeof res, v: number) => actions.admin({ resources: { ...getState().resources, [k]: v } });
  return (
    <div className="grid grid-cols-3 gap-x-6">
      <div>
        <SectionLabel>Ресурсы</SectionLabel>
        <Num label="Древесина" value={res.wood} onCommit={(v) => setRes("wood", v)} />
        <Num label="Железо" value={res.iron} onCommit={(v) => setRes("iron", v)} />
        <Num label="Медь" value={res.copper} onCommit={(v) => setRes("copper", v)} />
      </div>
      <div>
        <SectionLabel>Мир</SectionLabel>
        <Num label="День" value={day} onCommit={(v) => actions.admin({ day: v })} />
        <Num label="Загрязнение" value={Math.round(pollution)} onCommit={(v) => actions.admin({ pollution: v })} />
        <Num label="Целостность базы" value={Math.round(baseHp)} onCommit={(v) => actions.admin({ baseHp: v, baseHpMax: Math.max(v, getState().baseHpMax) })} />
      </div>
      <div className="flex flex-col justify-end gap-2">
        <div className="flex gap-2">
          <button onClick={() => actions.save()} className="flex-1 rounded-md bg-[#5a7a41] px-3 py-2 text-sm font-semibold hover:bg-[#4c6836]">💾 Сохранить</button>
          <button onClick={() => actions.load()} className="flex-1 rounded-md border border-[#93a986] px-3 py-2 text-sm hover:border-[#37c7ac]">↺ Загрузить</button>
        </div>
        <button onClick={() => actions.reset()} className="rounded-md border border-[#8a5a4a] px-3 py-2 text-sm text-[#e0a99a] hover:bg-[#4a2c26]">⟲ Сбросить базу</button>
      </div>
    </div>
  );
}

// ---- section: camera limits (top-down view) ----
function CameraSection() {
  const maxZoom = useGame((s) => s.settings.maxZoom);
  const zoom = useGame((s) => s.architectZoom);
  return (
    <div className="flex flex-wrap items-center gap-x-8 gap-y-3">
      <label className="flex items-center gap-3">
        <span className="w-52 text-sm text-[#c8d4b3]">Макс. отдаление камеры · {maxZoom.toFixed(1)}×</span>
        <input
          type="range" min={1} max={6} step={0.1} value={maxZoom}
          onChange={(e) => actions.setSettings({ maxZoom: Number(e.target.value) })}
          className="w-56 accent-[#37c7ac]"
        />
      </label>
      <div className="text-xs text-[#8a9b73]">Сейчас: {zoom.toFixed(1)}× (колёсико — зум, ЛКМ по земле зажать — двигать)</div>
      <button onClick={() => actions.resetArchitectPan()} className="rounded-md border border-[#93a986] px-3 py-1.5 text-xs text-[#c8d4b3] hover:border-[#37c7ac]">
        🎯 Вернуть камеру к базе
      </button>
    </div>
  );
}

// ---- section: live statistics (energy & pollution over time) ----
function StatsSection() {
  const stats = useGame((s) => s.stats);
  const power = useGame((s) => s.power);
  const pollution = useGame((s) => s.pollution);
  const canvas = useRef<HTMLCanvasElement>(null);
  const W = 640, H = 150;

  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = "#2c3720";
    ctx.fillRect(0, 0, W, H);
    // gridlines
    ctx.strokeStyle = "#3c4a2e";
    ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo(0, (H / 4) * i); ctx.lineTo(W, (H / 4) * i); ctx.stroke(); }
    if (stats.length < 2) {
      ctx.fillStyle = "#8a9b73";
      ctx.font = "12px monospace";
      ctx.fillText("Сбор данных… (обновляется раз в секунду)", 16, H / 2);
      return;
    }
    const maxPow = Math.max(10, ...stats.map((s) => Math.max(s.produced, s.consumed)));
    const maxPol = Math.max(10, ...stats.map((s) => s.pollution));
    const line = (key: "produced" | "consumed" | "pollution", color: string, max: number) => {
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.beginPath();
      stats.forEach((s, i) => {
        const x = (i / (stats.length - 1)) * W;
        const y = H - (s[key] / max) * (H - 8) - 4;
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      });
      ctx.stroke();
    };
    line("produced", "#37c7ac", maxPow);
    line("consumed", "#e0b45a", maxPow);
    line("pollution", "#d9663f", maxPol);
  }, [stats]);

  const Legend = ({ c, t, v }: { c: string; t: string; v: string }) => (
    <span className="flex items-center gap-1.5 text-xs text-[#c8d4b3]">
      <span className="inline-block h-2.5 w-2.5 rounded-sm" style={{ background: c }} />{t}: <b className="text-[#e9ead6]">{v}</b>
    </span>
  );
  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-wrap gap-4">
        <Legend c="#37c7ac" t="Энергия" v={String(power.produced)} />
        <Legend c="#e0b45a" t="Потребление" v={String(power.consumed)} />
        <Legend c="#d9663f" t="Загрязнение" v={String(Math.round(pollution))} />
      </div>
      <canvas ref={canvas} width={W} height={H} className="w-full rounded-lg border border-[#2c3720]" />
    </div>
  );
}

// ---- section: interface layout editor ----
function InterfaceSection() {
  const layout = useGame((s) => s.hudLayout);
  const editing = useGame((s) => s.hudEditing);
  return (
    <div className="flex items-start gap-4">
      <button
        onClick={() => actions.toggleHudEdit()}
        className={`shrink-0 rounded-md px-4 py-2 text-sm font-semibold transition ${
          editing ? "bg-[#37c7ac] text-[#22331a]" : "bg-[#5a7a41] text-white hover:bg-[#4c6836]"
        }`}
      >
        {editing ? "✓ Двигайте виджеты мышью" : "✥ Включить перетаскивание"}
      </button>
      <div className="flex flex-wrap gap-2">
        {HUD_ELEMENTS.map((el) => {
          const l = layout[el.id] ?? { dx: 0, dy: 0, scale: 1, hidden: false };
          return (
            <div key={el.id} className="rounded-lg border border-[#2c3720] bg-[#33401f]/60 px-3 py-2">
              <div className="mb-1 flex items-center gap-2">
                <span className="text-xs font-semibold text-[#e9ead6]">{el.label}</span>
                <button
                  onClick={() => actions.setHudLayout(el.id, { hidden: !l.hidden })}
                  className={`rounded px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wide transition ${
                    l.hidden ? "bg-[#8a5a4a] text-white" : "border border-[#93a986] text-[#c8d4b3]"
                  }`}
                >
                  {l.hidden ? "скрыт" : "виден"}
                </button>
              </div>
              <label className="flex items-center gap-2">
                <span className="text-[10px] text-[#c8d4b3]">{Math.round(l.scale * 100)}%</span>
                <input type="range" min={0.6} max={1.8} step={0.05} value={l.scale}
                  onChange={(e) => actions.setHudLayout(el.id, { scale: Number(e.target.value) })}
                  className="w-24 accent-[#37c7ac]" />
              </label>
            </div>
          );
        })}
        <button onClick={() => actions.resetHudLayout()} className="self-center rounded-md border border-[#93a986] px-3 py-2 text-xs text-[#c8d4b3] hover:border-[#37c7ac]">
          ⟲ Сброс
        </button>
      </div>
    </div>
  );
}

const SECTIONS = [
  ...PROP_CATALOG.map((g, i) => ({ id: `prop${i}`, label: g.section, icon: g.icon, render: () => <PropsSection index={i} /> })),
  { id: "atmo", label: "Атмосфера", icon: "🌦", render: () => <AtmosphereSection /> },
  { id: "cam", label: "Камера", icon: "🎥", render: () => <CameraSection /> },
  { id: "stats", label: "Статистика", icon: "📈", render: () => <StatsSection /> },
  { id: "world", label: "Мир", icon: "🌍", render: () => <WorldSection /> },
  { id: "ui", label: "Интерфейс", icon: "🎚", render: () => <InterfaceSection /> },
];

// God/Creator mode: a sectioned palette docked ABOVE the build strip. Selecting
// a prop makes it the active brush — click the ground to paint it anywhere.
export default function AdminPanel() {
  const [tab, setTab] = useState(0);
  const brush = useGame((s) => s.godBrush);
  const active = SECTIONS[tab] ?? SECTIONS[0];

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-28 z-30 flex justify-center px-4">
      <div className="pointer-events-auto w-full max-w-4xl overflow-hidden rounded-2xl border border-[#2c3720] bg-[#123c37]/97 text-[#e9ead6] shadow-2xl backdrop-blur">
        {/* header */}
        <div className="flex items-center justify-between border-b border-[#2c3720] bg-[#33401f] px-4 py-2">
          <div className="flex items-center gap-2">
            <span className="text-base font-bold">🪄 Режим Творца</span>
            {brush && (
              <span className="rounded-full bg-[#5a7a41] px-2 py-0.5 text-[11px] font-semibold">
                кисть: {brush === "erase" ? "ластик" : brush} · клик по земле
              </span>
            )}
          </div>
          <button
            onClick={() => actions.toggleAdmin()}
            className="rounded-md px-2 py-0.5 text-lg text-[#a9b992] transition hover:bg-[#4a2c26] hover:text-white"
            title="Закрыть (~)"
          >
            ✕
          </button>
        </div>

        {/* section tabs */}
        <div className="flex flex-wrap gap-1 border-b border-[#2c3720] px-3 pt-2">
          {SECTIONS.map((s, i) => (
            <button
              key={s.id}
              onClick={() => setTab(i)}
              className={`rounded-t-md px-3 py-1.5 text-xs font-semibold transition ${
                tab === i ? "bg-[#4a5b32] text-white" : "text-[#a9b992] hover:text-white"
              }`}
            >
              <span className="mr-1">{s.icon}</span>{s.label}
            </button>
          ))}
        </div>

        {/* active section body */}
        <div className="px-4 py-3">{active.render()}</div>
      </div>
    </div>
  );
}
