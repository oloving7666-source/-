import { useEffect, useRef, useState } from "react";
import { clockLabel, dayPart, daytime } from "../daynight";
import { useGame } from "../store";

// Compact time-of-day readout, top-centre. Reads the live render clock via rAF
// (not the store, which doesn't tick per-frame) and shows a sun→night arc plus
// a warning tint while it's night, when the horde is more aggressive.
export default function DayClock() {
  const day = useGame((s) => s.day);
  const [, force] = useState(0);
  const frame = useRef(0);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      // repaint a few times a second — cheap, and the clock only needs coarse updates
      if (++frame.current % 12 === 0) force((n) => n + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const part = dayPart();
  const night = daytime.night;
  const angle = (((daytime.t % 1) + 1) % 1) * 360;

  return (
    <div className="pointer-events-none absolute left-3 top-[4.75rem] z-20">
      <div
        className="flex items-center gap-2.5 rounded-lg border px-3.5 py-1.5 backdrop-blur-md transition-colors"
        style={{
          borderColor: night > 0.4 ? "rgba(120,140,200,0.55)" : "rgba(127,147,100,0.5)",
          backgroundColor: night > 0.4 ? "rgba(18,22,40,0.7)" : "rgba(28,36,20,0.7)",
        }}
      >
        {/* little orbit dial */}
        <span className="relative flex h-6 w-6 items-center justify-center">
          <span className="absolute inset-0 rounded-full border border-white/15" />
          <span
            className="absolute h-2 w-2 rounded-full shadow"
            style={{
              backgroundColor: night > 0.5 ? "#cdd6ff" : "#ffdf9a",
              transform: `rotate(${angle}deg) translateY(-9px)`,
            }}
          />
        </span>
        <div className="leading-tight">
          <div className="font-mono text-sm font-semibold text-[#e8f0dd]">{clockLabel()}</div>
          <div className="text-[10px] uppercase tracking-wider text-[#a9b992]">
            {part.icon} {part.label} · День {day}
          </div>
        </div>
        {night > 0.4 && (
          <span className="ml-1 rounded-md bg-[#3a2c4a]/80 px-1.5 py-0.5 text-[10px] font-semibold text-[#d7c6ff]">
            орда активнее
          </span>
        )}
      </div>
    </div>
  );
}
