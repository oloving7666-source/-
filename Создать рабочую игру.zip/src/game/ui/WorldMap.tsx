import { BIOMES, type BiomeMeta } from "../config";
import { actions, useGame } from "../store";
import type { Biome } from "../types";

// Painted-board style world map. Each region is a little layered "postcard"
// scene built from that biome's real palette (sky, hills, water, decor) so the
// board previews what you'll actually deploy into. Clicking one moves the base.
const LAYOUT: Record<Biome, string> = {
  snow:   "1 / 2 / 2 / 4",
  desert: "1 / 1 / 3 / 2",
  forest: "2 / 2 / 3 / 3",
  swamp:  "2 / 3 / 3 / 4",
};

const ORDER: Biome[] = ["snow", "desert", "forest", "swamp"];

// Small triangular "tree/peak" silhouette anchored to the ground line.
function Tri({ x, c, s = 1 }: { x: string; c: string; s?: number }) {
  return (
    <span
      className="absolute bottom-2"
      style={{ left: x, width: 12 * s, height: 16 * s, backgroundColor: c, clipPath: "polygon(50% 0, 0 100%, 100% 100%)", transform: "translateX(-50%)" }}
    />
  );
}

// A tiny diorama drawn purely from the biome palette.
function Scene({ b }: { b: BiomeMeta }) {
  const g = b.ground;
  return (
    <span className="absolute inset-0 overflow-hidden">
      {/* sky */}
      <span className="absolute inset-0" style={{ backgroundImage: `linear-gradient(180deg, ${b.sky}, ${g.field2})` }} />
      {/* sun / moon */}
      <span
        className="absolute right-3 top-3 h-6 w-6 rounded-full opacity-80 blur-[1px]"
        style={{ backgroundColor: b.id === "snow" || b.id === "swamp" ? "#eef3f6" : "#fff2cf" }}
      />
      {/* far hills */}
      <span
        className="absolute inset-x-0 bottom-0 h-2/3"
        style={{ backgroundColor: g.rock, clipPath: "polygon(0 55%, 22% 30%, 45% 50%, 70% 22%, 100% 45%, 100% 100%, 0 100%)" }}
      />
      {/* peak cap */}
      <span
        className="absolute inset-x-0 bottom-0 h-2/3 opacity-90"
        style={{ backgroundColor: g.peak, clipPath: "polygon(70% 22%, 62% 34%, 78% 34%)" }}
      />
      {/* ground */}
      <span className="absolute inset-x-0 bottom-0 h-2/5" style={{ backgroundColor: g.field }} />
      {/* water pool */}
      <span
        className="absolute bottom-1 left-2 h-3 w-10 rounded-full"
        style={{ backgroundColor: b.water, opacity: b.waterOpacity }}
      />
      {/* biome decor silhouettes on the near ground */}
      {b.id === "forest" && (
        <>
          <Tri x="58%" c="#2f4a2b" />
          <Tri x="72%" c="#264022" s={0.8} />
          <Tri x="85%" c="#33512e" s={1.1} />
        </>
      )}
      {b.id === "swamp" && (
        <>
          <Tri x="60%" c="#243a22" s={0.9} />
          <span className="absolute bottom-1 right-4 h-4 w-1 -rotate-6 rounded" style={{ backgroundColor: "#3a4a2c" }} />
          <span className="absolute bottom-0 left-4 h-2 w-6 rounded-full" style={{ backgroundColor: "#3d5a3f", opacity: 0.7 }} />
        </>
      )}
      {b.id === "desert" && (
        <>
          <span className="absolute bottom-2 left-1/2 h-5 w-1.5 rounded" style={{ backgroundColor: "#4c6836" }} />
          <span className="absolute bottom-3.5 left-[46%] h-1.5 w-2 rounded" style={{ backgroundColor: "#4c6836" }} />
          <span className="absolute bottom-3.5 left-[52%] h-1.5 w-2 rounded" style={{ backgroundColor: "#4c6836" }} />
        </>
      )}
      {b.id === "snow" && (
        <>
          <Tri x="60%" c="#e8eef2" s={0.9} />
          <Tri x="78%" c="#d6dfe6" s={1.1} />
        </>
      )}
    </span>
  );
}

export default function WorldMap() {
  const biome = useGame((s) => s.biome);

  return (
    <div className="pointer-events-auto fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-6 backdrop-blur-sm">
      <div className="relative w-full max-w-3xl rounded-2xl border-2 border-[#3f5648] bg-[#0d1512] p-5 shadow-[0_0_60px_rgba(0,0,0,0.7)]">
        {/* header */}
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="text-xl font-bold tracking-wide text-[#e8f0dd]">🗺 Карта мира</div>
            <div className="text-xs text-[#37c7ac]">Эко-Завод: Грань · выберите локацию для высадки</div>
          </div>
          <button
            onClick={() => actions.closeWorldMap()}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-[#3f5648] bg-[#121a15] text-lg text-[#e8f0dd] transition hover:border-[#37c7ac] hover:text-[#37c7ac]"
            title="Закрыть (Esc)"
          >
            ✕
          </button>
        </div>

        {/* the board — a 2×3 region grid roughly matching the concept layout */}
        <div
          className="grid gap-2 rounded-xl border border-[#2a3a2e] bg-[#101a14] p-2"
          style={{ gridTemplateColumns: "1fr 1.2fr 1fr", gridTemplateRows: "1fr 1.2fr", aspectRatio: "16 / 10" }}
        >
          {ORDER.map((id) => {
            const meta = BIOMES[id];
            const active = id === biome;
            return (
              <button
                key={id}
                onClick={() => actions.setBiome(id)}
                style={{ gridArea: LAYOUT[id] }}
                className={`group relative flex flex-col items-center justify-end overflow-hidden rounded-lg border-2 pb-2 text-center transition ${
                  active
                    ? "border-[#37c7ac] ring-2 ring-[#37c7ac]/50"
                    : "border-black/30 hover:border-[#37c7ac] hover:brightness-110"
                }`}
                title={meta.blurb}
              >
                <Scene b={meta} />
                {active && <span className="absolute right-2 top-2 h-3 w-3 animate-ping rounded-full bg-[#37c7ac]" />}
                <span className="relative mt-1 rounded-md bg-black/55 px-2 py-0.5 text-sm font-bold text-white backdrop-blur-sm">
                  {meta.icon} {meta.label}
                  {active && " · вы здесь"}
                </span>
                <span className="relative mt-1 max-w-[88%] rounded bg-black/35 px-1.5 text-[11px] leading-tight text-white/90 backdrop-blur-sm">
                  {meta.blurb}
                </span>
                <span className="relative mt-1 max-w-[90%] rounded bg-[#123c37]/70 px-1.5 text-[10px] leading-tight text-[#8fe6d4] backdrop-blur-sm">
                  ⚙ {meta.mod.label}
                </span>
              </button>
            );
          })}
        </div>

        <div className="mt-3 text-center text-[11px] text-[#93a986]">
          Переключение локации мгновенно переносит вашу базу в новый биом. Постройки сохраняются.
        </div>
      </div>
    </div>
  );
}
