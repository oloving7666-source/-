import { useEffect, useRef, useState } from "react";
import { BIOMES, BUILDINGS, GRID, HALF, ORE_COLOR } from "../config";
import { actions, getState, isPowered, poweredPylons, useGame } from "../store";

const SIZE = 168;

// Lightweight 2D overview drawn each frame from the live store snapshot.
export default function Minimap() {
  const canvas = useRef<HTMLCanvasElement>(null);
  // subscribe so the component stays mounted with reactive phase tint
  const phase = useGame((s) => s.phase);
  const [heat, setHeat] = useState(false);
  const heatRef = useRef(heat);
  heatRef.current = heat;

  useEffect(() => {
    let raf = 0;
    const draw = () => {
      const c = canvas.current;
      if (c) {
        const ctx = c.getContext("2d")!;
        const s = getState();
        const k = SIZE / GRID;
        ctx.fillStyle = s.phase === "storm" ? "#2c2620" : BIOMES[s.biome].ground.field;
        ctx.fillRect(0, 0, SIZE, SIZE);

        // pollution heatmap: additive glow around active emitters (red = dirty,
        // green = a cleaner like the recycler / waterwheel scrubbing the air).
        if (heatRef.current) {
          const live = poweredPylons(s.buildings);
          ctx.globalCompositeOperation = "lighter";
          for (const b of s.buildings) {
            const p = BUILDINGS[b.kind].pollution;
            if (!p) continue;
            if (BUILDINGS[b.kind].power < 0 && !isPowered(b, s.buildings, live)) continue;
            const rad = (6 + Math.min(12, Math.abs(p) * 4)) * k;
            const cx = b.x * k, cz = b.z * k;
            const g = ctx.createRadialGradient(cx, cz, 0, cx, cz, rad);
            const col = p > 0 ? "217,102,63" : "90,180,90";
            g.addColorStop(0, `rgba(${col},0.55)`);
            g.addColorStop(1, `rgba(${col},0)`);
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.arc(cx, cz, rad, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.globalCompositeOperation = "source-over";
        }

        // ore nodes
        for (const n of s.nodes) {
          ctx.fillStyle = ORE_COLOR[n.ore];
          ctx.fillRect(n.x * k - 1, n.z * k - 1, 2.5, 2.5);
        }
        // buildings
        for (const b of s.buildings) {
          ctx.fillStyle = b.kind === "hub" ? "#ffd98a" : b.kind === "turret" ? "#d9663f" : "#cfe0b0";
          const sz = b.kind === "hub" ? 5 : 3;
          ctx.fillRect(b.x * k - sz / 2, b.z * k - sz / 2, sz, sz);
        }
        // belts
        ctx.strokeStyle = "#e0b45a";
        ctx.lineWidth = 1;
        for (const belt of s.belts) {
          ctx.beginPath();
          belt.cells.forEach((cell, i) => {
            const px = cell.x * k, pz = cell.z * k;
            i ? ctx.lineTo(px, pz) : ctx.moveTo(px, pz);
          });
          ctx.stroke();
        }
        // player
        const pcx = ((s.player.x + HALF) / (HALF * 2)) * SIZE;
        const pcz = ((s.player.z + HALF) / (HALF * 2)) * SIZE;
        ctx.fillStyle = "#fff6df";
        ctx.beginPath();
        ctx.arc(pcx, pcz, 3, 0, Math.PI * 2);
        ctx.fill();

        // top-down camera view centre (player + pan) — click elsewhere to jump
        if (s.mode === "architect") {
          const vcx = ((s.player.x + s.architectPan.x + HALF) / (HALF * 2)) * SIZE;
          const vcz = ((s.player.z + s.architectPan.z + HALF) / (HALF * 2)) * SIZE;
          ctx.strokeStyle = "#e0b45a";
          ctx.lineWidth = 1.5;
          ctx.strokeRect(vcx - 9, vcz - 9, 18, 18);
        }
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  const jump = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const px = ((e.clientX - r.left) / r.width) * (HALF * 2) - HALF;
    const pz = ((e.clientY - r.top) / r.height) * (HALF * 2) - HALF;
    actions.setArchitectPan(px, pz);
  };

  return (
    <div className="pointer-events-auto relative overflow-hidden rounded-lg border border-[#3f5648] bg-[#161d17]/90 p-1 backdrop-blur">
      <canvas
        ref={canvas}
        width={SIZE}
        height={SIZE}
        onClick={jump}
        title="Клик — перенести камеру сюда (в режиме TAB)"
        className="block cursor-crosshair rounded"
        style={{ imageRendering: "pixelated", outline: phase === "storm" ? "1px solid #d9663f" : "none" }}
      />
      <button
        onClick={(e) => { e.stopPropagation(); setHeat((v) => !v); }}
        title="Теплокарта загрязнения"
        className={`absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-md border text-sm leading-none backdrop-blur transition ${
          heat ? "border-[#d9663f] bg-[#f7e4d8]/90 text-[#a8442a]" : "border-[#3f5648] bg-[#161d17]/80 text-[#93a986] hover:border-[#37c7ac]"
        }`}
      >
        ☁
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); actions.openWorldMap(); }}
        title="Карта мира — выбрать локацию"
        className="absolute left-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-md border border-[#37c7ac]/60 bg-[#161d17]/85 text-sm leading-none text-[#37c7ac] backdrop-blur transition hover:bg-[#123c37]"
      >
        🗺
      </button>
    </div>
  );
}
