import { useState } from "react";
import { actions } from "../store";
import { audio } from "../audio";
import { GraphicsPanel, SoundPanel, GameplayPanel, Toggle } from "./Menu";
import { useGame } from "../store";

type Panel = "root" | "sound" | "video" | "tutorial";

export default function PauseMenu() {
  const [panel, setPanel] = useState<Panel>("root");

  const rootButtons: [string, () => void][] = [
    ["▶  Продолжить", () => { audio.play("click"); actions.closePauseMenu(); }],
    ["🔊  Звук", () => { audio.play("click"); setPanel("sound"); }],
    ["🎨  Графика", () => { audio.play("click"); setPanel("video"); }],
    ["📖  Обучение", () => { audio.play("click"); setPanel("tutorial"); }],
    ["🏠  Выйти в меню", () => { audio.play("click"); actions.quitToMenu(); }],
    ["⏻  Выйти из игры", () => { audio.play("click"); actions.quitGame(); }],
  ];

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#20281a]/60 backdrop-blur-sm">
      <div className="w-[380px] overflow-hidden rounded-2xl border border-[#3f5648] bg-[#161d17] shadow-2xl">
        <div className="border-b border-[#d7d8bd] bg-[#123c37] px-6 py-4 text-[#e9ead6]">
          <div className="text-lg font-bold tracking-tight">Пауза</div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-[#a9b992]">Эко-Завод: Грань</div>
        </div>

        <div className="p-5">
          {panel === "root" && (
            <div className="flex flex-col gap-2.5">
              {rootButtons.map(([label, onClick], i) => (
                <button
                  key={i}
                  onClick={onClick}
                  className={`rounded-xl px-5 py-3 text-left font-semibold transition ${
                    i === 0
                      ? "bg-[#5a7a41] text-white hover:bg-[#4c6836]"
                      : i >= 4
                      ? "border border-[#d8b5a5] bg-white text-[#8a4a34] hover:border-[#b5563f]"
                      : "border border-[#3f5648] bg-white text-[#d7e4c8] hover:border-[#5a7a41]"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          )}

          {panel !== "root" && (
            <div className="flex flex-col gap-4">
              <button
                onClick={() => { audio.play("click"); setPanel("root"); }}
                className="self-start text-sm font-semibold text-[#5a7a41] hover:underline"
              >
                ← Назад
              </button>
              {panel === "sound" && <SoundPanel />}
              {panel === "video" && <GraphicsPanel />}
              {panel === "tutorial" && <TutorialPanel />}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function TutorialPanel() {
  const on = useGame((s) => s.tutorial);
  return (
    <div className="flex flex-col gap-4">
      <p className="text-sm leading-relaxed text-[#93a986]">
        Пошаговое обучение показывает управление, строительство и оборону.
      </p>
      <Toggle
        label="Обучение"
        hint={on ? "Активно" : "Отключено"}
        on={on}
        onChange={() => (on ? actions.skipTutorial() : actions.startTutorial())}
      />
      <GameplayPanel />
    </div>
  );
}
