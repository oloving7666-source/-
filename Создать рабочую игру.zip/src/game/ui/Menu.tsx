import { useState, type ReactNode } from "react";
import { SAVE_KEY } from "../config";
import { actions, useGame } from "../store";
import { audio } from "../audio";
import menuBg from "@/imports/Gemini_Generated_Image_g3xkbg3xkbg3xkbg.jpg";

type Tab = "play" | "profile" | "sound" | "video" | "game" | "tutorial";

// User-supplied backdrop for the main menu.
const MENU_BG = menuBg;

const BIOME_LABEL: Record<string, string> = {
  forest: "Лес", desert: "Пустыня", snow: "Снега", swamp: "Болото",
};

// Peek at the autosave (if any) to show a short summary on the "Continue" button.
function readSaveMeta(): { day: number; biome: string; buildings: number } | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return null;
    const s = JSON.parse(raw);
    return {
      day: Number(s.day) || 1,
      biome: BIOME_LABEL[s.biome] ?? "Лес",
      buildings: Array.isArray(s.buildings) ? s.buildings.length : 0,
    };
  } catch {
    return null;
  }
}

// Small industrial bolt used on panel corners for the "riveted plate" look.
function Rivet({ className = "" }: { className?: string }) {
  return (
    <span
      className={`pointer-events-none absolute h-2 w-2 rounded-full bg-[#0f150a]/80 shadow-[inset_0_1px_1px_rgba(255,255,255,0.35),0_1px_1px_rgba(0,0,0,0.5)] ring-1 ring-[#8a9b73]/40 ${className}`}
    />
  );
}

// A dark, translucent green-glass plate with a soft top rim highlight and rivets
// in every corner — the single surface style shared across the whole menu.
// `dim` scales the fill opacity (lower = more see-through).
function Plate({ className = "", dim = 1, children }: { className?: string; dim?: number; children: ReactNode }) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-[#7f9364]/40 shadow-[0_18px_40px_rgba(0,0,0,0.5)] backdrop-blur-md ${className}`}
      style={{ backgroundImage: `linear-gradient(160deg, rgba(58,72,42,${0.82 * dim}), rgba(26,34,20,${0.86 * dim}))` }}
    >
      {/* glossy top-edge rim */}
      <span className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/40 to-transparent" />
      <Rivet className="left-2.5 top-2.5" />
      <Rivet className="right-2.5 top-2.5" />
      <Rivet className="bottom-2.5 left-2.5" />
      <Rivet className="bottom-2.5 right-2.5" />
      {children}
    </div>
  );
}

function Slider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <label className="flex items-center gap-4">
      <span className="w-40 text-sm text-[#c8d4b3]">{label}</span>
      <input
        type="range" min={0} max={1} step={0.01} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="flex-1 accent-[#7fa85f]"
      />
      <span className="w-10 text-right font-mono text-sm text-[#e9ead6]">{Math.round(value * 100)}</span>
    </label>
  );
}

export function Toggle({ label, hint, on, onChange }: { label: string; hint?: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => { audio.play("click"); onChange(!on); }}
      className={`flex items-center justify-between rounded-xl border px-4 py-3 text-left transition ${
        on ? "border-[#7fa85f] bg-[#3c4d2a]/80" : "border-[#4a5834]/60 bg-[#1c2414]/70 hover:border-[#6f8a4f]"
      }`}
    >
      <span>
        <span className="block text-sm font-semibold text-[#e9ead6]">{label}</span>
        {hint && <span className="block text-xs text-[#a9b992]">{hint}</span>}
      </span>
      <span className={`ml-4 flex h-6 w-11 shrink-0 items-center rounded-full px-0.5 transition ${on ? "bg-[#7fa85f]" : "bg-[#3a4530]"}`}>
        <span className={`h-5 w-5 rounded-full bg-white shadow transition ${on ? "translate-x-5" : ""}`} />
      </span>
    </button>
  );
}

const QUALITIES: [import("../types").Quality, string, string][] = [
  ["low", "Низкая", "Быстро на слабых ПК"],
  ["medium", "Средняя", "Баланс качества и FPS"],
  ["high", "Высокая", "Гуще лес, чёткие тени"],
];

// Shared style for the selectable "chip" buttons (quality / difficulty).
function chip(active: boolean) {
  return `flex-1 rounded-xl border px-4 py-4 text-left text-[#e9ead6] transition ${
    active ? "border-[#7fa85f] bg-[#3c4d2a]/80" : "border-[#4a5834]/60 bg-[#1c2414]/70 hover:border-[#6f8a4f]"
  }`;
}

export function GraphicsPanel() {
  const settings = useGame((s) => s.settings);
  return (
    <div className="flex flex-col gap-5">
      <div>
        <div className="mb-2 text-sm font-semibold text-[#a9b992]">Качество</div>
        <div className="flex gap-3">
          {QUALITIES.map(([q, title, desc]) => (
            <button
              key={q}
              onClick={() => { audio.play("click"); actions.setSettings({ quality: q }); }}
              className={chip(settings.quality === q)}
            >
              <div className="font-semibold">{title}</div>
              <div className="text-xs text-[#a9b992]">{desc}</div>
            </button>
          ))}
        </div>
      </div>
      <div className="flex flex-col gap-3">
        <Toggle label="Тени" hint="Мягкие тени от солнца" on={settings.shadows} onChange={(v) => actions.setSettings({ shadows: v })} />
        <Toggle label="Частицы" hint="Пыльца днём, искры в бурю" on={settings.particles} onChange={(v) => actions.setSettings({ particles: v })} />
        <Toggle label="Облака" hint="Плывущие облака в небе" on={settings.clouds} onChange={(v) => actions.setSettings({ clouds: v })} />
      </div>
    </div>
  );
}

export function SoundPanel() {
  const settings = useGame((s) => s.settings);
  return (
    <div className="flex flex-col gap-5">
      <Slider label="Общая громкость" value={settings.master} onChange={(v) => { audio.start(); actions.setSettings({ master: v }); audio.play("click"); }} />
      <Slider label="Музыка" value={settings.music} onChange={(v) => actions.setSettings({ music: v })} />
      <Slider label="Эффекты" value={settings.sfx} onChange={(v) => { actions.setSettings({ sfx: v }); audio.play("click"); }} />
      <Slider label="Эмбиент (природа)" value={settings.ambient} onChange={(v) => actions.setSettings({ ambient: v })} />
    </div>
  );
}

export function GameplayPanel() {
  const settings = useGame((s) => s.settings);
  return (
    <div className="flex flex-col gap-5">
      <div>
        <div className="mb-2 text-sm font-semibold text-[#a9b992]">Сложность</div>
        <div className="flex gap-3">
          {([1, 2, 3] as const).map((d) => (
            <button
              key={d}
              onClick={() => { audio.play("click"); actions.setSettings({ difficulty: d }); }}
              className={chip(settings.difficulty === d) + " text-center"}
            >
              <div className="font-semibold">{d === 1 ? "Спокойно" : d === 2 ? "Норма" : "Хардкор"}</div>
              <div className="text-xs text-[#a9b992]">Уровень {d}</div>
            </button>
          ))}
        </div>
      </div>
      <div className="flex flex-col gap-3">
        <Toggle label="Пауза в меню" hint="Останавливать время в паузе-меню" on={settings.pauseInMenu} onChange={(v) => actions.setSettings({ pauseInMenu: v })} />
        <Toggle label="Пауза в инвентаре" hint="Останавливать время в инвентаре/крафте" on={settings.pauseInInventory} onChange={(v) => actions.setSettings({ pauseInInventory: v })} />
        <Toggle label="Пауза в режиме TAB" hint="Всегда открывать вид сверху (архитектор) на паузе" on={settings.pauseInArchitect} onChange={(v) => actions.setSettings({ pauseInArchitect: v })} />
        <Toggle label="Подсказки" hint="Показывать всплывающие советы" on={settings.hints} onChange={(v) => actions.setSettings({ hints: v })} />
      </div>
    </div>
  );
}

// Corner toggle for the menu background music (🔊 / 🔇). First press also boots
// the audio engine (must happen inside a user gesture), then flips play/pause.
function MusicButton() {
  const [on, setOn] = useState(audio.isMusicOn() && audio.isStarted());
  const click = () => {
    if (!audio.isStarted()) { audio.start(); setOn(audio.isMusicOn()); }
    else setOn(audio.toggleMusic());
    audio.play("click");
  };
  return (
    <button
      onClick={click}
      title={on ? "Музыка: ВКЛ" : "Музыка: ВЫКЛ"}
      className={`group absolute right-6 top-6 z-10 flex h-11 w-11 items-center justify-center rounded-full border shadow-lg backdrop-blur-md transition ${
        on
          ? "border-[#7fa85f] bg-[#1c2414]/80 text-[#7fe08a]"
          : "border-[#4a5834]/60 bg-[#1c2414]/70 text-[#7b8570] hover:border-[#6f8a4f]"
      }`}
    >
      <svg
        viewBox="0 0 24 24"
        className="h-5 w-5"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.8}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M4 9v6h4l5 4V5L8 9H4z" />
        {on ? (
          <>
            <path d="M16 8.5a5 5 0 0 1 0 7" />
            <path d="M18.5 6a8.5 8.5 0 0 1 0 12" />
          </>
        ) : (
          <path d="M17 9l4 6M21 9l-4 6" />
        )}
      </svg>
    </button>
  );
}

export default function Menu() {
  const settings = useGame((s) => s.settings);
  const blueprints = useGame((s) => s.blueprints);
  const [tab, setTab] = useState<Tab>("play");
  const [confirmNew, setConfirmNew] = useState(false);
  const saveMeta = readSaveMeta();
  const hasSave = !!saveMeta;

  const tabs: [Tab, string][] = [
    ["play", "Играть"], ["profile", "Профиль"], ["sound", "Звук"], ["video", "Графика"], ["game", "Игра"], ["tutorial", "Обучение"],
  ];

  const TAB_TITLE: Record<Tab, string> = {
    play: `Добро пожаловать, ${settings.playerName}`,
    profile: "Профиль", sound: "Звук", video: "Графика", game: "Игра", tutorial: "Обучение",
  };

  return (
    <div className="absolute inset-0 z-30 overflow-hidden">
      {/* forest waterfall backdrop */}
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url("${MENU_BG}")` }} />
      <div className="absolute inset-0 bg-gradient-to-br from-[#0d1408]/55 via-[#12200c]/35 to-[#0a1207]/65" />

      {/* corner music on/off */}
      <MusicButton />

      {/* floating panels */}
      <div className="relative flex h-full w-full items-center justify-center gap-8 px-8">
        {/* ---- LEFT: brand + navigation plate ---- */}
        <Plate className="menu-rise flex w-[300px] flex-col p-6 text-[#e9ead6]">
          <div className="mb-1 text-3xl font-bold tracking-tight drop-shadow">Vanguard-Grid</div>
          <div className="mb-6 font-mono text-[11px] uppercase tracking-[0.2em] text-[#a9b992]">Эко-Завод: Грань</div>
          <div className="flex flex-col gap-2">
            {tabs.map(([id, label]) => {
              const active = tab === id;
              return (
                <button
                  key={id}
                  onClick={() => { audio.play("click"); setTab(id); }}
                  className={`relative flex items-center justify-between rounded-lg border px-4 py-2.5 text-left text-[15px] transition ${
                    active
                      ? "border-[#7fa85f] bg-[#4c6836] font-semibold text-white shadow-inner"
                      : "border-[#4a5834]/70 bg-[#2c3720]/70 text-[#c8d4b3] hover:border-[#6f8a4f] hover:bg-[#38471f]/80"
                  }`}
                >
                  <Rivet className="left-1.5 top-1/2 -translate-y-1/2" />
                  <span className="pl-2">{label}</span>
                  {active ? <span className="text-sm opacity-90">⚙</span> : <Rivet className="right-1.5 top-1/2 -translate-y-1/2" />}
                </button>
              );
            })}
          </div>
          <div className="mt-6 font-mono text-[10px] text-[#8a9b73]">v0.8 · web prototype</div>
        </Plate>

        {/* ---- RIGHT: active tab content plate (same glass surface, more see-through) ---- */}
        <Plate dim={0.6} className="menu-rise flex max-h-[80vh] w-[440px] flex-col overflow-y-auto p-8 text-[#e9ead6] [animation-delay:110ms]">
          <h2 className="mb-4 text-3xl font-bold drop-shadow">{TAB_TITLE[tab]}</h2>

          {tab === "play" && (
            <div className="flex flex-col">
              <p className="mb-6 text-sm leading-relaxed text-[#cdd8bd]">
                Стройте лесную фабрику днём, обороняйте ядро ночью. Загрязняете природу —
                злите орду. Баланс между скоростью и экологией за вами.
              </p>
              <div className="flex flex-col gap-3">
                <button
                  onClick={() => { if (saveMeta) { audio.play("click"); setConfirmNew(true); } else { actions.reset(); actions.startGame(); } }}
                  className="relative rounded-xl border border-[#7fa85f] bg-[#5a7a41] px-6 py-4 text-left text-lg font-semibold text-white shadow-lg transition hover:bg-[#4c6836]"
                >
                  <Rivet className="left-2 top-2" />
                  <Rivet className="right-2 top-2" />
                  <Rivet className="bottom-2 left-2" />
                  <Rivet className="bottom-2 right-2" />
                  ▶ Новая база
                </button>

                {/* Guard: starting fresh would overwrite the autosave. */}
                {confirmNew && (
                  <div className="rounded-xl border border-[#c08a4a]/60 bg-[#2a1f14]/80 p-4">
                    <div className="mb-1 text-sm font-semibold text-[#f0d9b0]">Перезаписать прогресс?</div>
                    <p className="mb-3 text-xs leading-relaxed text-[#d8c3a0]">
                      Есть сохранение: День {saveMeta?.day} · {saveMeta?.biome} · построек: {saveMeta?.buildings}.
                      Новая база сотрёт его.
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => { actions.reset(); actions.startGame(); }}
                        className="flex-1 rounded-lg border border-[#c08a4a] bg-[#7a4f22]/80 px-3 py-2 text-sm font-semibold text-[#ffe9c8] transition hover:bg-[#8a5a28]"
                      >
                        Начать заново
                      </button>
                      <button
                        onClick={() => { audio.play("click"); setConfirmNew(false); }}
                        className="flex-1 rounded-lg border border-[#4a5834]/60 bg-[#1c2414]/70 px-3 py-2 text-sm font-semibold text-[#dbe4cb] transition hover:border-[#6f8a4f]"
                      >
                        Отмена
                      </button>
                    </div>
                  </div>
                )}

                {saveMeta && (
                  <button
                    onClick={() => { actions.load(); actions.startGame(); }}
                    className="rounded-xl border border-[#6f7f57]/60 bg-[#2c3720]/70 px-6 py-3.5 text-left transition hover:border-[#7fa85f] hover:bg-[#38471f]/80"
                  >
                    <span className="block font-semibold text-[#dbe4cb]">↺ Продолжить</span>
                    <span className="mt-0.5 block text-xs text-[#a9b992]">
                      День {saveMeta.day} · {saveMeta.biome} · построек: {saveMeta.buildings}
                    </span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* All settings tabs share the same dark-glass surface as the plate. */}
          {tab === "profile" && (
            <div>
              <label className="mb-6 block">
                <span className="mb-2 block text-sm text-[#a9b992]">Имя смотрителя</span>
                <input
                  value={settings.playerName}
                  onChange={(e) => actions.setSettings({ playerName: e.target.value })}
                  className="w-full rounded-lg border border-[#4a5834]/60 bg-[#1c2414]/70 px-4 py-2.5 text-[#e9ead6] outline-none transition focus:border-[#7fa85f]"
                />
              </label>
              <div className="rounded-lg border border-[#4a5834]/50 bg-[#1c2414]/60 p-4 text-sm text-[#a9b992]">
                Сохранённых чертежей: <b className="text-[#e9ead6]">{blueprints.length}</b>
              </div>
            </div>
          )}
          {tab === "sound" && <SoundPanel />}
          {tab === "video" && <GraphicsPanel />}
          {tab === "game" && <GameplayPanel />}
          {tab === "tutorial" && (
            <div>
              <p className="mb-6 text-sm leading-relaxed text-[#cdd8bd]">
                Пошаговое обучение показывает управление камерой, строительство и оборону.
                Его можно пропустить в любой момент.
              </p>
              <TutorialToggle />
            </div>
          )}
        </Plate>
      </div>
    </div>
  );
}

function TutorialToggle() {
  const on = useGame((s) => s.tutorial);
  return (
    <button
      onClick={() => (on ? actions.skipTutorial() : actions.startTutorial())}
      className={`rounded-xl border px-6 py-3 font-semibold text-[#e9ead6] transition ${
        on ? "border-[#7fa85f] bg-[#3c4d2a]/80" : "border-[#4a5834]/60 bg-[#1c2414]/70 hover:border-[#6f8a4f]"
      }`}
    >
      Обучение при старте: {on ? "ВКЛ" : "ВЫКЛ"}
    </button>
  );
}
