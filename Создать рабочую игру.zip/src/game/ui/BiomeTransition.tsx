import { useEffect, useRef, useState } from "react";
import { BIOMES } from "../config";
import { useGame } from "../store";

// Full-screen wipe played whenever the active biome changes: a quick flash to
// the new biome's sky colour, then a fade back to gameplay — so switching
// locations from the world map feels like a deliberate transit, not a jump-cut.
export default function BiomeTransition() {
  const biome = useGame((s) => s.biome);
  const first = useRef(true);
  const [flash, setFlash] = useState<{ color: string; label: string } | null>(null);

  useEffect(() => {
    if (first.current) { first.current = false; return; } // skip the initial mount
    const meta = BIOMES[biome];
    setFlash({ color: meta.sky, label: meta.label });
    const id = setTimeout(() => setFlash(null), 900);
    return () => clearTimeout(id);
  }, [biome]);

  if (!flash) return null;
  return (
    <div
      className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center"
      style={{ animation: "biomeWipe 900ms ease-in-out forwards" }}
    >
      <div className="absolute inset-0" style={{ backgroundColor: flash.color }} />
      <div
        className="relative rounded-full border border-white/40 bg-black/30 px-6 py-2 text-lg font-semibold tracking-wide text-white backdrop-blur-sm"
        style={{ animation: "biomeLabel 900ms ease-in-out forwards" }}
      >
        {flash.label}
      </div>
    </div>
  );
}
