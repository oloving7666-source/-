// Shared day/night clock. Written each frame by <Environment>, read by the HUD
// clock widget and by the sim tick (night raises the threat). Kept in its own
// tiny module so both the render layer and the store can import it without a
// heavy circular dependency.
export const daytime = { t: 0.4, light: 1, night: 0 };

// Human-readable HH:MM from the 0..1 clock (0 = midnight, 0.5 = noon).
export function clockLabel(): string {
  const mins = Math.floor(((daytime.t % 1) + 1) % 1 * 24 * 60);
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

// Coarse part-of-day used for the icon + label.
export function dayPart(): { icon: string; label: string } {
  const t = ((daytime.t % 1) + 1) % 1;
  if (t < 0.24 || t >= 0.82) return { icon: "🌙", label: "Ночь" };
  if (t < 0.32) return { icon: "🌅", label: "Рассвет" };
  if (t < 0.68) return { icon: "☀", label: "День" };
  return { icon: "🌇", label: "Закат" };
}
